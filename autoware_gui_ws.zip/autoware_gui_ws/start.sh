#!/bin/sh
cd install
./setup.sh
cd /usr/bin
./qtcreator
