// generated from rosidl_generator_c/resource/idl.h.em
// with input from sensor_driver_msgs:msg/UltrasonicRadar20.idl
// generated code does not contain a copyright notice

#ifndef SENSOR_DRIVER_MSGS__MSG__ULTRASONIC_RADAR20_H_
#define SENSOR_DRIVER_MSGS__MSG__ULTRASONIC_RADAR20_H_

#include "sensor_driver_msgs/msg/detail/ultrasonic_radar20__struct.h"
#include "sensor_driver_msgs/msg/detail/ultrasonic_radar20__functions.h"
#include "sensor_driver_msgs/msg/detail/ultrasonic_radar20__type_support.h"

#endif  // SENSOR_DRIVER_MSGS__MSG__ULTRASONIC_RADAR20_H_
