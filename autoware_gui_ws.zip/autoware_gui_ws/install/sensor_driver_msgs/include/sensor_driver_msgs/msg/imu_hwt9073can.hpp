// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SENSOR_DRIVER_MSGS__MSG__IMU_HWT9073CAN_HPP_
#define SENSOR_DRIVER_MSGS__MSG__IMU_HWT9073CAN_HPP_

#include "sensor_driver_msgs/msg/detail/imu_hwt9073can__struct.hpp"
#include "sensor_driver_msgs/msg/detail/imu_hwt9073can__builder.hpp"
#include "sensor_driver_msgs/msg/detail/imu_hwt9073can__traits.hpp"

#endif  // SENSOR_DRIVER_MSGS__MSG__IMU_HWT9073CAN_HPP_
