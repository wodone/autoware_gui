// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SENSOR_DRIVER_MSGS__MSG__GNSS_PASHR_HPP_
#define SENSOR_DRIVER_MSGS__MSG__GNSS_PASHR_HPP_

#include "sensor_driver_msgs/msg/detail/gnss_pashr__struct.hpp"
#include "sensor_driver_msgs/msg/detail/gnss_pashr__builder.hpp"
#include "sensor_driver_msgs/msg/detail/gnss_pashr__traits.hpp"

#endif  // SENSOR_DRIVER_MSGS__MSG__GNSS_PASHR_HPP_
