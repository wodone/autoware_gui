// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from sensor_driver_msgs:msg/GnssGpgga.idl
// generated code does not contain a copyright notice

#ifndef SENSOR_DRIVER_MSGS__MSG__DETAIL__GNSS_GPGGA__STRUCT_HPP_
#define SENSOR_DRIVER_MSGS__MSG__DETAIL__GNSS_GPGGA__STRUCT_HPP_

#include <rosidl_runtime_cpp/bounded_vector.hpp>
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__sensor_driver_msgs__msg__GnssGpgga __attribute__((deprecated))
#else
# define DEPRECATED__sensor_driver_msgs__msg__GnssGpgga __declspec(deprecated)
#endif

namespace sensor_driver_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct GnssGpgga_
{
  using Type = GnssGpgga_<ContainerAllocator>;

  explicit GnssGpgga_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->data_id = "";
      this->utc_time = 0.0;
      this->latitude = 0.0;
      this->latitude_sign = "";
      this->longitude = 0.0;
      this->longitude_sign = "";
      this->state = 0;
      this->satellite_num = 0;
      this->hdop = 0.0;
      this->altitude = 0.0;
      this->altitude_sign = "";
      this->altitude_diff = 0.0;
      this->altitude_diff_sign = "";
      this->rtk_delay = 0.0;
      this->rtk_id = 0;
      this->cs = "";
    }
  }

  explicit GnssGpgga_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init),
    data_id(_alloc),
    latitude_sign(_alloc),
    longitude_sign(_alloc),
    altitude_sign(_alloc),
    altitude_diff_sign(_alloc),
    cs(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->data_id = "";
      this->utc_time = 0.0;
      this->latitude = 0.0;
      this->latitude_sign = "";
      this->longitude = 0.0;
      this->longitude_sign = "";
      this->state = 0;
      this->satellite_num = 0;
      this->hdop = 0.0;
      this->altitude = 0.0;
      this->altitude_sign = "";
      this->altitude_diff = 0.0;
      this->altitude_diff_sign = "";
      this->rtk_delay = 0.0;
      this->rtk_id = 0;
      this->cs = "";
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _data_id_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _data_id_type data_id;
  using _utc_time_type =
    double;
  _utc_time_type utc_time;
  using _latitude_type =
    double;
  _latitude_type latitude;
  using _latitude_sign_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _latitude_sign_type latitude_sign;
  using _longitude_type =
    double;
  _longitude_type longitude;
  using _longitude_sign_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _longitude_sign_type longitude_sign;
  using _state_type =
    uint16_t;
  _state_type state;
  using _satellite_num_type =
    uint16_t;
  _satellite_num_type satellite_num;
  using _hdop_type =
    double;
  _hdop_type hdop;
  using _altitude_type =
    double;
  _altitude_type altitude;
  using _altitude_sign_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _altitude_sign_type altitude_sign;
  using _altitude_diff_type =
    double;
  _altitude_diff_type altitude_diff;
  using _altitude_diff_sign_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _altitude_diff_sign_type altitude_diff_sign;
  using _rtk_delay_type =
    double;
  _rtk_delay_type rtk_delay;
  using _rtk_id_type =
    uint16_t;
  _rtk_id_type rtk_id;
  using _cs_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _cs_type cs;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__data_id(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->data_id = _arg;
    return *this;
  }
  Type & set__utc_time(
    const double & _arg)
  {
    this->utc_time = _arg;
    return *this;
  }
  Type & set__latitude(
    const double & _arg)
  {
    this->latitude = _arg;
    return *this;
  }
  Type & set__latitude_sign(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->latitude_sign = _arg;
    return *this;
  }
  Type & set__longitude(
    const double & _arg)
  {
    this->longitude = _arg;
    return *this;
  }
  Type & set__longitude_sign(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->longitude_sign = _arg;
    return *this;
  }
  Type & set__state(
    const uint16_t & _arg)
  {
    this->state = _arg;
    return *this;
  }
  Type & set__satellite_num(
    const uint16_t & _arg)
  {
    this->satellite_num = _arg;
    return *this;
  }
  Type & set__hdop(
    const double & _arg)
  {
    this->hdop = _arg;
    return *this;
  }
  Type & set__altitude(
    const double & _arg)
  {
    this->altitude = _arg;
    return *this;
  }
  Type & set__altitude_sign(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->altitude_sign = _arg;
    return *this;
  }
  Type & set__altitude_diff(
    const double & _arg)
  {
    this->altitude_diff = _arg;
    return *this;
  }
  Type & set__altitude_diff_sign(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->altitude_diff_sign = _arg;
    return *this;
  }
  Type & set__rtk_delay(
    const double & _arg)
  {
    this->rtk_delay = _arg;
    return *this;
  }
  Type & set__rtk_id(
    const uint16_t & _arg)
  {
    this->rtk_id = _arg;
    return *this;
  }
  Type & set__cs(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->cs = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    sensor_driver_msgs::msg::GnssGpgga_<ContainerAllocator> *;
  using ConstRawPtr =
    const sensor_driver_msgs::msg::GnssGpgga_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<sensor_driver_msgs::msg::GnssGpgga_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<sensor_driver_msgs::msg::GnssGpgga_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      sensor_driver_msgs::msg::GnssGpgga_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<sensor_driver_msgs::msg::GnssGpgga_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      sensor_driver_msgs::msg::GnssGpgga_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<sensor_driver_msgs::msg::GnssGpgga_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<sensor_driver_msgs::msg::GnssGpgga_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<sensor_driver_msgs::msg::GnssGpgga_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__sensor_driver_msgs__msg__GnssGpgga
    std::shared_ptr<sensor_driver_msgs::msg::GnssGpgga_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__sensor_driver_msgs__msg__GnssGpgga
    std::shared_ptr<sensor_driver_msgs::msg::GnssGpgga_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const GnssGpgga_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->data_id != other.data_id) {
      return false;
    }
    if (this->utc_time != other.utc_time) {
      return false;
    }
    if (this->latitude != other.latitude) {
      return false;
    }
    if (this->latitude_sign != other.latitude_sign) {
      return false;
    }
    if (this->longitude != other.longitude) {
      return false;
    }
    if (this->longitude_sign != other.longitude_sign) {
      return false;
    }
    if (this->state != other.state) {
      return false;
    }
    if (this->satellite_num != other.satellite_num) {
      return false;
    }
    if (this->hdop != other.hdop) {
      return false;
    }
    if (this->altitude != other.altitude) {
      return false;
    }
    if (this->altitude_sign != other.altitude_sign) {
      return false;
    }
    if (this->altitude_diff != other.altitude_diff) {
      return false;
    }
    if (this->altitude_diff_sign != other.altitude_diff_sign) {
      return false;
    }
    if (this->rtk_delay != other.rtk_delay) {
      return false;
    }
    if (this->rtk_id != other.rtk_id) {
      return false;
    }
    if (this->cs != other.cs) {
      return false;
    }
    return true;
  }
  bool operator!=(const GnssGpgga_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct GnssGpgga_

// alias to use template instance with default allocator
using GnssGpgga =
  sensor_driver_msgs::msg::GnssGpgga_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace sensor_driver_msgs

#endif  // SENSOR_DRIVER_MSGS__MSG__DETAIL__GNSS_GPGGA__STRUCT_HPP_
