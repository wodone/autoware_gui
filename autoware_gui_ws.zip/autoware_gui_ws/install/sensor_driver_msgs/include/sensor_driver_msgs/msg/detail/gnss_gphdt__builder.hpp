// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sensor_driver_msgs:msg/GnssGphdt.idl
// generated code does not contain a copyright notice

#ifndef SENSOR_DRIVER_MSGS__MSG__DETAIL__GNSS_GPHDT__BUILDER_HPP_
#define SENSOR_DRIVER_MSGS__MSG__DETAIL__GNSS_GPHDT__BUILDER_HPP_

#include "sensor_driver_msgs/msg/detail/gnss_gphdt__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace sensor_driver_msgs
{

namespace msg
{

namespace builder
{

class Init_GnssGphdt_cs
{
public:
  explicit Init_GnssGphdt_cs(::sensor_driver_msgs::msg::GnssGphdt & msg)
  : msg_(msg)
  {}
  ::sensor_driver_msgs::msg::GnssGphdt cs(::sensor_driver_msgs::msg::GnssGphdt::_cs_type arg)
  {
    msg_.cs = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGphdt msg_;
};

class Init_GnssGphdt_t_sign
{
public:
  explicit Init_GnssGphdt_t_sign(::sensor_driver_msgs::msg::GnssGphdt & msg)
  : msg_(msg)
  {}
  Init_GnssGphdt_cs t_sign(::sensor_driver_msgs::msg::GnssGphdt::_t_sign_type arg)
  {
    msg_.t_sign = std::move(arg);
    return Init_GnssGphdt_cs(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGphdt msg_;
};

class Init_GnssGphdt_yaw
{
public:
  explicit Init_GnssGphdt_yaw(::sensor_driver_msgs::msg::GnssGphdt & msg)
  : msg_(msg)
  {}
  Init_GnssGphdt_t_sign yaw(::sensor_driver_msgs::msg::GnssGphdt::_yaw_type arg)
  {
    msg_.yaw = std::move(arg);
    return Init_GnssGphdt_t_sign(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGphdt msg_;
};

class Init_GnssGphdt_data_id
{
public:
  explicit Init_GnssGphdt_data_id(::sensor_driver_msgs::msg::GnssGphdt & msg)
  : msg_(msg)
  {}
  Init_GnssGphdt_yaw data_id(::sensor_driver_msgs::msg::GnssGphdt::_data_id_type arg)
  {
    msg_.data_id = std::move(arg);
    return Init_GnssGphdt_yaw(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGphdt msg_;
};

class Init_GnssGphdt_header
{
public:
  Init_GnssGphdt_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_GnssGphdt_data_id header(::sensor_driver_msgs::msg::GnssGphdt::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_GnssGphdt_data_id(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGphdt msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sensor_driver_msgs::msg::GnssGphdt>()
{
  return sensor_driver_msgs::msg::builder::Init_GnssGphdt_header();
}

}  // namespace sensor_driver_msgs

#endif  // SENSOR_DRIVER_MSGS__MSG__DETAIL__GNSS_GPHDT__BUILDER_HPP_
