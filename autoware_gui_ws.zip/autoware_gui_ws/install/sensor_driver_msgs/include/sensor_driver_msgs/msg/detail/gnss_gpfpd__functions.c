// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from sensor_driver_msgs:msg/GnssGpfpd.idl
// generated code does not contain a copyright notice
#include "sensor_driver_msgs/msg/detail/gnss_gpfpd__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"
// Member `data_id`
// Member `cs`
#include "rosidl_runtime_c/string_functions.h"

bool
sensor_driver_msgs__msg__GnssGpfpd__init(sensor_driver_msgs__msg__GnssGpfpd * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    sensor_driver_msgs__msg__GnssGpfpd__fini(msg);
    return false;
  }
  // data_id
  if (!rosidl_runtime_c__String__init(&msg->data_id)) {
    sensor_driver_msgs__msg__GnssGpfpd__fini(msg);
    return false;
  }
  // gps_week
  // gps_time
  // yaw
  // pitch
  // roll
  // latitude
  // longitude
  // altitude
  // velocity_east
  // velocity_north
  // velocity_sky
  // base_line
  // satellite_num_1
  // satellite_num_2
  // state
  // cs
  if (!rosidl_runtime_c__String__init(&msg->cs)) {
    sensor_driver_msgs__msg__GnssGpfpd__fini(msg);
    return false;
  }
  return true;
}

void
sensor_driver_msgs__msg__GnssGpfpd__fini(sensor_driver_msgs__msg__GnssGpfpd * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // data_id
  rosidl_runtime_c__String__fini(&msg->data_id);
  // gps_week
  // gps_time
  // yaw
  // pitch
  // roll
  // latitude
  // longitude
  // altitude
  // velocity_east
  // velocity_north
  // velocity_sky
  // base_line
  // satellite_num_1
  // satellite_num_2
  // state
  // cs
  rosidl_runtime_c__String__fini(&msg->cs);
}

bool
sensor_driver_msgs__msg__GnssGpfpd__are_equal(const sensor_driver_msgs__msg__GnssGpfpd * lhs, const sensor_driver_msgs__msg__GnssGpfpd * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // data_id
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->data_id), &(rhs->data_id)))
  {
    return false;
  }
  // gps_week
  if (lhs->gps_week != rhs->gps_week) {
    return false;
  }
  // gps_time
  if (lhs->gps_time != rhs->gps_time) {
    return false;
  }
  // yaw
  if (lhs->yaw != rhs->yaw) {
    return false;
  }
  // pitch
  if (lhs->pitch != rhs->pitch) {
    return false;
  }
  // roll
  if (lhs->roll != rhs->roll) {
    return false;
  }
  // latitude
  if (lhs->latitude != rhs->latitude) {
    return false;
  }
  // longitude
  if (lhs->longitude != rhs->longitude) {
    return false;
  }
  // altitude
  if (lhs->altitude != rhs->altitude) {
    return false;
  }
  // velocity_east
  if (lhs->velocity_east != rhs->velocity_east) {
    return false;
  }
  // velocity_north
  if (lhs->velocity_north != rhs->velocity_north) {
    return false;
  }
  // velocity_sky
  if (lhs->velocity_sky != rhs->velocity_sky) {
    return false;
  }
  // base_line
  if (lhs->base_line != rhs->base_line) {
    return false;
  }
  // satellite_num_1
  if (lhs->satellite_num_1 != rhs->satellite_num_1) {
    return false;
  }
  // satellite_num_2
  if (lhs->satellite_num_2 != rhs->satellite_num_2) {
    return false;
  }
  // state
  if (lhs->state != rhs->state) {
    return false;
  }
  // cs
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->cs), &(rhs->cs)))
  {
    return false;
  }
  return true;
}

bool
sensor_driver_msgs__msg__GnssGpfpd__copy(
  const sensor_driver_msgs__msg__GnssGpfpd * input,
  sensor_driver_msgs__msg__GnssGpfpd * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // data_id
  if (!rosidl_runtime_c__String__copy(
      &(input->data_id), &(output->data_id)))
  {
    return false;
  }
  // gps_week
  output->gps_week = input->gps_week;
  // gps_time
  output->gps_time = input->gps_time;
  // yaw
  output->yaw = input->yaw;
  // pitch
  output->pitch = input->pitch;
  // roll
  output->roll = input->roll;
  // latitude
  output->latitude = input->latitude;
  // longitude
  output->longitude = input->longitude;
  // altitude
  output->altitude = input->altitude;
  // velocity_east
  output->velocity_east = input->velocity_east;
  // velocity_north
  output->velocity_north = input->velocity_north;
  // velocity_sky
  output->velocity_sky = input->velocity_sky;
  // base_line
  output->base_line = input->base_line;
  // satellite_num_1
  output->satellite_num_1 = input->satellite_num_1;
  // satellite_num_2
  output->satellite_num_2 = input->satellite_num_2;
  // state
  output->state = input->state;
  // cs
  if (!rosidl_runtime_c__String__copy(
      &(input->cs), &(output->cs)))
  {
    return false;
  }
  return true;
}

sensor_driver_msgs__msg__GnssGpfpd *
sensor_driver_msgs__msg__GnssGpfpd__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sensor_driver_msgs__msg__GnssGpfpd * msg = (sensor_driver_msgs__msg__GnssGpfpd *)allocator.allocate(sizeof(sensor_driver_msgs__msg__GnssGpfpd), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(sensor_driver_msgs__msg__GnssGpfpd));
  bool success = sensor_driver_msgs__msg__GnssGpfpd__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
sensor_driver_msgs__msg__GnssGpfpd__destroy(sensor_driver_msgs__msg__GnssGpfpd * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    sensor_driver_msgs__msg__GnssGpfpd__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
sensor_driver_msgs__msg__GnssGpfpd__Sequence__init(sensor_driver_msgs__msg__GnssGpfpd__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sensor_driver_msgs__msg__GnssGpfpd * data = NULL;

  if (size) {
    data = (sensor_driver_msgs__msg__GnssGpfpd *)allocator.zero_allocate(size, sizeof(sensor_driver_msgs__msg__GnssGpfpd), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = sensor_driver_msgs__msg__GnssGpfpd__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        sensor_driver_msgs__msg__GnssGpfpd__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
sensor_driver_msgs__msg__GnssGpfpd__Sequence__fini(sensor_driver_msgs__msg__GnssGpfpd__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      sensor_driver_msgs__msg__GnssGpfpd__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

sensor_driver_msgs__msg__GnssGpfpd__Sequence *
sensor_driver_msgs__msg__GnssGpfpd__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sensor_driver_msgs__msg__GnssGpfpd__Sequence * array = (sensor_driver_msgs__msg__GnssGpfpd__Sequence *)allocator.allocate(sizeof(sensor_driver_msgs__msg__GnssGpfpd__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = sensor_driver_msgs__msg__GnssGpfpd__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
sensor_driver_msgs__msg__GnssGpfpd__Sequence__destroy(sensor_driver_msgs__msg__GnssGpfpd__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    sensor_driver_msgs__msg__GnssGpfpd__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
sensor_driver_msgs__msg__GnssGpfpd__Sequence__are_equal(const sensor_driver_msgs__msg__GnssGpfpd__Sequence * lhs, const sensor_driver_msgs__msg__GnssGpfpd__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!sensor_driver_msgs__msg__GnssGpfpd__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
sensor_driver_msgs__msg__GnssGpfpd__Sequence__copy(
  const sensor_driver_msgs__msg__GnssGpfpd__Sequence * input,
  sensor_driver_msgs__msg__GnssGpfpd__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(sensor_driver_msgs__msg__GnssGpfpd);
    sensor_driver_msgs__msg__GnssGpfpd * data =
      (sensor_driver_msgs__msg__GnssGpfpd *)realloc(output->data, allocation_size);
    if (!data) {
      return false;
    }
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!sensor_driver_msgs__msg__GnssGpfpd__init(&data[i])) {
        /* free currently allocated and return false */
        for (; i-- > output->capacity; ) {
          sensor_driver_msgs__msg__GnssGpfpd__fini(&data[i]);
        }
        free(data);
        return false;
      }
    }
    output->data = data;
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!sensor_driver_msgs__msg__GnssGpfpd__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
