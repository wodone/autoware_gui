// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from sensor_driver_msgs:msg/UltrasonicRadar20.idl
// generated code does not contain a copyright notice

#ifndef SENSOR_DRIVER_MSGS__MSG__DETAIL__ULTRASONIC_RADAR20__STRUCT_HPP_
#define SENSOR_DRIVER_MSGS__MSG__DETAIL__ULTRASONIC_RADAR20__STRUCT_HPP_

#include <rosidl_runtime_cpp/bounded_vector.hpp>
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__sensor_driver_msgs__msg__UltrasonicRadar20 __attribute__((deprecated))
#else
# define DEPRECATED__sensor_driver_msgs__msg__UltrasonicRadar20 __declspec(deprecated)
#endif

namespace sensor_driver_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct UltrasonicRadar20_
{
  using Type = UltrasonicRadar20_<ContainerAllocator>;

  explicit UltrasonicRadar20_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->ultrasonic_01 = 0;
      this->ultrasonic_02 = 0;
      this->ultrasonic_03 = 0;
      this->ultrasonic_04 = 0;
      this->ultrasonic_05 = 0;
      this->ultrasonic_06 = 0;
      this->ultrasonic_07 = 0;
      this->ultrasonic_08 = 0;
      this->ultrasonic_09 = 0;
      this->ultrasonic_10 = 0;
      this->ultrasonic_11 = 0;
      this->ultrasonic_12 = 0;
      this->ultrasonic_13 = 0;
      this->ultrasonic_14 = 0;
      this->ultrasonic_15 = 0;
      this->ultrasonic_16 = 0;
      this->ultrasonic_17 = 0;
      this->ultrasonic_18 = 0;
      this->ultrasonic_19 = 0;
      this->ultrasonic_20 = 0;
    }
  }

  explicit UltrasonicRadar20_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->ultrasonic_01 = 0;
      this->ultrasonic_02 = 0;
      this->ultrasonic_03 = 0;
      this->ultrasonic_04 = 0;
      this->ultrasonic_05 = 0;
      this->ultrasonic_06 = 0;
      this->ultrasonic_07 = 0;
      this->ultrasonic_08 = 0;
      this->ultrasonic_09 = 0;
      this->ultrasonic_10 = 0;
      this->ultrasonic_11 = 0;
      this->ultrasonic_12 = 0;
      this->ultrasonic_13 = 0;
      this->ultrasonic_14 = 0;
      this->ultrasonic_15 = 0;
      this->ultrasonic_16 = 0;
      this->ultrasonic_17 = 0;
      this->ultrasonic_18 = 0;
      this->ultrasonic_19 = 0;
      this->ultrasonic_20 = 0;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _ultrasonic_01_type =
    uint16_t;
  _ultrasonic_01_type ultrasonic_01;
  using _ultrasonic_02_type =
    uint16_t;
  _ultrasonic_02_type ultrasonic_02;
  using _ultrasonic_03_type =
    uint16_t;
  _ultrasonic_03_type ultrasonic_03;
  using _ultrasonic_04_type =
    uint16_t;
  _ultrasonic_04_type ultrasonic_04;
  using _ultrasonic_05_type =
    uint16_t;
  _ultrasonic_05_type ultrasonic_05;
  using _ultrasonic_06_type =
    uint16_t;
  _ultrasonic_06_type ultrasonic_06;
  using _ultrasonic_07_type =
    uint16_t;
  _ultrasonic_07_type ultrasonic_07;
  using _ultrasonic_08_type =
    uint16_t;
  _ultrasonic_08_type ultrasonic_08;
  using _ultrasonic_09_type =
    uint16_t;
  _ultrasonic_09_type ultrasonic_09;
  using _ultrasonic_10_type =
    uint16_t;
  _ultrasonic_10_type ultrasonic_10;
  using _ultrasonic_11_type =
    uint16_t;
  _ultrasonic_11_type ultrasonic_11;
  using _ultrasonic_12_type =
    uint16_t;
  _ultrasonic_12_type ultrasonic_12;
  using _ultrasonic_13_type =
    uint16_t;
  _ultrasonic_13_type ultrasonic_13;
  using _ultrasonic_14_type =
    uint16_t;
  _ultrasonic_14_type ultrasonic_14;
  using _ultrasonic_15_type =
    uint16_t;
  _ultrasonic_15_type ultrasonic_15;
  using _ultrasonic_16_type =
    uint16_t;
  _ultrasonic_16_type ultrasonic_16;
  using _ultrasonic_17_type =
    uint16_t;
  _ultrasonic_17_type ultrasonic_17;
  using _ultrasonic_18_type =
    uint16_t;
  _ultrasonic_18_type ultrasonic_18;
  using _ultrasonic_19_type =
    uint16_t;
  _ultrasonic_19_type ultrasonic_19;
  using _ultrasonic_20_type =
    uint16_t;
  _ultrasonic_20_type ultrasonic_20;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__ultrasonic_01(
    const uint16_t & _arg)
  {
    this->ultrasonic_01 = _arg;
    return *this;
  }
  Type & set__ultrasonic_02(
    const uint16_t & _arg)
  {
    this->ultrasonic_02 = _arg;
    return *this;
  }
  Type & set__ultrasonic_03(
    const uint16_t & _arg)
  {
    this->ultrasonic_03 = _arg;
    return *this;
  }
  Type & set__ultrasonic_04(
    const uint16_t & _arg)
  {
    this->ultrasonic_04 = _arg;
    return *this;
  }
  Type & set__ultrasonic_05(
    const uint16_t & _arg)
  {
    this->ultrasonic_05 = _arg;
    return *this;
  }
  Type & set__ultrasonic_06(
    const uint16_t & _arg)
  {
    this->ultrasonic_06 = _arg;
    return *this;
  }
  Type & set__ultrasonic_07(
    const uint16_t & _arg)
  {
    this->ultrasonic_07 = _arg;
    return *this;
  }
  Type & set__ultrasonic_08(
    const uint16_t & _arg)
  {
    this->ultrasonic_08 = _arg;
    return *this;
  }
  Type & set__ultrasonic_09(
    const uint16_t & _arg)
  {
    this->ultrasonic_09 = _arg;
    return *this;
  }
  Type & set__ultrasonic_10(
    const uint16_t & _arg)
  {
    this->ultrasonic_10 = _arg;
    return *this;
  }
  Type & set__ultrasonic_11(
    const uint16_t & _arg)
  {
    this->ultrasonic_11 = _arg;
    return *this;
  }
  Type & set__ultrasonic_12(
    const uint16_t & _arg)
  {
    this->ultrasonic_12 = _arg;
    return *this;
  }
  Type & set__ultrasonic_13(
    const uint16_t & _arg)
  {
    this->ultrasonic_13 = _arg;
    return *this;
  }
  Type & set__ultrasonic_14(
    const uint16_t & _arg)
  {
    this->ultrasonic_14 = _arg;
    return *this;
  }
  Type & set__ultrasonic_15(
    const uint16_t & _arg)
  {
    this->ultrasonic_15 = _arg;
    return *this;
  }
  Type & set__ultrasonic_16(
    const uint16_t & _arg)
  {
    this->ultrasonic_16 = _arg;
    return *this;
  }
  Type & set__ultrasonic_17(
    const uint16_t & _arg)
  {
    this->ultrasonic_17 = _arg;
    return *this;
  }
  Type & set__ultrasonic_18(
    const uint16_t & _arg)
  {
    this->ultrasonic_18 = _arg;
    return *this;
  }
  Type & set__ultrasonic_19(
    const uint16_t & _arg)
  {
    this->ultrasonic_19 = _arg;
    return *this;
  }
  Type & set__ultrasonic_20(
    const uint16_t & _arg)
  {
    this->ultrasonic_20 = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    sensor_driver_msgs::msg::UltrasonicRadar20_<ContainerAllocator> *;
  using ConstRawPtr =
    const sensor_driver_msgs::msg::UltrasonicRadar20_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<sensor_driver_msgs::msg::UltrasonicRadar20_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<sensor_driver_msgs::msg::UltrasonicRadar20_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      sensor_driver_msgs::msg::UltrasonicRadar20_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<sensor_driver_msgs::msg::UltrasonicRadar20_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      sensor_driver_msgs::msg::UltrasonicRadar20_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<sensor_driver_msgs::msg::UltrasonicRadar20_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<sensor_driver_msgs::msg::UltrasonicRadar20_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<sensor_driver_msgs::msg::UltrasonicRadar20_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__sensor_driver_msgs__msg__UltrasonicRadar20
    std::shared_ptr<sensor_driver_msgs::msg::UltrasonicRadar20_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__sensor_driver_msgs__msg__UltrasonicRadar20
    std::shared_ptr<sensor_driver_msgs::msg::UltrasonicRadar20_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const UltrasonicRadar20_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->ultrasonic_01 != other.ultrasonic_01) {
      return false;
    }
    if (this->ultrasonic_02 != other.ultrasonic_02) {
      return false;
    }
    if (this->ultrasonic_03 != other.ultrasonic_03) {
      return false;
    }
    if (this->ultrasonic_04 != other.ultrasonic_04) {
      return false;
    }
    if (this->ultrasonic_05 != other.ultrasonic_05) {
      return false;
    }
    if (this->ultrasonic_06 != other.ultrasonic_06) {
      return false;
    }
    if (this->ultrasonic_07 != other.ultrasonic_07) {
      return false;
    }
    if (this->ultrasonic_08 != other.ultrasonic_08) {
      return false;
    }
    if (this->ultrasonic_09 != other.ultrasonic_09) {
      return false;
    }
    if (this->ultrasonic_10 != other.ultrasonic_10) {
      return false;
    }
    if (this->ultrasonic_11 != other.ultrasonic_11) {
      return false;
    }
    if (this->ultrasonic_12 != other.ultrasonic_12) {
      return false;
    }
    if (this->ultrasonic_13 != other.ultrasonic_13) {
      return false;
    }
    if (this->ultrasonic_14 != other.ultrasonic_14) {
      return false;
    }
    if (this->ultrasonic_15 != other.ultrasonic_15) {
      return false;
    }
    if (this->ultrasonic_16 != other.ultrasonic_16) {
      return false;
    }
    if (this->ultrasonic_17 != other.ultrasonic_17) {
      return false;
    }
    if (this->ultrasonic_18 != other.ultrasonic_18) {
      return false;
    }
    if (this->ultrasonic_19 != other.ultrasonic_19) {
      return false;
    }
    if (this->ultrasonic_20 != other.ultrasonic_20) {
      return false;
    }
    return true;
  }
  bool operator!=(const UltrasonicRadar20_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct UltrasonicRadar20_

// alias to use template instance with default allocator
using UltrasonicRadar20 =
  sensor_driver_msgs::msg::UltrasonicRadar20_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace sensor_driver_msgs

#endif  // SENSOR_DRIVER_MSGS__MSG__DETAIL__ULTRASONIC_RADAR20__STRUCT_HPP_
