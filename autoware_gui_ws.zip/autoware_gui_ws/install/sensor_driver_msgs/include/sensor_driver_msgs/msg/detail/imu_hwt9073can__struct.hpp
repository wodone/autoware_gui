// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from sensor_driver_msgs:msg/ImuHwt9073can.idl
// generated code does not contain a copyright notice

#ifndef SENSOR_DRIVER_MSGS__MSG__DETAIL__IMU_HWT9073CAN__STRUCT_HPP_
#define SENSOR_DRIVER_MSGS__MSG__DETAIL__IMU_HWT9073CAN__STRUCT_HPP_

#include <rosidl_runtime_cpp/bounded_vector.hpp>
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__sensor_driver_msgs__msg__ImuHwt9073can __attribute__((deprecated))
#else
# define DEPRECATED__sensor_driver_msgs__msg__ImuHwt9073can __declspec(deprecated)
#endif

namespace sensor_driver_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ImuHwt9073can_
{
  using Type = ImuHwt9073can_<ContainerAllocator>;

  explicit ImuHwt9073can_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->time_year = 0;
      this->time_month = 0;
      this->time_day = 0;
      this->time_hour = 0;
      this->time_min = 0;
      this->time_sec = 0;
      this->acc_x_raw = 0;
      this->acc_y_raw = 0;
      this->acc_z_raw = 0;
      this->a_vel_x_raw = 0;
      this->a_vel_y_raw = 0;
      this->a_vel_z_raw = 0;
      this->angle_x_raw = 0l;
      this->angle_y_raw = 0l;
      this->angle_z_raw = 0l;
      this->mag_x = 0;
      this->mag_y = 0;
      this->mag_z = 0;
      this->acc_x = 0.0;
      this->acc_y = 0.0;
      this->acc_z = 0.0;
      this->a_vel_x = 0.0;
      this->a_vel_y = 0.0;
      this->a_vel_z = 0.0;
      this->angle_x = 0.0;
      this->angle_y = 0.0;
      this->angle_z = 0.0;
    }
  }

  explicit ImuHwt9073can_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->time_year = 0;
      this->time_month = 0;
      this->time_day = 0;
      this->time_hour = 0;
      this->time_min = 0;
      this->time_sec = 0;
      this->acc_x_raw = 0;
      this->acc_y_raw = 0;
      this->acc_z_raw = 0;
      this->a_vel_x_raw = 0;
      this->a_vel_y_raw = 0;
      this->a_vel_z_raw = 0;
      this->angle_x_raw = 0l;
      this->angle_y_raw = 0l;
      this->angle_z_raw = 0l;
      this->mag_x = 0;
      this->mag_y = 0;
      this->mag_z = 0;
      this->acc_x = 0.0;
      this->acc_y = 0.0;
      this->acc_z = 0.0;
      this->a_vel_x = 0.0;
      this->a_vel_y = 0.0;
      this->a_vel_z = 0.0;
      this->angle_x = 0.0;
      this->angle_y = 0.0;
      this->angle_z = 0.0;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _time_year_type =
    int16_t;
  _time_year_type time_year;
  using _time_month_type =
    int16_t;
  _time_month_type time_month;
  using _time_day_type =
    int16_t;
  _time_day_type time_day;
  using _time_hour_type =
    int16_t;
  _time_hour_type time_hour;
  using _time_min_type =
    int16_t;
  _time_min_type time_min;
  using _time_sec_type =
    int16_t;
  _time_sec_type time_sec;
  using _acc_x_raw_type =
    int16_t;
  _acc_x_raw_type acc_x_raw;
  using _acc_y_raw_type =
    int16_t;
  _acc_y_raw_type acc_y_raw;
  using _acc_z_raw_type =
    int16_t;
  _acc_z_raw_type acc_z_raw;
  using _a_vel_x_raw_type =
    int16_t;
  _a_vel_x_raw_type a_vel_x_raw;
  using _a_vel_y_raw_type =
    int16_t;
  _a_vel_y_raw_type a_vel_y_raw;
  using _a_vel_z_raw_type =
    int16_t;
  _a_vel_z_raw_type a_vel_z_raw;
  using _angle_x_raw_type =
    int32_t;
  _angle_x_raw_type angle_x_raw;
  using _angle_y_raw_type =
    int32_t;
  _angle_y_raw_type angle_y_raw;
  using _angle_z_raw_type =
    int32_t;
  _angle_z_raw_type angle_z_raw;
  using _mag_x_type =
    int16_t;
  _mag_x_type mag_x;
  using _mag_y_type =
    int16_t;
  _mag_y_type mag_y;
  using _mag_z_type =
    int16_t;
  _mag_z_type mag_z;
  using _acc_x_type =
    double;
  _acc_x_type acc_x;
  using _acc_y_type =
    double;
  _acc_y_type acc_y;
  using _acc_z_type =
    double;
  _acc_z_type acc_z;
  using _a_vel_x_type =
    double;
  _a_vel_x_type a_vel_x;
  using _a_vel_y_type =
    double;
  _a_vel_y_type a_vel_y;
  using _a_vel_z_type =
    double;
  _a_vel_z_type a_vel_z;
  using _angle_x_type =
    double;
  _angle_x_type angle_x;
  using _angle_y_type =
    double;
  _angle_y_type angle_y;
  using _angle_z_type =
    double;
  _angle_z_type angle_z;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__time_year(
    const int16_t & _arg)
  {
    this->time_year = _arg;
    return *this;
  }
  Type & set__time_month(
    const int16_t & _arg)
  {
    this->time_month = _arg;
    return *this;
  }
  Type & set__time_day(
    const int16_t & _arg)
  {
    this->time_day = _arg;
    return *this;
  }
  Type & set__time_hour(
    const int16_t & _arg)
  {
    this->time_hour = _arg;
    return *this;
  }
  Type & set__time_min(
    const int16_t & _arg)
  {
    this->time_min = _arg;
    return *this;
  }
  Type & set__time_sec(
    const int16_t & _arg)
  {
    this->time_sec = _arg;
    return *this;
  }
  Type & set__acc_x_raw(
    const int16_t & _arg)
  {
    this->acc_x_raw = _arg;
    return *this;
  }
  Type & set__acc_y_raw(
    const int16_t & _arg)
  {
    this->acc_y_raw = _arg;
    return *this;
  }
  Type & set__acc_z_raw(
    const int16_t & _arg)
  {
    this->acc_z_raw = _arg;
    return *this;
  }
  Type & set__a_vel_x_raw(
    const int16_t & _arg)
  {
    this->a_vel_x_raw = _arg;
    return *this;
  }
  Type & set__a_vel_y_raw(
    const int16_t & _arg)
  {
    this->a_vel_y_raw = _arg;
    return *this;
  }
  Type & set__a_vel_z_raw(
    const int16_t & _arg)
  {
    this->a_vel_z_raw = _arg;
    return *this;
  }
  Type & set__angle_x_raw(
    const int32_t & _arg)
  {
    this->angle_x_raw = _arg;
    return *this;
  }
  Type & set__angle_y_raw(
    const int32_t & _arg)
  {
    this->angle_y_raw = _arg;
    return *this;
  }
  Type & set__angle_z_raw(
    const int32_t & _arg)
  {
    this->angle_z_raw = _arg;
    return *this;
  }
  Type & set__mag_x(
    const int16_t & _arg)
  {
    this->mag_x = _arg;
    return *this;
  }
  Type & set__mag_y(
    const int16_t & _arg)
  {
    this->mag_y = _arg;
    return *this;
  }
  Type & set__mag_z(
    const int16_t & _arg)
  {
    this->mag_z = _arg;
    return *this;
  }
  Type & set__acc_x(
    const double & _arg)
  {
    this->acc_x = _arg;
    return *this;
  }
  Type & set__acc_y(
    const double & _arg)
  {
    this->acc_y = _arg;
    return *this;
  }
  Type & set__acc_z(
    const double & _arg)
  {
    this->acc_z = _arg;
    return *this;
  }
  Type & set__a_vel_x(
    const double & _arg)
  {
    this->a_vel_x = _arg;
    return *this;
  }
  Type & set__a_vel_y(
    const double & _arg)
  {
    this->a_vel_y = _arg;
    return *this;
  }
  Type & set__a_vel_z(
    const double & _arg)
  {
    this->a_vel_z = _arg;
    return *this;
  }
  Type & set__angle_x(
    const double & _arg)
  {
    this->angle_x = _arg;
    return *this;
  }
  Type & set__angle_y(
    const double & _arg)
  {
    this->angle_y = _arg;
    return *this;
  }
  Type & set__angle_z(
    const double & _arg)
  {
    this->angle_z = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    sensor_driver_msgs::msg::ImuHwt9073can_<ContainerAllocator> *;
  using ConstRawPtr =
    const sensor_driver_msgs::msg::ImuHwt9073can_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<sensor_driver_msgs::msg::ImuHwt9073can_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<sensor_driver_msgs::msg::ImuHwt9073can_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      sensor_driver_msgs::msg::ImuHwt9073can_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<sensor_driver_msgs::msg::ImuHwt9073can_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      sensor_driver_msgs::msg::ImuHwt9073can_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<sensor_driver_msgs::msg::ImuHwt9073can_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<sensor_driver_msgs::msg::ImuHwt9073can_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<sensor_driver_msgs::msg::ImuHwt9073can_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__sensor_driver_msgs__msg__ImuHwt9073can
    std::shared_ptr<sensor_driver_msgs::msg::ImuHwt9073can_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__sensor_driver_msgs__msg__ImuHwt9073can
    std::shared_ptr<sensor_driver_msgs::msg::ImuHwt9073can_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ImuHwt9073can_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->time_year != other.time_year) {
      return false;
    }
    if (this->time_month != other.time_month) {
      return false;
    }
    if (this->time_day != other.time_day) {
      return false;
    }
    if (this->time_hour != other.time_hour) {
      return false;
    }
    if (this->time_min != other.time_min) {
      return false;
    }
    if (this->time_sec != other.time_sec) {
      return false;
    }
    if (this->acc_x_raw != other.acc_x_raw) {
      return false;
    }
    if (this->acc_y_raw != other.acc_y_raw) {
      return false;
    }
    if (this->acc_z_raw != other.acc_z_raw) {
      return false;
    }
    if (this->a_vel_x_raw != other.a_vel_x_raw) {
      return false;
    }
    if (this->a_vel_y_raw != other.a_vel_y_raw) {
      return false;
    }
    if (this->a_vel_z_raw != other.a_vel_z_raw) {
      return false;
    }
    if (this->angle_x_raw != other.angle_x_raw) {
      return false;
    }
    if (this->angle_y_raw != other.angle_y_raw) {
      return false;
    }
    if (this->angle_z_raw != other.angle_z_raw) {
      return false;
    }
    if (this->mag_x != other.mag_x) {
      return false;
    }
    if (this->mag_y != other.mag_y) {
      return false;
    }
    if (this->mag_z != other.mag_z) {
      return false;
    }
    if (this->acc_x != other.acc_x) {
      return false;
    }
    if (this->acc_y != other.acc_y) {
      return false;
    }
    if (this->acc_z != other.acc_z) {
      return false;
    }
    if (this->a_vel_x != other.a_vel_x) {
      return false;
    }
    if (this->a_vel_y != other.a_vel_y) {
      return false;
    }
    if (this->a_vel_z != other.a_vel_z) {
      return false;
    }
    if (this->angle_x != other.angle_x) {
      return false;
    }
    if (this->angle_y != other.angle_y) {
      return false;
    }
    if (this->angle_z != other.angle_z) {
      return false;
    }
    return true;
  }
  bool operator!=(const ImuHwt9073can_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ImuHwt9073can_

// alias to use template instance with default allocator
using ImuHwt9073can =
  sensor_driver_msgs::msg::ImuHwt9073can_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace sensor_driver_msgs

#endif  // SENSOR_DRIVER_MSGS__MSG__DETAIL__IMU_HWT9073CAN__STRUCT_HPP_
