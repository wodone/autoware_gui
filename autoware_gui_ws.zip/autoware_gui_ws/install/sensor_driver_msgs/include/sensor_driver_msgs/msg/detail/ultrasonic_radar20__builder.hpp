// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sensor_driver_msgs:msg/UltrasonicRadar20.idl
// generated code does not contain a copyright notice

#ifndef SENSOR_DRIVER_MSGS__MSG__DETAIL__ULTRASONIC_RADAR20__BUILDER_HPP_
#define SENSOR_DRIVER_MSGS__MSG__DETAIL__ULTRASONIC_RADAR20__BUILDER_HPP_

#include "sensor_driver_msgs/msg/detail/ultrasonic_radar20__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace sensor_driver_msgs
{

namespace msg
{

namespace builder
{

class Init_UltrasonicRadar20_ultrasonic_20
{
public:
  explicit Init_UltrasonicRadar20_ultrasonic_20(::sensor_driver_msgs::msg::UltrasonicRadar20 & msg)
  : msg_(msg)
  {}
  ::sensor_driver_msgs::msg::UltrasonicRadar20 ultrasonic_20(::sensor_driver_msgs::msg::UltrasonicRadar20::_ultrasonic_20_type arg)
  {
    msg_.ultrasonic_20 = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sensor_driver_msgs::msg::UltrasonicRadar20 msg_;
};

class Init_UltrasonicRadar20_ultrasonic_19
{
public:
  explicit Init_UltrasonicRadar20_ultrasonic_19(::sensor_driver_msgs::msg::UltrasonicRadar20 & msg)
  : msg_(msg)
  {}
  Init_UltrasonicRadar20_ultrasonic_20 ultrasonic_19(::sensor_driver_msgs::msg::UltrasonicRadar20::_ultrasonic_19_type arg)
  {
    msg_.ultrasonic_19 = std::move(arg);
    return Init_UltrasonicRadar20_ultrasonic_20(msg_);
  }

private:
  ::sensor_driver_msgs::msg::UltrasonicRadar20 msg_;
};

class Init_UltrasonicRadar20_ultrasonic_18
{
public:
  explicit Init_UltrasonicRadar20_ultrasonic_18(::sensor_driver_msgs::msg::UltrasonicRadar20 & msg)
  : msg_(msg)
  {}
  Init_UltrasonicRadar20_ultrasonic_19 ultrasonic_18(::sensor_driver_msgs::msg::UltrasonicRadar20::_ultrasonic_18_type arg)
  {
    msg_.ultrasonic_18 = std::move(arg);
    return Init_UltrasonicRadar20_ultrasonic_19(msg_);
  }

private:
  ::sensor_driver_msgs::msg::UltrasonicRadar20 msg_;
};

class Init_UltrasonicRadar20_ultrasonic_17
{
public:
  explicit Init_UltrasonicRadar20_ultrasonic_17(::sensor_driver_msgs::msg::UltrasonicRadar20 & msg)
  : msg_(msg)
  {}
  Init_UltrasonicRadar20_ultrasonic_18 ultrasonic_17(::sensor_driver_msgs::msg::UltrasonicRadar20::_ultrasonic_17_type arg)
  {
    msg_.ultrasonic_17 = std::move(arg);
    return Init_UltrasonicRadar20_ultrasonic_18(msg_);
  }

private:
  ::sensor_driver_msgs::msg::UltrasonicRadar20 msg_;
};

class Init_UltrasonicRadar20_ultrasonic_16
{
public:
  explicit Init_UltrasonicRadar20_ultrasonic_16(::sensor_driver_msgs::msg::UltrasonicRadar20 & msg)
  : msg_(msg)
  {}
  Init_UltrasonicRadar20_ultrasonic_17 ultrasonic_16(::sensor_driver_msgs::msg::UltrasonicRadar20::_ultrasonic_16_type arg)
  {
    msg_.ultrasonic_16 = std::move(arg);
    return Init_UltrasonicRadar20_ultrasonic_17(msg_);
  }

private:
  ::sensor_driver_msgs::msg::UltrasonicRadar20 msg_;
};

class Init_UltrasonicRadar20_ultrasonic_15
{
public:
  explicit Init_UltrasonicRadar20_ultrasonic_15(::sensor_driver_msgs::msg::UltrasonicRadar20 & msg)
  : msg_(msg)
  {}
  Init_UltrasonicRadar20_ultrasonic_16 ultrasonic_15(::sensor_driver_msgs::msg::UltrasonicRadar20::_ultrasonic_15_type arg)
  {
    msg_.ultrasonic_15 = std::move(arg);
    return Init_UltrasonicRadar20_ultrasonic_16(msg_);
  }

private:
  ::sensor_driver_msgs::msg::UltrasonicRadar20 msg_;
};

class Init_UltrasonicRadar20_ultrasonic_14
{
public:
  explicit Init_UltrasonicRadar20_ultrasonic_14(::sensor_driver_msgs::msg::UltrasonicRadar20 & msg)
  : msg_(msg)
  {}
  Init_UltrasonicRadar20_ultrasonic_15 ultrasonic_14(::sensor_driver_msgs::msg::UltrasonicRadar20::_ultrasonic_14_type arg)
  {
    msg_.ultrasonic_14 = std::move(arg);
    return Init_UltrasonicRadar20_ultrasonic_15(msg_);
  }

private:
  ::sensor_driver_msgs::msg::UltrasonicRadar20 msg_;
};

class Init_UltrasonicRadar20_ultrasonic_13
{
public:
  explicit Init_UltrasonicRadar20_ultrasonic_13(::sensor_driver_msgs::msg::UltrasonicRadar20 & msg)
  : msg_(msg)
  {}
  Init_UltrasonicRadar20_ultrasonic_14 ultrasonic_13(::sensor_driver_msgs::msg::UltrasonicRadar20::_ultrasonic_13_type arg)
  {
    msg_.ultrasonic_13 = std::move(arg);
    return Init_UltrasonicRadar20_ultrasonic_14(msg_);
  }

private:
  ::sensor_driver_msgs::msg::UltrasonicRadar20 msg_;
};

class Init_UltrasonicRadar20_ultrasonic_12
{
public:
  explicit Init_UltrasonicRadar20_ultrasonic_12(::sensor_driver_msgs::msg::UltrasonicRadar20 & msg)
  : msg_(msg)
  {}
  Init_UltrasonicRadar20_ultrasonic_13 ultrasonic_12(::sensor_driver_msgs::msg::UltrasonicRadar20::_ultrasonic_12_type arg)
  {
    msg_.ultrasonic_12 = std::move(arg);
    return Init_UltrasonicRadar20_ultrasonic_13(msg_);
  }

private:
  ::sensor_driver_msgs::msg::UltrasonicRadar20 msg_;
};

class Init_UltrasonicRadar20_ultrasonic_11
{
public:
  explicit Init_UltrasonicRadar20_ultrasonic_11(::sensor_driver_msgs::msg::UltrasonicRadar20 & msg)
  : msg_(msg)
  {}
  Init_UltrasonicRadar20_ultrasonic_12 ultrasonic_11(::sensor_driver_msgs::msg::UltrasonicRadar20::_ultrasonic_11_type arg)
  {
    msg_.ultrasonic_11 = std::move(arg);
    return Init_UltrasonicRadar20_ultrasonic_12(msg_);
  }

private:
  ::sensor_driver_msgs::msg::UltrasonicRadar20 msg_;
};

class Init_UltrasonicRadar20_ultrasonic_10
{
public:
  explicit Init_UltrasonicRadar20_ultrasonic_10(::sensor_driver_msgs::msg::UltrasonicRadar20 & msg)
  : msg_(msg)
  {}
  Init_UltrasonicRadar20_ultrasonic_11 ultrasonic_10(::sensor_driver_msgs::msg::UltrasonicRadar20::_ultrasonic_10_type arg)
  {
    msg_.ultrasonic_10 = std::move(arg);
    return Init_UltrasonicRadar20_ultrasonic_11(msg_);
  }

private:
  ::sensor_driver_msgs::msg::UltrasonicRadar20 msg_;
};

class Init_UltrasonicRadar20_ultrasonic_09
{
public:
  explicit Init_UltrasonicRadar20_ultrasonic_09(::sensor_driver_msgs::msg::UltrasonicRadar20 & msg)
  : msg_(msg)
  {}
  Init_UltrasonicRadar20_ultrasonic_10 ultrasonic_09(::sensor_driver_msgs::msg::UltrasonicRadar20::_ultrasonic_09_type arg)
  {
    msg_.ultrasonic_09 = std::move(arg);
    return Init_UltrasonicRadar20_ultrasonic_10(msg_);
  }

private:
  ::sensor_driver_msgs::msg::UltrasonicRadar20 msg_;
};

class Init_UltrasonicRadar20_ultrasonic_08
{
public:
  explicit Init_UltrasonicRadar20_ultrasonic_08(::sensor_driver_msgs::msg::UltrasonicRadar20 & msg)
  : msg_(msg)
  {}
  Init_UltrasonicRadar20_ultrasonic_09 ultrasonic_08(::sensor_driver_msgs::msg::UltrasonicRadar20::_ultrasonic_08_type arg)
  {
    msg_.ultrasonic_08 = std::move(arg);
    return Init_UltrasonicRadar20_ultrasonic_09(msg_);
  }

private:
  ::sensor_driver_msgs::msg::UltrasonicRadar20 msg_;
};

class Init_UltrasonicRadar20_ultrasonic_07
{
public:
  explicit Init_UltrasonicRadar20_ultrasonic_07(::sensor_driver_msgs::msg::UltrasonicRadar20 & msg)
  : msg_(msg)
  {}
  Init_UltrasonicRadar20_ultrasonic_08 ultrasonic_07(::sensor_driver_msgs::msg::UltrasonicRadar20::_ultrasonic_07_type arg)
  {
    msg_.ultrasonic_07 = std::move(arg);
    return Init_UltrasonicRadar20_ultrasonic_08(msg_);
  }

private:
  ::sensor_driver_msgs::msg::UltrasonicRadar20 msg_;
};

class Init_UltrasonicRadar20_ultrasonic_06
{
public:
  explicit Init_UltrasonicRadar20_ultrasonic_06(::sensor_driver_msgs::msg::UltrasonicRadar20 & msg)
  : msg_(msg)
  {}
  Init_UltrasonicRadar20_ultrasonic_07 ultrasonic_06(::sensor_driver_msgs::msg::UltrasonicRadar20::_ultrasonic_06_type arg)
  {
    msg_.ultrasonic_06 = std::move(arg);
    return Init_UltrasonicRadar20_ultrasonic_07(msg_);
  }

private:
  ::sensor_driver_msgs::msg::UltrasonicRadar20 msg_;
};

class Init_UltrasonicRadar20_ultrasonic_05
{
public:
  explicit Init_UltrasonicRadar20_ultrasonic_05(::sensor_driver_msgs::msg::UltrasonicRadar20 & msg)
  : msg_(msg)
  {}
  Init_UltrasonicRadar20_ultrasonic_06 ultrasonic_05(::sensor_driver_msgs::msg::UltrasonicRadar20::_ultrasonic_05_type arg)
  {
    msg_.ultrasonic_05 = std::move(arg);
    return Init_UltrasonicRadar20_ultrasonic_06(msg_);
  }

private:
  ::sensor_driver_msgs::msg::UltrasonicRadar20 msg_;
};

class Init_UltrasonicRadar20_ultrasonic_04
{
public:
  explicit Init_UltrasonicRadar20_ultrasonic_04(::sensor_driver_msgs::msg::UltrasonicRadar20 & msg)
  : msg_(msg)
  {}
  Init_UltrasonicRadar20_ultrasonic_05 ultrasonic_04(::sensor_driver_msgs::msg::UltrasonicRadar20::_ultrasonic_04_type arg)
  {
    msg_.ultrasonic_04 = std::move(arg);
    return Init_UltrasonicRadar20_ultrasonic_05(msg_);
  }

private:
  ::sensor_driver_msgs::msg::UltrasonicRadar20 msg_;
};

class Init_UltrasonicRadar20_ultrasonic_03
{
public:
  explicit Init_UltrasonicRadar20_ultrasonic_03(::sensor_driver_msgs::msg::UltrasonicRadar20 & msg)
  : msg_(msg)
  {}
  Init_UltrasonicRadar20_ultrasonic_04 ultrasonic_03(::sensor_driver_msgs::msg::UltrasonicRadar20::_ultrasonic_03_type arg)
  {
    msg_.ultrasonic_03 = std::move(arg);
    return Init_UltrasonicRadar20_ultrasonic_04(msg_);
  }

private:
  ::sensor_driver_msgs::msg::UltrasonicRadar20 msg_;
};

class Init_UltrasonicRadar20_ultrasonic_02
{
public:
  explicit Init_UltrasonicRadar20_ultrasonic_02(::sensor_driver_msgs::msg::UltrasonicRadar20 & msg)
  : msg_(msg)
  {}
  Init_UltrasonicRadar20_ultrasonic_03 ultrasonic_02(::sensor_driver_msgs::msg::UltrasonicRadar20::_ultrasonic_02_type arg)
  {
    msg_.ultrasonic_02 = std::move(arg);
    return Init_UltrasonicRadar20_ultrasonic_03(msg_);
  }

private:
  ::sensor_driver_msgs::msg::UltrasonicRadar20 msg_;
};

class Init_UltrasonicRadar20_ultrasonic_01
{
public:
  explicit Init_UltrasonicRadar20_ultrasonic_01(::sensor_driver_msgs::msg::UltrasonicRadar20 & msg)
  : msg_(msg)
  {}
  Init_UltrasonicRadar20_ultrasonic_02 ultrasonic_01(::sensor_driver_msgs::msg::UltrasonicRadar20::_ultrasonic_01_type arg)
  {
    msg_.ultrasonic_01 = std::move(arg);
    return Init_UltrasonicRadar20_ultrasonic_02(msg_);
  }

private:
  ::sensor_driver_msgs::msg::UltrasonicRadar20 msg_;
};

class Init_UltrasonicRadar20_header
{
public:
  Init_UltrasonicRadar20_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_UltrasonicRadar20_ultrasonic_01 header(::sensor_driver_msgs::msg::UltrasonicRadar20::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_UltrasonicRadar20_ultrasonic_01(msg_);
  }

private:
  ::sensor_driver_msgs::msg::UltrasonicRadar20 msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sensor_driver_msgs::msg::UltrasonicRadar20>()
{
  return sensor_driver_msgs::msg::builder::Init_UltrasonicRadar20_header();
}

}  // namespace sensor_driver_msgs

#endif  // SENSOR_DRIVER_MSGS__MSG__DETAIL__ULTRASONIC_RADAR20__BUILDER_HPP_
