// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sensor_driver_msgs:msg/GnssPashr.idl
// generated code does not contain a copyright notice

#ifndef SENSOR_DRIVER_MSGS__MSG__DETAIL__GNSS_PASHR__BUILDER_HPP_
#define SENSOR_DRIVER_MSGS__MSG__DETAIL__GNSS_PASHR__BUILDER_HPP_

#include "sensor_driver_msgs/msg/detail/gnss_pashr__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace sensor_driver_msgs
{

namespace msg
{

namespace builder
{

class Init_GnssPashr_cs
{
public:
  explicit Init_GnssPashr_cs(::sensor_driver_msgs::msg::GnssPashr & msg)
  : msg_(msg)
  {}
  ::sensor_driver_msgs::msg::GnssPashr cs(::sensor_driver_msgs::msg::GnssPashr::_cs_type arg)
  {
    msg_.cs = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssPashr msg_;
};

class Init_GnssPashr_state
{
public:
  explicit Init_GnssPashr_state(::sensor_driver_msgs::msg::GnssPashr & msg)
  : msg_(msg)
  {}
  Init_GnssPashr_cs state(::sensor_driver_msgs::msg::GnssPashr::_state_type arg)
  {
    msg_.state = std::move(arg);
    return Init_GnssPashr_cs(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssPashr msg_;
};

class Init_GnssPashr_yaw_std
{
public:
  explicit Init_GnssPashr_yaw_std(::sensor_driver_msgs::msg::GnssPashr & msg)
  : msg_(msg)
  {}
  Init_GnssPashr_state yaw_std(::sensor_driver_msgs::msg::GnssPashr::_yaw_std_type arg)
  {
    msg_.yaw_std = std::move(arg);
    return Init_GnssPashr_state(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssPashr msg_;
};

class Init_GnssPashr_pitch_std
{
public:
  explicit Init_GnssPashr_pitch_std(::sensor_driver_msgs::msg::GnssPashr & msg)
  : msg_(msg)
  {}
  Init_GnssPashr_yaw_std pitch_std(::sensor_driver_msgs::msg::GnssPashr::_pitch_std_type arg)
  {
    msg_.pitch_std = std::move(arg);
    return Init_GnssPashr_yaw_std(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssPashr msg_;
};

class Init_GnssPashr_roll_std
{
public:
  explicit Init_GnssPashr_roll_std(::sensor_driver_msgs::msg::GnssPashr & msg)
  : msg_(msg)
  {}
  Init_GnssPashr_pitch_std roll_std(::sensor_driver_msgs::msg::GnssPashr::_roll_std_type arg)
  {
    msg_.roll_std = std::move(arg);
    return Init_GnssPashr_pitch_std(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssPashr msg_;
};

class Init_GnssPashr_height_error
{
public:
  explicit Init_GnssPashr_height_error(::sensor_driver_msgs::msg::GnssPashr & msg)
  : msg_(msg)
  {}
  Init_GnssPashr_roll_std height_error(::sensor_driver_msgs::msg::GnssPashr::_height_error_type arg)
  {
    msg_.height_error = std::move(arg);
    return Init_GnssPashr_roll_std(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssPashr msg_;
};

class Init_GnssPashr_pitch
{
public:
  explicit Init_GnssPashr_pitch(::sensor_driver_msgs::msg::GnssPashr & msg)
  : msg_(msg)
  {}
  Init_GnssPashr_height_error pitch(::sensor_driver_msgs::msg::GnssPashr::_pitch_type arg)
  {
    msg_.pitch = std::move(arg);
    return Init_GnssPashr_height_error(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssPashr msg_;
};

class Init_GnssPashr_roll
{
public:
  explicit Init_GnssPashr_roll(::sensor_driver_msgs::msg::GnssPashr & msg)
  : msg_(msg)
  {}
  Init_GnssPashr_pitch roll(::sensor_driver_msgs::msg::GnssPashr::_roll_type arg)
  {
    msg_.roll = std::move(arg);
    return Init_GnssPashr_pitch(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssPashr msg_;
};

class Init_GnssPashr_t_sign
{
public:
  explicit Init_GnssPashr_t_sign(::sensor_driver_msgs::msg::GnssPashr & msg)
  : msg_(msg)
  {}
  Init_GnssPashr_roll t_sign(::sensor_driver_msgs::msg::GnssPashr::_t_sign_type arg)
  {
    msg_.t_sign = std::move(arg);
    return Init_GnssPashr_roll(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssPashr msg_;
};

class Init_GnssPashr_yaw
{
public:
  explicit Init_GnssPashr_yaw(::sensor_driver_msgs::msg::GnssPashr & msg)
  : msg_(msg)
  {}
  Init_GnssPashr_t_sign yaw(::sensor_driver_msgs::msg::GnssPashr::_yaw_type arg)
  {
    msg_.yaw = std::move(arg);
    return Init_GnssPashr_t_sign(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssPashr msg_;
};

class Init_GnssPashr_utc_time
{
public:
  explicit Init_GnssPashr_utc_time(::sensor_driver_msgs::msg::GnssPashr & msg)
  : msg_(msg)
  {}
  Init_GnssPashr_yaw utc_time(::sensor_driver_msgs::msg::GnssPashr::_utc_time_type arg)
  {
    msg_.utc_time = std::move(arg);
    return Init_GnssPashr_yaw(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssPashr msg_;
};

class Init_GnssPashr_data_id
{
public:
  explicit Init_GnssPashr_data_id(::sensor_driver_msgs::msg::GnssPashr & msg)
  : msg_(msg)
  {}
  Init_GnssPashr_utc_time data_id(::sensor_driver_msgs::msg::GnssPashr::_data_id_type arg)
  {
    msg_.data_id = std::move(arg);
    return Init_GnssPashr_utc_time(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssPashr msg_;
};

class Init_GnssPashr_header
{
public:
  Init_GnssPashr_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_GnssPashr_data_id header(::sensor_driver_msgs::msg::GnssPashr::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_GnssPashr_data_id(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssPashr msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sensor_driver_msgs::msg::GnssPashr>()
{
  return sensor_driver_msgs::msg::builder::Init_GnssPashr_header();
}

}  // namespace sensor_driver_msgs

#endif  // SENSOR_DRIVER_MSGS__MSG__DETAIL__GNSS_PASHR__BUILDER_HPP_
