// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sensor_driver_msgs:msg/ChassisCanRecived.idl
// generated code does not contain a copyright notice

#ifndef SENSOR_DRIVER_MSGS__MSG__DETAIL__CHASSIS_CAN_RECIVED__BUILDER_HPP_
#define SENSOR_DRIVER_MSGS__MSG__DETAIL__CHASSIS_CAN_RECIVED__BUILDER_HPP_

#include "sensor_driver_msgs/msg/detail/chassis_can_recived__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace sensor_driver_msgs
{

namespace msg
{

namespace builder
{

class Init_ChassisCanRecived_bmsidu_fdbk_busa
{
public:
  explicit Init_ChassisCanRecived_bmsidu_fdbk_busa(::sensor_driver_msgs::msg::ChassisCanRecived & msg)
  : msg_(msg)
  {}
  ::sensor_driver_msgs::msg::ChassisCanRecived bmsidu_fdbk_busa(::sensor_driver_msgs::msg::ChassisCanRecived::_bmsidu_fdbk_busa_type arg)
  {
    msg_.bmsidu_fdbk_busa = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanRecived msg_;
};

class Init_ChassisCanRecived_ehbidu_fdbk_realdece
{
public:
  explicit Init_ChassisCanRecived_ehbidu_fdbk_realdece(::sensor_driver_msgs::msg::ChassisCanRecived & msg)
  : msg_(msg)
  {}
  Init_ChassisCanRecived_bmsidu_fdbk_busa ehbidu_fdbk_realdece(::sensor_driver_msgs::msg::ChassisCanRecived::_ehbidu_fdbk_realdece_type arg)
  {
    msg_.ehbidu_fdbk_realdece = std::move(arg);
    return Init_ChassisCanRecived_bmsidu_fdbk_busa(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanRecived msg_;
};

class Init_ChassisCanRecived_epsidu_fdbk_realangle
{
public:
  explicit Init_ChassisCanRecived_epsidu_fdbk_realangle(::sensor_driver_msgs::msg::ChassisCanRecived & msg)
  : msg_(msg)
  {}
  Init_ChassisCanRecived_ehbidu_fdbk_realdece epsidu_fdbk_realangle(::sensor_driver_msgs::msg::ChassisCanRecived::_epsidu_fdbk_realangle_type arg)
  {
    msg_.epsidu_fdbk_realangle = std::move(arg);
    return Init_ChassisCanRecived_ehbidu_fdbk_realdece(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanRecived msg_;
};

class Init_ChassisCanRecived_mcuidu_fdbk_realacc
{
public:
  explicit Init_ChassisCanRecived_mcuidu_fdbk_realacc(::sensor_driver_msgs::msg::ChassisCanRecived & msg)
  : msg_(msg)
  {}
  Init_ChassisCanRecived_epsidu_fdbk_realangle mcuidu_fdbk_realacc(::sensor_driver_msgs::msg::ChassisCanRecived::_mcuidu_fdbk_realacc_type arg)
  {
    msg_.mcuidu_fdbk_realacc = std::move(arg);
    return Init_ChassisCanRecived_epsidu_fdbk_realangle(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanRecived msg_;
};

class Init_ChassisCanRecived_mcuidu_fdbk_realsped
{
public:
  explicit Init_ChassisCanRecived_mcuidu_fdbk_realsped(::sensor_driver_msgs::msg::ChassisCanRecived & msg)
  : msg_(msg)
  {}
  Init_ChassisCanRecived_mcuidu_fdbk_realacc mcuidu_fdbk_realsped(::sensor_driver_msgs::msg::ChassisCanRecived::_mcuidu_fdbk_realsped_type arg)
  {
    msg_.mcuidu_fdbk_realsped = std::move(arg);
    return Init_ChassisCanRecived_mcuidu_fdbk_realacc(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanRecived msg_;
};

class Init_ChassisCanRecived_bcmidu_fdbk_doubleflash
{
public:
  explicit Init_ChassisCanRecived_bcmidu_fdbk_doubleflash(::sensor_driver_msgs::msg::ChassisCanRecived & msg)
  : msg_(msg)
  {}
  Init_ChassisCanRecived_mcuidu_fdbk_realsped bcmidu_fdbk_doubleflash(::sensor_driver_msgs::msg::ChassisCanRecived::_bcmidu_fdbk_doubleflash_type arg)
  {
    msg_.bcmidu_fdbk_doubleflash = std::move(arg);
    return Init_ChassisCanRecived_mcuidu_fdbk_realsped(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanRecived msg_;
};

class Init_ChassisCanRecived_bcmidu_fdbk_voice
{
public:
  explicit Init_ChassisCanRecived_bcmidu_fdbk_voice(::sensor_driver_msgs::msg::ChassisCanRecived & msg)
  : msg_(msg)
  {}
  Init_ChassisCanRecived_bcmidu_fdbk_doubleflash bcmidu_fdbk_voice(::sensor_driver_msgs::msg::ChassisCanRecived::_bcmidu_fdbk_voice_type arg)
  {
    msg_.bcmidu_fdbk_voice = std::move(arg);
    return Init_ChassisCanRecived_bcmidu_fdbk_doubleflash(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanRecived msg_;
};

class Init_ChassisCanRecived_bcmidu_fdbk_siren
{
public:
  explicit Init_ChassisCanRecived_bcmidu_fdbk_siren(::sensor_driver_msgs::msg::ChassisCanRecived & msg)
  : msg_(msg)
  {}
  Init_ChassisCanRecived_bcmidu_fdbk_voice bcmidu_fdbk_siren(::sensor_driver_msgs::msg::ChassisCanRecived::_bcmidu_fdbk_siren_type arg)
  {
    msg_.bcmidu_fdbk_siren = std::move(arg);
    return Init_ChassisCanRecived_bcmidu_fdbk_voice(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanRecived msg_;
};

class Init_ChassisCanRecived_bcmidu_fdbk_brakelight
{
public:
  explicit Init_ChassisCanRecived_bcmidu_fdbk_brakelight(::sensor_driver_msgs::msg::ChassisCanRecived & msg)
  : msg_(msg)
  {}
  Init_ChassisCanRecived_bcmidu_fdbk_siren bcmidu_fdbk_brakelight(::sensor_driver_msgs::msg::ChassisCanRecived::_bcmidu_fdbk_brakelight_type arg)
  {
    msg_.bcmidu_fdbk_brakelight = std::move(arg);
    return Init_ChassisCanRecived_bcmidu_fdbk_siren(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanRecived msg_;
};

class Init_ChassisCanRecived_bcmidu_fdbk_backlight
{
public:
  explicit Init_ChassisCanRecived_bcmidu_fdbk_backlight(::sensor_driver_msgs::msg::ChassisCanRecived & msg)
  : msg_(msg)
  {}
  Init_ChassisCanRecived_bcmidu_fdbk_brakelight bcmidu_fdbk_backlight(::sensor_driver_msgs::msg::ChassisCanRecived::_bcmidu_fdbk_backlight_type arg)
  {
    msg_.bcmidu_fdbk_backlight = std::move(arg);
    return Init_ChassisCanRecived_bcmidu_fdbk_brakelight(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanRecived msg_;
};

class Init_ChassisCanRecived_bcmidu_fdbk_turnflash
{
public:
  explicit Init_ChassisCanRecived_bcmidu_fdbk_turnflash(::sensor_driver_msgs::msg::ChassisCanRecived & msg)
  : msg_(msg)
  {}
  Init_ChassisCanRecived_bcmidu_fdbk_backlight bcmidu_fdbk_turnflash(::sensor_driver_msgs::msg::ChassisCanRecived::_bcmidu_fdbk_turnflash_type arg)
  {
    msg_.bcmidu_fdbk_turnflash = std::move(arg);
    return Init_ChassisCanRecived_bcmidu_fdbk_backlight(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanRecived msg_;
};

class Init_ChassisCanRecived_bcmidu_fdbk_headlight
{
public:
  explicit Init_ChassisCanRecived_bcmidu_fdbk_headlight(::sensor_driver_msgs::msg::ChassisCanRecived & msg)
  : msg_(msg)
  {}
  Init_ChassisCanRecived_bcmidu_fdbk_turnflash bcmidu_fdbk_headlight(::sensor_driver_msgs::msg::ChassisCanRecived::_bcmidu_fdbk_headlight_type arg)
  {
    msg_.bcmidu_fdbk_headlight = std::move(arg);
    return Init_ChassisCanRecived_bcmidu_fdbk_turnflash(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanRecived msg_;
};

class Init_ChassisCanRecived_bmsidu_fdbk_fault
{
public:
  explicit Init_ChassisCanRecived_bmsidu_fdbk_fault(::sensor_driver_msgs::msg::ChassisCanRecived & msg)
  : msg_(msg)
  {}
  Init_ChassisCanRecived_bcmidu_fdbk_headlight bmsidu_fdbk_fault(::sensor_driver_msgs::msg::ChassisCanRecived::_bmsidu_fdbk_fault_type arg)
  {
    msg_.bmsidu_fdbk_fault = std::move(arg);
    return Init_ChassisCanRecived_bcmidu_fdbk_headlight(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanRecived msg_;
};

class Init_ChassisCanRecived_bmsidu_fdbk_errolevel
{
public:
  explicit Init_ChassisCanRecived_bmsidu_fdbk_errolevel(::sensor_driver_msgs::msg::ChassisCanRecived & msg)
  : msg_(msg)
  {}
  Init_ChassisCanRecived_bmsidu_fdbk_fault bmsidu_fdbk_errolevel(::sensor_driver_msgs::msg::ChassisCanRecived::_bmsidu_fdbk_errolevel_type arg)
  {
    msg_.bmsidu_fdbk_errolevel = std::move(arg);
    return Init_ChassisCanRecived_bmsidu_fdbk_fault(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanRecived msg_;
};

class Init_ChassisCanRecived_bmsidu_fdbk_busv
{
public:
  explicit Init_ChassisCanRecived_bmsidu_fdbk_busv(::sensor_driver_msgs::msg::ChassisCanRecived & msg)
  : msg_(msg)
  {}
  Init_ChassisCanRecived_bmsidu_fdbk_errolevel bmsidu_fdbk_busv(::sensor_driver_msgs::msg::ChassisCanRecived::_bmsidu_fdbk_busv_type arg)
  {
    msg_.bmsidu_fdbk_busv = std::move(arg);
    return Init_ChassisCanRecived_bmsidu_fdbk_errolevel(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanRecived msg_;
};

class Init_ChassisCanRecived_bmsidu_fdbk_soc
{
public:
  explicit Init_ChassisCanRecived_bmsidu_fdbk_soc(::sensor_driver_msgs::msg::ChassisCanRecived & msg)
  : msg_(msg)
  {}
  Init_ChassisCanRecived_bmsidu_fdbk_busv bmsidu_fdbk_soc(::sensor_driver_msgs::msg::ChassisCanRecived::_bmsidu_fdbk_soc_type arg)
  {
    msg_.bmsidu_fdbk_soc = std::move(arg);
    return Init_ChassisCanRecived_bmsidu_fdbk_busv(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanRecived msg_;
};

class Init_ChassisCanRecived_bmsidu_fdbk_chcsta
{
public:
  explicit Init_ChassisCanRecived_bmsidu_fdbk_chcsta(::sensor_driver_msgs::msg::ChassisCanRecived & msg)
  : msg_(msg)
  {}
  Init_ChassisCanRecived_bmsidu_fdbk_soc bmsidu_fdbk_chcsta(::sensor_driver_msgs::msg::ChassisCanRecived::_bmsidu_fdbk_chcsta_type arg)
  {
    msg_.bmsidu_fdbk_chcsta = std::move(arg);
    return Init_ChassisCanRecived_bmsidu_fdbk_soc(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanRecived msg_;
};

class Init_ChassisCanRecived_ehbidu_fdbk_fault
{
public:
  explicit Init_ChassisCanRecived_ehbidu_fdbk_fault(::sensor_driver_msgs::msg::ChassisCanRecived & msg)
  : msg_(msg)
  {}
  Init_ChassisCanRecived_bmsidu_fdbk_chcsta ehbidu_fdbk_fault(::sensor_driver_msgs::msg::ChassisCanRecived::_ehbidu_fdbk_fault_type arg)
  {
    msg_.ehbidu_fdbk_fault = std::move(arg);
    return Init_ChassisCanRecived_bmsidu_fdbk_chcsta(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanRecived msg_;
};

class Init_ChassisCanRecived_ehbidu_fdbk_errolevel
{
public:
  explicit Init_ChassisCanRecived_ehbidu_fdbk_errolevel(::sensor_driver_msgs::msg::ChassisCanRecived & msg)
  : msg_(msg)
  {}
  Init_ChassisCanRecived_ehbidu_fdbk_fault ehbidu_fdbk_errolevel(::sensor_driver_msgs::msg::ChassisCanRecived::_ehbidu_fdbk_errolevel_type arg)
  {
    msg_.ehbidu_fdbk_errolevel = std::move(arg);
    return Init_ChassisCanRecived_ehbidu_fdbk_fault(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanRecived msg_;
};

class Init_ChassisCanRecived_ehbidu_fdbk_realpressure
{
public:
  explicit Init_ChassisCanRecived_ehbidu_fdbk_realpressure(::sensor_driver_msgs::msg::ChassisCanRecived & msg)
  : msg_(msg)
  {}
  Init_ChassisCanRecived_ehbidu_fdbk_errolevel ehbidu_fdbk_realpressure(::sensor_driver_msgs::msg::ChassisCanRecived::_ehbidu_fdbk_realpressure_type arg)
  {
    msg_.ehbidu_fdbk_realpressure = std::move(arg);
    return Init_ChassisCanRecived_ehbidu_fdbk_errolevel(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanRecived msg_;
};

class Init_ChassisCanRecived_epsidu_fdbk_fault
{
public:
  explicit Init_ChassisCanRecived_epsidu_fdbk_fault(::sensor_driver_msgs::msg::ChassisCanRecived & msg)
  : msg_(msg)
  {}
  Init_ChassisCanRecived_ehbidu_fdbk_realpressure epsidu_fdbk_fault(::sensor_driver_msgs::msg::ChassisCanRecived::_epsidu_fdbk_fault_type arg)
  {
    msg_.epsidu_fdbk_fault = std::move(arg);
    return Init_ChassisCanRecived_ehbidu_fdbk_realpressure(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanRecived msg_;
};

class Init_ChassisCanRecived_epsidu_fdbk_errolevel
{
public:
  explicit Init_ChassisCanRecived_epsidu_fdbk_errolevel(::sensor_driver_msgs::msg::ChassisCanRecived & msg)
  : msg_(msg)
  {}
  Init_ChassisCanRecived_epsidu_fdbk_fault epsidu_fdbk_errolevel(::sensor_driver_msgs::msg::ChassisCanRecived::_epsidu_fdbk_errolevel_type arg)
  {
    msg_.epsidu_fdbk_errolevel = std::move(arg);
    return Init_ChassisCanRecived_epsidu_fdbk_fault(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanRecived msg_;
};

class Init_ChassisCanRecived_epsidu_fdbk_worksta
{
public:
  explicit Init_ChassisCanRecived_epsidu_fdbk_worksta(::sensor_driver_msgs::msg::ChassisCanRecived & msg)
  : msg_(msg)
  {}
  Init_ChassisCanRecived_epsidu_fdbk_errolevel epsidu_fdbk_worksta(::sensor_driver_msgs::msg::ChassisCanRecived::_epsidu_fdbk_worksta_type arg)
  {
    msg_.epsidu_fdbk_worksta = std::move(arg);
    return Init_ChassisCanRecived_epsidu_fdbk_errolevel(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanRecived msg_;
};

class Init_ChassisCanRecived_epbidu_fdbk_fault
{
public:
  explicit Init_ChassisCanRecived_epbidu_fdbk_fault(::sensor_driver_msgs::msg::ChassisCanRecived & msg)
  : msg_(msg)
  {}
  Init_ChassisCanRecived_epsidu_fdbk_worksta epbidu_fdbk_fault(::sensor_driver_msgs::msg::ChassisCanRecived::_epbidu_fdbk_fault_type arg)
  {
    msg_.epbidu_fdbk_fault = std::move(arg);
    return Init_ChassisCanRecived_epsidu_fdbk_worksta(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanRecived msg_;
};

class Init_ChassisCanRecived_epbidu_fdbk_errolevel
{
public:
  explicit Init_ChassisCanRecived_epbidu_fdbk_errolevel(::sensor_driver_msgs::msg::ChassisCanRecived & msg)
  : msg_(msg)
  {}
  Init_ChassisCanRecived_epbidu_fdbk_fault epbidu_fdbk_errolevel(::sensor_driver_msgs::msg::ChassisCanRecived::_epbidu_fdbk_errolevel_type arg)
  {
    msg_.epbidu_fdbk_errolevel = std::move(arg);
    return Init_ChassisCanRecived_epbidu_fdbk_fault(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanRecived msg_;
};

class Init_ChassisCanRecived_epbidu_fdbk_parksta
{
public:
  explicit Init_ChassisCanRecived_epbidu_fdbk_parksta(::sensor_driver_msgs::msg::ChassisCanRecived & msg)
  : msg_(msg)
  {}
  Init_ChassisCanRecived_epbidu_fdbk_errolevel epbidu_fdbk_parksta(::sensor_driver_msgs::msg::ChassisCanRecived::_epbidu_fdbk_parksta_type arg)
  {
    msg_.epbidu_fdbk_parksta = std::move(arg);
    return Init_ChassisCanRecived_epbidu_fdbk_errolevel(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanRecived msg_;
};

class Init_ChassisCanRecived_mcuidu_fdbk_fault
{
public:
  explicit Init_ChassisCanRecived_mcuidu_fdbk_fault(::sensor_driver_msgs::msg::ChassisCanRecived & msg)
  : msg_(msg)
  {}
  Init_ChassisCanRecived_epbidu_fdbk_parksta mcuidu_fdbk_fault(::sensor_driver_msgs::msg::ChassisCanRecived::_mcuidu_fdbk_fault_type arg)
  {
    msg_.mcuidu_fdbk_fault = std::move(arg);
    return Init_ChassisCanRecived_epbidu_fdbk_parksta(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanRecived msg_;
};

class Init_ChassisCanRecived_mcuidu_fdbk_errolevel
{
public:
  explicit Init_ChassisCanRecived_mcuidu_fdbk_errolevel(::sensor_driver_msgs::msg::ChassisCanRecived & msg)
  : msg_(msg)
  {}
  Init_ChassisCanRecived_mcuidu_fdbk_fault mcuidu_fdbk_errolevel(::sensor_driver_msgs::msg::ChassisCanRecived::_mcuidu_fdbk_errolevel_type arg)
  {
    msg_.mcuidu_fdbk_errolevel = std::move(arg);
    return Init_ChassisCanRecived_mcuidu_fdbk_fault(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanRecived msg_;
};

class Init_ChassisCanRecived_mcuidu_fdbk_realrpm
{
public:
  explicit Init_ChassisCanRecived_mcuidu_fdbk_realrpm(::sensor_driver_msgs::msg::ChassisCanRecived & msg)
  : msg_(msg)
  {}
  Init_ChassisCanRecived_mcuidu_fdbk_errolevel mcuidu_fdbk_realrpm(::sensor_driver_msgs::msg::ChassisCanRecived::_mcuidu_fdbk_realrpm_type arg)
  {
    msg_.mcuidu_fdbk_realrpm = std::move(arg);
    return Init_ChassisCanRecived_mcuidu_fdbk_errolevel(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanRecived msg_;
};

class Init_ChassisCanRecived_mcuidu_fdbk_realtorq
{
public:
  explicit Init_ChassisCanRecived_mcuidu_fdbk_realtorq(::sensor_driver_msgs::msg::ChassisCanRecived & msg)
  : msg_(msg)
  {}
  Init_ChassisCanRecived_mcuidu_fdbk_realrpm mcuidu_fdbk_realtorq(::sensor_driver_msgs::msg::ChassisCanRecived::_mcuidu_fdbk_realtorq_type arg)
  {
    msg_.mcuidu_fdbk_realtorq = std::move(arg);
    return Init_ChassisCanRecived_mcuidu_fdbk_realrpm(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanRecived msg_;
};

class Init_ChassisCanRecived_mcuidu_fdbk_rnd
{
public:
  explicit Init_ChassisCanRecived_mcuidu_fdbk_rnd(::sensor_driver_msgs::msg::ChassisCanRecived & msg)
  : msg_(msg)
  {}
  Init_ChassisCanRecived_mcuidu_fdbk_realtorq mcuidu_fdbk_rnd(::sensor_driver_msgs::msg::ChassisCanRecived::_mcuidu_fdbk_rnd_type arg)
  {
    msg_.mcuidu_fdbk_rnd = std::move(arg);
    return Init_ChassisCanRecived_mcuidu_fdbk_realtorq(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanRecived msg_;
};

class Init_ChassisCanRecived_vcuidu_fdbk_checksum
{
public:
  explicit Init_ChassisCanRecived_vcuidu_fdbk_checksum(::sensor_driver_msgs::msg::ChassisCanRecived & msg)
  : msg_(msg)
  {}
  Init_ChassisCanRecived_mcuidu_fdbk_rnd vcuidu_fdbk_checksum(::sensor_driver_msgs::msg::ChassisCanRecived::_vcuidu_fdbk_checksum_type arg)
  {
    msg_.vcuidu_fdbk_checksum = std::move(arg);
    return Init_ChassisCanRecived_mcuidu_fdbk_rnd(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanRecived msg_;
};

class Init_ChassisCanRecived_vcu_fdbk_rollcnt
{
public:
  explicit Init_ChassisCanRecived_vcu_fdbk_rollcnt(::sensor_driver_msgs::msg::ChassisCanRecived & msg)
  : msg_(msg)
  {}
  Init_ChassisCanRecived_vcuidu_fdbk_checksum vcu_fdbk_rollcnt(::sensor_driver_msgs::msg::ChassisCanRecived::_vcu_fdbk_rollcnt_type arg)
  {
    msg_.vcu_fdbk_rollcnt = std::move(arg);
    return Init_ChassisCanRecived_vcuidu_fdbk_checksum(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanRecived msg_;
};

class Init_ChassisCanRecived_vcu_fdbk_softver
{
public:
  explicit Init_ChassisCanRecived_vcu_fdbk_softver(::sensor_driver_msgs::msg::ChassisCanRecived & msg)
  : msg_(msg)
  {}
  Init_ChassisCanRecived_vcu_fdbk_rollcnt vcu_fdbk_softver(::sensor_driver_msgs::msg::ChassisCanRecived::_vcu_fdbk_softver_type arg)
  {
    msg_.vcu_fdbk_softver = std::move(arg);
    return Init_ChassisCanRecived_vcu_fdbk_rollcnt(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanRecived msg_;
};

class Init_ChassisCanRecived_vcuidu_fdbk_erro
{
public:
  explicit Init_ChassisCanRecived_vcuidu_fdbk_erro(::sensor_driver_msgs::msg::ChassisCanRecived & msg)
  : msg_(msg)
  {}
  Init_ChassisCanRecived_vcu_fdbk_softver vcuidu_fdbk_erro(::sensor_driver_msgs::msg::ChassisCanRecived::_vcuidu_fdbk_erro_type arg)
  {
    msg_.vcuidu_fdbk_erro = std::move(arg);
    return Init_ChassisCanRecived_vcu_fdbk_softver(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanRecived msg_;
};

class Init_ChassisCanRecived_vcuidu_fdbk_power
{
public:
  explicit Init_ChassisCanRecived_vcuidu_fdbk_power(::sensor_driver_msgs::msg::ChassisCanRecived & msg)
  : msg_(msg)
  {}
  Init_ChassisCanRecived_vcuidu_fdbk_erro vcuidu_fdbk_power(::sensor_driver_msgs::msg::ChassisCanRecived::_vcuidu_fdbk_power_type arg)
  {
    msg_.vcuidu_fdbk_power = std::move(arg);
    return Init_ChassisCanRecived_vcuidu_fdbk_erro(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanRecived msg_;
};

class Init_ChassisCanRecived_vcuidu_fdbk_modelstop
{
public:
  explicit Init_ChassisCanRecived_vcuidu_fdbk_modelstop(::sensor_driver_msgs::msg::ChassisCanRecived & msg)
  : msg_(msg)
  {}
  Init_ChassisCanRecived_vcuidu_fdbk_power vcuidu_fdbk_modelstop(::sensor_driver_msgs::msg::ChassisCanRecived::_vcuidu_fdbk_modelstop_type arg)
  {
    msg_.vcuidu_fdbk_modelstop = std::move(arg);
    return Init_ChassisCanRecived_vcuidu_fdbk_power(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanRecived msg_;
};

class Init_ChassisCanRecived_vcuidu_fdbk_workmod
{
public:
  explicit Init_ChassisCanRecived_vcuidu_fdbk_workmod(::sensor_driver_msgs::msg::ChassisCanRecived & msg)
  : msg_(msg)
  {}
  Init_ChassisCanRecived_vcuidu_fdbk_modelstop vcuidu_fdbk_workmod(::sensor_driver_msgs::msg::ChassisCanRecived::_vcuidu_fdbk_workmod_type arg)
  {
    msg_.vcuidu_fdbk_workmod = std::move(arg);
    return Init_ChassisCanRecived_vcuidu_fdbk_modelstop(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanRecived msg_;
};

class Init_ChassisCanRecived_header
{
public:
  Init_ChassisCanRecived_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ChassisCanRecived_vcuidu_fdbk_workmod header(::sensor_driver_msgs::msg::ChassisCanRecived::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_ChassisCanRecived_vcuidu_fdbk_workmod(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanRecived msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sensor_driver_msgs::msg::ChassisCanRecived>()
{
  return sensor_driver_msgs::msg::builder::Init_ChassisCanRecived_header();
}

}  // namespace sensor_driver_msgs

#endif  // SENSOR_DRIVER_MSGS__MSG__DETAIL__CHASSIS_CAN_RECIVED__BUILDER_HPP_
