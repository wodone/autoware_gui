// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from sensor_driver_msgs:msg/UltrasonicRadar20.idl
// generated code does not contain a copyright notice

#ifndef SENSOR_DRIVER_MSGS__MSG__DETAIL__ULTRASONIC_RADAR20__STRUCT_H_
#define SENSOR_DRIVER_MSGS__MSG__DETAIL__ULTRASONIC_RADAR20__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"

// Struct defined in msg/UltrasonicRadar20 in the package sensor_driver_msgs.
typedef struct sensor_driver_msgs__msg__UltrasonicRadar20
{
  std_msgs__msg__Header header;
  uint16_t ultrasonic_01;
  uint16_t ultrasonic_02;
  uint16_t ultrasonic_03;
  uint16_t ultrasonic_04;
  uint16_t ultrasonic_05;
  uint16_t ultrasonic_06;
  uint16_t ultrasonic_07;
  uint16_t ultrasonic_08;
  uint16_t ultrasonic_09;
  uint16_t ultrasonic_10;
  uint16_t ultrasonic_11;
  uint16_t ultrasonic_12;
  uint16_t ultrasonic_13;
  uint16_t ultrasonic_14;
  uint16_t ultrasonic_15;
  uint16_t ultrasonic_16;
  uint16_t ultrasonic_17;
  uint16_t ultrasonic_18;
  uint16_t ultrasonic_19;
  uint16_t ultrasonic_20;
} sensor_driver_msgs__msg__UltrasonicRadar20;

// Struct for a sequence of sensor_driver_msgs__msg__UltrasonicRadar20.
typedef struct sensor_driver_msgs__msg__UltrasonicRadar20__Sequence
{
  sensor_driver_msgs__msg__UltrasonicRadar20 * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sensor_driver_msgs__msg__UltrasonicRadar20__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SENSOR_DRIVER_MSGS__MSG__DETAIL__ULTRASONIC_RADAR20__STRUCT_H_
