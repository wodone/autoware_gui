// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from sensor_driver_msgs:msg/ChassisCanRecived.idl
// generated code does not contain a copyright notice

#ifndef SENSOR_DRIVER_MSGS__MSG__DETAIL__CHASSIS_CAN_RECIVED__STRUCT_HPP_
#define SENSOR_DRIVER_MSGS__MSG__DETAIL__CHASSIS_CAN_RECIVED__STRUCT_HPP_

#include <rosidl_runtime_cpp/bounded_vector.hpp>
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__sensor_driver_msgs__msg__ChassisCanRecived __attribute__((deprecated))
#else
# define DEPRECATED__sensor_driver_msgs__msg__ChassisCanRecived __declspec(deprecated)
#endif

namespace sensor_driver_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ChassisCanRecived_
{
  using Type = ChassisCanRecived_<ContainerAllocator>;

  explicit ChassisCanRecived_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->vcuidu_fdbk_workmod = 0;
      this->vcuidu_fdbk_modelstop = 0;
      this->vcuidu_fdbk_power = 0;
      this->vcuidu_fdbk_erro = 0;
      this->vcu_fdbk_softver = 0ul;
      this->vcu_fdbk_rollcnt = 0;
      this->vcuidu_fdbk_checksum = 0;
      this->mcuidu_fdbk_rnd = 0;
      this->mcuidu_fdbk_realtorq = 0;
      this->mcuidu_fdbk_realrpm = 0;
      this->mcuidu_fdbk_errolevel = 0;
      this->mcuidu_fdbk_fault = 0;
      this->epbidu_fdbk_parksta = 0;
      this->epbidu_fdbk_errolevel = 0;
      this->epbidu_fdbk_fault = 0;
      this->epsidu_fdbk_worksta = 0;
      this->epsidu_fdbk_errolevel = 0;
      this->epsidu_fdbk_fault = 0;
      this->ehbidu_fdbk_realpressure = 0;
      this->ehbidu_fdbk_errolevel = 0;
      this->ehbidu_fdbk_fault = 0;
      this->bmsidu_fdbk_chcsta = 0;
      this->bmsidu_fdbk_soc = 0;
      this->bmsidu_fdbk_busv = 0;
      this->bmsidu_fdbk_errolevel = 0;
      this->bmsidu_fdbk_fault = 0;
      this->bcmidu_fdbk_headlight = 0;
      this->bcmidu_fdbk_turnflash = 0;
      this->bcmidu_fdbk_backlight = 0;
      this->bcmidu_fdbk_brakelight = 0;
      this->bcmidu_fdbk_siren = 0;
      this->bcmidu_fdbk_voice = 0;
      this->bcmidu_fdbk_doubleflash = 0;
      this->mcuidu_fdbk_realsped = 0;
      this->mcuidu_fdbk_realacc = 0;
      this->epsidu_fdbk_realangle = 0;
      this->ehbidu_fdbk_realdece = 0;
      this->bmsidu_fdbk_busa = 0;
    }
  }

  explicit ChassisCanRecived_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->vcuidu_fdbk_workmod = 0;
      this->vcuidu_fdbk_modelstop = 0;
      this->vcuidu_fdbk_power = 0;
      this->vcuidu_fdbk_erro = 0;
      this->vcu_fdbk_softver = 0ul;
      this->vcu_fdbk_rollcnt = 0;
      this->vcuidu_fdbk_checksum = 0;
      this->mcuidu_fdbk_rnd = 0;
      this->mcuidu_fdbk_realtorq = 0;
      this->mcuidu_fdbk_realrpm = 0;
      this->mcuidu_fdbk_errolevel = 0;
      this->mcuidu_fdbk_fault = 0;
      this->epbidu_fdbk_parksta = 0;
      this->epbidu_fdbk_errolevel = 0;
      this->epbidu_fdbk_fault = 0;
      this->epsidu_fdbk_worksta = 0;
      this->epsidu_fdbk_errolevel = 0;
      this->epsidu_fdbk_fault = 0;
      this->ehbidu_fdbk_realpressure = 0;
      this->ehbidu_fdbk_errolevel = 0;
      this->ehbidu_fdbk_fault = 0;
      this->bmsidu_fdbk_chcsta = 0;
      this->bmsidu_fdbk_soc = 0;
      this->bmsidu_fdbk_busv = 0;
      this->bmsidu_fdbk_errolevel = 0;
      this->bmsidu_fdbk_fault = 0;
      this->bcmidu_fdbk_headlight = 0;
      this->bcmidu_fdbk_turnflash = 0;
      this->bcmidu_fdbk_backlight = 0;
      this->bcmidu_fdbk_brakelight = 0;
      this->bcmidu_fdbk_siren = 0;
      this->bcmidu_fdbk_voice = 0;
      this->bcmidu_fdbk_doubleflash = 0;
      this->mcuidu_fdbk_realsped = 0;
      this->mcuidu_fdbk_realacc = 0;
      this->epsidu_fdbk_realangle = 0;
      this->ehbidu_fdbk_realdece = 0;
      this->bmsidu_fdbk_busa = 0;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _vcuidu_fdbk_workmod_type =
    uint16_t;
  _vcuidu_fdbk_workmod_type vcuidu_fdbk_workmod;
  using _vcuidu_fdbk_modelstop_type =
    uint16_t;
  _vcuidu_fdbk_modelstop_type vcuidu_fdbk_modelstop;
  using _vcuidu_fdbk_power_type =
    uint16_t;
  _vcuidu_fdbk_power_type vcuidu_fdbk_power;
  using _vcuidu_fdbk_erro_type =
    uint16_t;
  _vcuidu_fdbk_erro_type vcuidu_fdbk_erro;
  using _vcu_fdbk_softver_type =
    uint32_t;
  _vcu_fdbk_softver_type vcu_fdbk_softver;
  using _vcu_fdbk_rollcnt_type =
    uint16_t;
  _vcu_fdbk_rollcnt_type vcu_fdbk_rollcnt;
  using _vcuidu_fdbk_checksum_type =
    uint16_t;
  _vcuidu_fdbk_checksum_type vcuidu_fdbk_checksum;
  using _mcuidu_fdbk_rnd_type =
    uint16_t;
  _mcuidu_fdbk_rnd_type mcuidu_fdbk_rnd;
  using _mcuidu_fdbk_realtorq_type =
    uint16_t;
  _mcuidu_fdbk_realtorq_type mcuidu_fdbk_realtorq;
  using _mcuidu_fdbk_realrpm_type =
    uint16_t;
  _mcuidu_fdbk_realrpm_type mcuidu_fdbk_realrpm;
  using _mcuidu_fdbk_errolevel_type =
    uint16_t;
  _mcuidu_fdbk_errolevel_type mcuidu_fdbk_errolevel;
  using _mcuidu_fdbk_fault_type =
    uint16_t;
  _mcuidu_fdbk_fault_type mcuidu_fdbk_fault;
  using _epbidu_fdbk_parksta_type =
    uint16_t;
  _epbidu_fdbk_parksta_type epbidu_fdbk_parksta;
  using _epbidu_fdbk_errolevel_type =
    uint16_t;
  _epbidu_fdbk_errolevel_type epbidu_fdbk_errolevel;
  using _epbidu_fdbk_fault_type =
    uint16_t;
  _epbidu_fdbk_fault_type epbidu_fdbk_fault;
  using _epsidu_fdbk_worksta_type =
    uint16_t;
  _epsidu_fdbk_worksta_type epsidu_fdbk_worksta;
  using _epsidu_fdbk_errolevel_type =
    uint16_t;
  _epsidu_fdbk_errolevel_type epsidu_fdbk_errolevel;
  using _epsidu_fdbk_fault_type =
    uint16_t;
  _epsidu_fdbk_fault_type epsidu_fdbk_fault;
  using _ehbidu_fdbk_realpressure_type =
    uint16_t;
  _ehbidu_fdbk_realpressure_type ehbidu_fdbk_realpressure;
  using _ehbidu_fdbk_errolevel_type =
    uint16_t;
  _ehbidu_fdbk_errolevel_type ehbidu_fdbk_errolevel;
  using _ehbidu_fdbk_fault_type =
    uint16_t;
  _ehbidu_fdbk_fault_type ehbidu_fdbk_fault;
  using _bmsidu_fdbk_chcsta_type =
    uint16_t;
  _bmsidu_fdbk_chcsta_type bmsidu_fdbk_chcsta;
  using _bmsidu_fdbk_soc_type =
    uint16_t;
  _bmsidu_fdbk_soc_type bmsidu_fdbk_soc;
  using _bmsidu_fdbk_busv_type =
    uint16_t;
  _bmsidu_fdbk_busv_type bmsidu_fdbk_busv;
  using _bmsidu_fdbk_errolevel_type =
    uint16_t;
  _bmsidu_fdbk_errolevel_type bmsidu_fdbk_errolevel;
  using _bmsidu_fdbk_fault_type =
    uint16_t;
  _bmsidu_fdbk_fault_type bmsidu_fdbk_fault;
  using _bcmidu_fdbk_headlight_type =
    uint16_t;
  _bcmidu_fdbk_headlight_type bcmidu_fdbk_headlight;
  using _bcmidu_fdbk_turnflash_type =
    uint16_t;
  _bcmidu_fdbk_turnflash_type bcmidu_fdbk_turnflash;
  using _bcmidu_fdbk_backlight_type =
    uint16_t;
  _bcmidu_fdbk_backlight_type bcmidu_fdbk_backlight;
  using _bcmidu_fdbk_brakelight_type =
    uint16_t;
  _bcmidu_fdbk_brakelight_type bcmidu_fdbk_brakelight;
  using _bcmidu_fdbk_siren_type =
    uint16_t;
  _bcmidu_fdbk_siren_type bcmidu_fdbk_siren;
  using _bcmidu_fdbk_voice_type =
    uint16_t;
  _bcmidu_fdbk_voice_type bcmidu_fdbk_voice;
  using _bcmidu_fdbk_doubleflash_type =
    uint16_t;
  _bcmidu_fdbk_doubleflash_type bcmidu_fdbk_doubleflash;
  using _mcuidu_fdbk_realsped_type =
    int16_t;
  _mcuidu_fdbk_realsped_type mcuidu_fdbk_realsped;
  using _mcuidu_fdbk_realacc_type =
    int16_t;
  _mcuidu_fdbk_realacc_type mcuidu_fdbk_realacc;
  using _epsidu_fdbk_realangle_type =
    int16_t;
  _epsidu_fdbk_realangle_type epsidu_fdbk_realangle;
  using _ehbidu_fdbk_realdece_type =
    int16_t;
  _ehbidu_fdbk_realdece_type ehbidu_fdbk_realdece;
  using _bmsidu_fdbk_busa_type =
    int16_t;
  _bmsidu_fdbk_busa_type bmsidu_fdbk_busa;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__vcuidu_fdbk_workmod(
    const uint16_t & _arg)
  {
    this->vcuidu_fdbk_workmod = _arg;
    return *this;
  }
  Type & set__vcuidu_fdbk_modelstop(
    const uint16_t & _arg)
  {
    this->vcuidu_fdbk_modelstop = _arg;
    return *this;
  }
  Type & set__vcuidu_fdbk_power(
    const uint16_t & _arg)
  {
    this->vcuidu_fdbk_power = _arg;
    return *this;
  }
  Type & set__vcuidu_fdbk_erro(
    const uint16_t & _arg)
  {
    this->vcuidu_fdbk_erro = _arg;
    return *this;
  }
  Type & set__vcu_fdbk_softver(
    const uint32_t & _arg)
  {
    this->vcu_fdbk_softver = _arg;
    return *this;
  }
  Type & set__vcu_fdbk_rollcnt(
    const uint16_t & _arg)
  {
    this->vcu_fdbk_rollcnt = _arg;
    return *this;
  }
  Type & set__vcuidu_fdbk_checksum(
    const uint16_t & _arg)
  {
    this->vcuidu_fdbk_checksum = _arg;
    return *this;
  }
  Type & set__mcuidu_fdbk_rnd(
    const uint16_t & _arg)
  {
    this->mcuidu_fdbk_rnd = _arg;
    return *this;
  }
  Type & set__mcuidu_fdbk_realtorq(
    const uint16_t & _arg)
  {
    this->mcuidu_fdbk_realtorq = _arg;
    return *this;
  }
  Type & set__mcuidu_fdbk_realrpm(
    const uint16_t & _arg)
  {
    this->mcuidu_fdbk_realrpm = _arg;
    return *this;
  }
  Type & set__mcuidu_fdbk_errolevel(
    const uint16_t & _arg)
  {
    this->mcuidu_fdbk_errolevel = _arg;
    return *this;
  }
  Type & set__mcuidu_fdbk_fault(
    const uint16_t & _arg)
  {
    this->mcuidu_fdbk_fault = _arg;
    return *this;
  }
  Type & set__epbidu_fdbk_parksta(
    const uint16_t & _arg)
  {
    this->epbidu_fdbk_parksta = _arg;
    return *this;
  }
  Type & set__epbidu_fdbk_errolevel(
    const uint16_t & _arg)
  {
    this->epbidu_fdbk_errolevel = _arg;
    return *this;
  }
  Type & set__epbidu_fdbk_fault(
    const uint16_t & _arg)
  {
    this->epbidu_fdbk_fault = _arg;
    return *this;
  }
  Type & set__epsidu_fdbk_worksta(
    const uint16_t & _arg)
  {
    this->epsidu_fdbk_worksta = _arg;
    return *this;
  }
  Type & set__epsidu_fdbk_errolevel(
    const uint16_t & _arg)
  {
    this->epsidu_fdbk_errolevel = _arg;
    return *this;
  }
  Type & set__epsidu_fdbk_fault(
    const uint16_t & _arg)
  {
    this->epsidu_fdbk_fault = _arg;
    return *this;
  }
  Type & set__ehbidu_fdbk_realpressure(
    const uint16_t & _arg)
  {
    this->ehbidu_fdbk_realpressure = _arg;
    return *this;
  }
  Type & set__ehbidu_fdbk_errolevel(
    const uint16_t & _arg)
  {
    this->ehbidu_fdbk_errolevel = _arg;
    return *this;
  }
  Type & set__ehbidu_fdbk_fault(
    const uint16_t & _arg)
  {
    this->ehbidu_fdbk_fault = _arg;
    return *this;
  }
  Type & set__bmsidu_fdbk_chcsta(
    const uint16_t & _arg)
  {
    this->bmsidu_fdbk_chcsta = _arg;
    return *this;
  }
  Type & set__bmsidu_fdbk_soc(
    const uint16_t & _arg)
  {
    this->bmsidu_fdbk_soc = _arg;
    return *this;
  }
  Type & set__bmsidu_fdbk_busv(
    const uint16_t & _arg)
  {
    this->bmsidu_fdbk_busv = _arg;
    return *this;
  }
  Type & set__bmsidu_fdbk_errolevel(
    const uint16_t & _arg)
  {
    this->bmsidu_fdbk_errolevel = _arg;
    return *this;
  }
  Type & set__bmsidu_fdbk_fault(
    const uint16_t & _arg)
  {
    this->bmsidu_fdbk_fault = _arg;
    return *this;
  }
  Type & set__bcmidu_fdbk_headlight(
    const uint16_t & _arg)
  {
    this->bcmidu_fdbk_headlight = _arg;
    return *this;
  }
  Type & set__bcmidu_fdbk_turnflash(
    const uint16_t & _arg)
  {
    this->bcmidu_fdbk_turnflash = _arg;
    return *this;
  }
  Type & set__bcmidu_fdbk_backlight(
    const uint16_t & _arg)
  {
    this->bcmidu_fdbk_backlight = _arg;
    return *this;
  }
  Type & set__bcmidu_fdbk_brakelight(
    const uint16_t & _arg)
  {
    this->bcmidu_fdbk_brakelight = _arg;
    return *this;
  }
  Type & set__bcmidu_fdbk_siren(
    const uint16_t & _arg)
  {
    this->bcmidu_fdbk_siren = _arg;
    return *this;
  }
  Type & set__bcmidu_fdbk_voice(
    const uint16_t & _arg)
  {
    this->bcmidu_fdbk_voice = _arg;
    return *this;
  }
  Type & set__bcmidu_fdbk_doubleflash(
    const uint16_t & _arg)
  {
    this->bcmidu_fdbk_doubleflash = _arg;
    return *this;
  }
  Type & set__mcuidu_fdbk_realsped(
    const int16_t & _arg)
  {
    this->mcuidu_fdbk_realsped = _arg;
    return *this;
  }
  Type & set__mcuidu_fdbk_realacc(
    const int16_t & _arg)
  {
    this->mcuidu_fdbk_realacc = _arg;
    return *this;
  }
  Type & set__epsidu_fdbk_realangle(
    const int16_t & _arg)
  {
    this->epsidu_fdbk_realangle = _arg;
    return *this;
  }
  Type & set__ehbidu_fdbk_realdece(
    const int16_t & _arg)
  {
    this->ehbidu_fdbk_realdece = _arg;
    return *this;
  }
  Type & set__bmsidu_fdbk_busa(
    const int16_t & _arg)
  {
    this->bmsidu_fdbk_busa = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    sensor_driver_msgs::msg::ChassisCanRecived_<ContainerAllocator> *;
  using ConstRawPtr =
    const sensor_driver_msgs::msg::ChassisCanRecived_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<sensor_driver_msgs::msg::ChassisCanRecived_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<sensor_driver_msgs::msg::ChassisCanRecived_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      sensor_driver_msgs::msg::ChassisCanRecived_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<sensor_driver_msgs::msg::ChassisCanRecived_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      sensor_driver_msgs::msg::ChassisCanRecived_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<sensor_driver_msgs::msg::ChassisCanRecived_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<sensor_driver_msgs::msg::ChassisCanRecived_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<sensor_driver_msgs::msg::ChassisCanRecived_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__sensor_driver_msgs__msg__ChassisCanRecived
    std::shared_ptr<sensor_driver_msgs::msg::ChassisCanRecived_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__sensor_driver_msgs__msg__ChassisCanRecived
    std::shared_ptr<sensor_driver_msgs::msg::ChassisCanRecived_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ChassisCanRecived_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->vcuidu_fdbk_workmod != other.vcuidu_fdbk_workmod) {
      return false;
    }
    if (this->vcuidu_fdbk_modelstop != other.vcuidu_fdbk_modelstop) {
      return false;
    }
    if (this->vcuidu_fdbk_power != other.vcuidu_fdbk_power) {
      return false;
    }
    if (this->vcuidu_fdbk_erro != other.vcuidu_fdbk_erro) {
      return false;
    }
    if (this->vcu_fdbk_softver != other.vcu_fdbk_softver) {
      return false;
    }
    if (this->vcu_fdbk_rollcnt != other.vcu_fdbk_rollcnt) {
      return false;
    }
    if (this->vcuidu_fdbk_checksum != other.vcuidu_fdbk_checksum) {
      return false;
    }
    if (this->mcuidu_fdbk_rnd != other.mcuidu_fdbk_rnd) {
      return false;
    }
    if (this->mcuidu_fdbk_realtorq != other.mcuidu_fdbk_realtorq) {
      return false;
    }
    if (this->mcuidu_fdbk_realrpm != other.mcuidu_fdbk_realrpm) {
      return false;
    }
    if (this->mcuidu_fdbk_errolevel != other.mcuidu_fdbk_errolevel) {
      return false;
    }
    if (this->mcuidu_fdbk_fault != other.mcuidu_fdbk_fault) {
      return false;
    }
    if (this->epbidu_fdbk_parksta != other.epbidu_fdbk_parksta) {
      return false;
    }
    if (this->epbidu_fdbk_errolevel != other.epbidu_fdbk_errolevel) {
      return false;
    }
    if (this->epbidu_fdbk_fault != other.epbidu_fdbk_fault) {
      return false;
    }
    if (this->epsidu_fdbk_worksta != other.epsidu_fdbk_worksta) {
      return false;
    }
    if (this->epsidu_fdbk_errolevel != other.epsidu_fdbk_errolevel) {
      return false;
    }
    if (this->epsidu_fdbk_fault != other.epsidu_fdbk_fault) {
      return false;
    }
    if (this->ehbidu_fdbk_realpressure != other.ehbidu_fdbk_realpressure) {
      return false;
    }
    if (this->ehbidu_fdbk_errolevel != other.ehbidu_fdbk_errolevel) {
      return false;
    }
    if (this->ehbidu_fdbk_fault != other.ehbidu_fdbk_fault) {
      return false;
    }
    if (this->bmsidu_fdbk_chcsta != other.bmsidu_fdbk_chcsta) {
      return false;
    }
    if (this->bmsidu_fdbk_soc != other.bmsidu_fdbk_soc) {
      return false;
    }
    if (this->bmsidu_fdbk_busv != other.bmsidu_fdbk_busv) {
      return false;
    }
    if (this->bmsidu_fdbk_errolevel != other.bmsidu_fdbk_errolevel) {
      return false;
    }
    if (this->bmsidu_fdbk_fault != other.bmsidu_fdbk_fault) {
      return false;
    }
    if (this->bcmidu_fdbk_headlight != other.bcmidu_fdbk_headlight) {
      return false;
    }
    if (this->bcmidu_fdbk_turnflash != other.bcmidu_fdbk_turnflash) {
      return false;
    }
    if (this->bcmidu_fdbk_backlight != other.bcmidu_fdbk_backlight) {
      return false;
    }
    if (this->bcmidu_fdbk_brakelight != other.bcmidu_fdbk_brakelight) {
      return false;
    }
    if (this->bcmidu_fdbk_siren != other.bcmidu_fdbk_siren) {
      return false;
    }
    if (this->bcmidu_fdbk_voice != other.bcmidu_fdbk_voice) {
      return false;
    }
    if (this->bcmidu_fdbk_doubleflash != other.bcmidu_fdbk_doubleflash) {
      return false;
    }
    if (this->mcuidu_fdbk_realsped != other.mcuidu_fdbk_realsped) {
      return false;
    }
    if (this->mcuidu_fdbk_realacc != other.mcuidu_fdbk_realacc) {
      return false;
    }
    if (this->epsidu_fdbk_realangle != other.epsidu_fdbk_realangle) {
      return false;
    }
    if (this->ehbidu_fdbk_realdece != other.ehbidu_fdbk_realdece) {
      return false;
    }
    if (this->bmsidu_fdbk_busa != other.bmsidu_fdbk_busa) {
      return false;
    }
    return true;
  }
  bool operator!=(const ChassisCanRecived_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ChassisCanRecived_

// alias to use template instance with default allocator
using ChassisCanRecived =
  sensor_driver_msgs::msg::ChassisCanRecived_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace sensor_driver_msgs

#endif  // SENSOR_DRIVER_MSGS__MSG__DETAIL__CHASSIS_CAN_RECIVED__STRUCT_HPP_
