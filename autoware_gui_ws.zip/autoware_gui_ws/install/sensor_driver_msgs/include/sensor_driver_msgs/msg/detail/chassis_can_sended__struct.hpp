// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from sensor_driver_msgs:msg/ChassisCanSended.idl
// generated code does not contain a copyright notice

#ifndef SENSOR_DRIVER_MSGS__MSG__DETAIL__CHASSIS_CAN_SENDED__STRUCT_HPP_
#define SENSOR_DRIVER_MSGS__MSG__DETAIL__CHASSIS_CAN_SENDED__STRUCT_HPP_

#include <rosidl_runtime_cpp/bounded_vector.hpp>
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__sensor_driver_msgs__msg__ChassisCanSended __attribute__((deprecated))
#else
# define DEPRECATED__sensor_driver_msgs__msg__ChassisCanSended __declspec(deprecated)
#endif

namespace sensor_driver_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ChassisCanSended_
{
  using Type = ChassisCanSended_<ContainerAllocator>;

  explicit ChassisCanSended_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->iduvcu_ctrl_workmod = 0;
      this->iduvcu_ctrl_estop = 0;
      this->iduvcu_ctrl_restop = 0;
      this->iduvcu_ctrl_rollcnt = 0;
      this->iduvcu_ctrl_checksum = 0;
      this->idumcu_ctrl_workmod = 0;
      this->idumcu_ctrl_rnd = 0;
      this->iduepb_ctrl_reqpark = 0;
      this->iduehb_ctrl_brakmod = 0;
      this->iduehb_ctrl_tgtpressure = 0;
      this->idubms_ctrl_power = 0;
      this->idubcm_ctrl_headlight = 0;
      this->idubcm_ctrl_leftflash = 0;
      this->idubcm_ctrl_rightflash = 0;
      this->idubcm_ctrl_backlight = 0;
      this->idubcm_ctrl_brakelight = 0;
      this->idubcm_ctrl_siren = 0;
      this->idubcm_ctrl_voice = 0;
      this->idubcm_ctrl_doubleflash = 0;
      this->idumcu_ctrl_tgtsped = 0;
      this->idumcu_ctrl_tgtacc = 0;
      this->idumcu_ctrl_tgttorq = 0;
      this->idueps_ctrl_tgtangle = 0;
      this->iduehb_ctrl_tgtdece = 0;
    }
  }

  explicit ChassisCanSended_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->iduvcu_ctrl_workmod = 0;
      this->iduvcu_ctrl_estop = 0;
      this->iduvcu_ctrl_restop = 0;
      this->iduvcu_ctrl_rollcnt = 0;
      this->iduvcu_ctrl_checksum = 0;
      this->idumcu_ctrl_workmod = 0;
      this->idumcu_ctrl_rnd = 0;
      this->iduepb_ctrl_reqpark = 0;
      this->iduehb_ctrl_brakmod = 0;
      this->iduehb_ctrl_tgtpressure = 0;
      this->idubms_ctrl_power = 0;
      this->idubcm_ctrl_headlight = 0;
      this->idubcm_ctrl_leftflash = 0;
      this->idubcm_ctrl_rightflash = 0;
      this->idubcm_ctrl_backlight = 0;
      this->idubcm_ctrl_brakelight = 0;
      this->idubcm_ctrl_siren = 0;
      this->idubcm_ctrl_voice = 0;
      this->idubcm_ctrl_doubleflash = 0;
      this->idumcu_ctrl_tgtsped = 0;
      this->idumcu_ctrl_tgtacc = 0;
      this->idumcu_ctrl_tgttorq = 0;
      this->idueps_ctrl_tgtangle = 0;
      this->iduehb_ctrl_tgtdece = 0;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _iduvcu_ctrl_workmod_type =
    uint16_t;
  _iduvcu_ctrl_workmod_type iduvcu_ctrl_workmod;
  using _iduvcu_ctrl_estop_type =
    uint16_t;
  _iduvcu_ctrl_estop_type iduvcu_ctrl_estop;
  using _iduvcu_ctrl_restop_type =
    uint16_t;
  _iduvcu_ctrl_restop_type iduvcu_ctrl_restop;
  using _iduvcu_ctrl_rollcnt_type =
    uint16_t;
  _iduvcu_ctrl_rollcnt_type iduvcu_ctrl_rollcnt;
  using _iduvcu_ctrl_checksum_type =
    uint16_t;
  _iduvcu_ctrl_checksum_type iduvcu_ctrl_checksum;
  using _idumcu_ctrl_workmod_type =
    uint16_t;
  _idumcu_ctrl_workmod_type idumcu_ctrl_workmod;
  using _idumcu_ctrl_rnd_type =
    uint16_t;
  _idumcu_ctrl_rnd_type idumcu_ctrl_rnd;
  using _iduepb_ctrl_reqpark_type =
    uint16_t;
  _iduepb_ctrl_reqpark_type iduepb_ctrl_reqpark;
  using _iduehb_ctrl_brakmod_type =
    uint16_t;
  _iduehb_ctrl_brakmod_type iduehb_ctrl_brakmod;
  using _iduehb_ctrl_tgtpressure_type =
    uint16_t;
  _iduehb_ctrl_tgtpressure_type iduehb_ctrl_tgtpressure;
  using _idubms_ctrl_power_type =
    uint16_t;
  _idubms_ctrl_power_type idubms_ctrl_power;
  using _idubcm_ctrl_headlight_type =
    uint16_t;
  _idubcm_ctrl_headlight_type idubcm_ctrl_headlight;
  using _idubcm_ctrl_leftflash_type =
    uint16_t;
  _idubcm_ctrl_leftflash_type idubcm_ctrl_leftflash;
  using _idubcm_ctrl_rightflash_type =
    uint16_t;
  _idubcm_ctrl_rightflash_type idubcm_ctrl_rightflash;
  using _idubcm_ctrl_backlight_type =
    uint16_t;
  _idubcm_ctrl_backlight_type idubcm_ctrl_backlight;
  using _idubcm_ctrl_brakelight_type =
    uint16_t;
  _idubcm_ctrl_brakelight_type idubcm_ctrl_brakelight;
  using _idubcm_ctrl_siren_type =
    uint16_t;
  _idubcm_ctrl_siren_type idubcm_ctrl_siren;
  using _idubcm_ctrl_voice_type =
    uint16_t;
  _idubcm_ctrl_voice_type idubcm_ctrl_voice;
  using _idubcm_ctrl_doubleflash_type =
    uint16_t;
  _idubcm_ctrl_doubleflash_type idubcm_ctrl_doubleflash;
  using _idumcu_ctrl_tgtsped_type =
    int16_t;
  _idumcu_ctrl_tgtsped_type idumcu_ctrl_tgtsped;
  using _idumcu_ctrl_tgtacc_type =
    int16_t;
  _idumcu_ctrl_tgtacc_type idumcu_ctrl_tgtacc;
  using _idumcu_ctrl_tgttorq_type =
    int16_t;
  _idumcu_ctrl_tgttorq_type idumcu_ctrl_tgttorq;
  using _idueps_ctrl_tgtangle_type =
    int16_t;
  _idueps_ctrl_tgtangle_type idueps_ctrl_tgtangle;
  using _iduehb_ctrl_tgtdece_type =
    int16_t;
  _iduehb_ctrl_tgtdece_type iduehb_ctrl_tgtdece;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__iduvcu_ctrl_workmod(
    const uint16_t & _arg)
  {
    this->iduvcu_ctrl_workmod = _arg;
    return *this;
  }
  Type & set__iduvcu_ctrl_estop(
    const uint16_t & _arg)
  {
    this->iduvcu_ctrl_estop = _arg;
    return *this;
  }
  Type & set__iduvcu_ctrl_restop(
    const uint16_t & _arg)
  {
    this->iduvcu_ctrl_restop = _arg;
    return *this;
  }
  Type & set__iduvcu_ctrl_rollcnt(
    const uint16_t & _arg)
  {
    this->iduvcu_ctrl_rollcnt = _arg;
    return *this;
  }
  Type & set__iduvcu_ctrl_checksum(
    const uint16_t & _arg)
  {
    this->iduvcu_ctrl_checksum = _arg;
    return *this;
  }
  Type & set__idumcu_ctrl_workmod(
    const uint16_t & _arg)
  {
    this->idumcu_ctrl_workmod = _arg;
    return *this;
  }
  Type & set__idumcu_ctrl_rnd(
    const uint16_t & _arg)
  {
    this->idumcu_ctrl_rnd = _arg;
    return *this;
  }
  Type & set__iduepb_ctrl_reqpark(
    const uint16_t & _arg)
  {
    this->iduepb_ctrl_reqpark = _arg;
    return *this;
  }
  Type & set__iduehb_ctrl_brakmod(
    const uint16_t & _arg)
  {
    this->iduehb_ctrl_brakmod = _arg;
    return *this;
  }
  Type & set__iduehb_ctrl_tgtpressure(
    const uint16_t & _arg)
  {
    this->iduehb_ctrl_tgtpressure = _arg;
    return *this;
  }
  Type & set__idubms_ctrl_power(
    const uint16_t & _arg)
  {
    this->idubms_ctrl_power = _arg;
    return *this;
  }
  Type & set__idubcm_ctrl_headlight(
    const uint16_t & _arg)
  {
    this->idubcm_ctrl_headlight = _arg;
    return *this;
  }
  Type & set__idubcm_ctrl_leftflash(
    const uint16_t & _arg)
  {
    this->idubcm_ctrl_leftflash = _arg;
    return *this;
  }
  Type & set__idubcm_ctrl_rightflash(
    const uint16_t & _arg)
  {
    this->idubcm_ctrl_rightflash = _arg;
    return *this;
  }
  Type & set__idubcm_ctrl_backlight(
    const uint16_t & _arg)
  {
    this->idubcm_ctrl_backlight = _arg;
    return *this;
  }
  Type & set__idubcm_ctrl_brakelight(
    const uint16_t & _arg)
  {
    this->idubcm_ctrl_brakelight = _arg;
    return *this;
  }
  Type & set__idubcm_ctrl_siren(
    const uint16_t & _arg)
  {
    this->idubcm_ctrl_siren = _arg;
    return *this;
  }
  Type & set__idubcm_ctrl_voice(
    const uint16_t & _arg)
  {
    this->idubcm_ctrl_voice = _arg;
    return *this;
  }
  Type & set__idubcm_ctrl_doubleflash(
    const uint16_t & _arg)
  {
    this->idubcm_ctrl_doubleflash = _arg;
    return *this;
  }
  Type & set__idumcu_ctrl_tgtsped(
    const int16_t & _arg)
  {
    this->idumcu_ctrl_tgtsped = _arg;
    return *this;
  }
  Type & set__idumcu_ctrl_tgtacc(
    const int16_t & _arg)
  {
    this->idumcu_ctrl_tgtacc = _arg;
    return *this;
  }
  Type & set__idumcu_ctrl_tgttorq(
    const int16_t & _arg)
  {
    this->idumcu_ctrl_tgttorq = _arg;
    return *this;
  }
  Type & set__idueps_ctrl_tgtangle(
    const int16_t & _arg)
  {
    this->idueps_ctrl_tgtangle = _arg;
    return *this;
  }
  Type & set__iduehb_ctrl_tgtdece(
    const int16_t & _arg)
  {
    this->iduehb_ctrl_tgtdece = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    sensor_driver_msgs::msg::ChassisCanSended_<ContainerAllocator> *;
  using ConstRawPtr =
    const sensor_driver_msgs::msg::ChassisCanSended_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<sensor_driver_msgs::msg::ChassisCanSended_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<sensor_driver_msgs::msg::ChassisCanSended_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      sensor_driver_msgs::msg::ChassisCanSended_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<sensor_driver_msgs::msg::ChassisCanSended_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      sensor_driver_msgs::msg::ChassisCanSended_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<sensor_driver_msgs::msg::ChassisCanSended_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<sensor_driver_msgs::msg::ChassisCanSended_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<sensor_driver_msgs::msg::ChassisCanSended_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__sensor_driver_msgs__msg__ChassisCanSended
    std::shared_ptr<sensor_driver_msgs::msg::ChassisCanSended_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__sensor_driver_msgs__msg__ChassisCanSended
    std::shared_ptr<sensor_driver_msgs::msg::ChassisCanSended_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ChassisCanSended_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->iduvcu_ctrl_workmod != other.iduvcu_ctrl_workmod) {
      return false;
    }
    if (this->iduvcu_ctrl_estop != other.iduvcu_ctrl_estop) {
      return false;
    }
    if (this->iduvcu_ctrl_restop != other.iduvcu_ctrl_restop) {
      return false;
    }
    if (this->iduvcu_ctrl_rollcnt != other.iduvcu_ctrl_rollcnt) {
      return false;
    }
    if (this->iduvcu_ctrl_checksum != other.iduvcu_ctrl_checksum) {
      return false;
    }
    if (this->idumcu_ctrl_workmod != other.idumcu_ctrl_workmod) {
      return false;
    }
    if (this->idumcu_ctrl_rnd != other.idumcu_ctrl_rnd) {
      return false;
    }
    if (this->iduepb_ctrl_reqpark != other.iduepb_ctrl_reqpark) {
      return false;
    }
    if (this->iduehb_ctrl_brakmod != other.iduehb_ctrl_brakmod) {
      return false;
    }
    if (this->iduehb_ctrl_tgtpressure != other.iduehb_ctrl_tgtpressure) {
      return false;
    }
    if (this->idubms_ctrl_power != other.idubms_ctrl_power) {
      return false;
    }
    if (this->idubcm_ctrl_headlight != other.idubcm_ctrl_headlight) {
      return false;
    }
    if (this->idubcm_ctrl_leftflash != other.idubcm_ctrl_leftflash) {
      return false;
    }
    if (this->idubcm_ctrl_rightflash != other.idubcm_ctrl_rightflash) {
      return false;
    }
    if (this->idubcm_ctrl_backlight != other.idubcm_ctrl_backlight) {
      return false;
    }
    if (this->idubcm_ctrl_brakelight != other.idubcm_ctrl_brakelight) {
      return false;
    }
    if (this->idubcm_ctrl_siren != other.idubcm_ctrl_siren) {
      return false;
    }
    if (this->idubcm_ctrl_voice != other.idubcm_ctrl_voice) {
      return false;
    }
    if (this->idubcm_ctrl_doubleflash != other.idubcm_ctrl_doubleflash) {
      return false;
    }
    if (this->idumcu_ctrl_tgtsped != other.idumcu_ctrl_tgtsped) {
      return false;
    }
    if (this->idumcu_ctrl_tgtacc != other.idumcu_ctrl_tgtacc) {
      return false;
    }
    if (this->idumcu_ctrl_tgttorq != other.idumcu_ctrl_tgttorq) {
      return false;
    }
    if (this->idueps_ctrl_tgtangle != other.idueps_ctrl_tgtangle) {
      return false;
    }
    if (this->iduehb_ctrl_tgtdece != other.iduehb_ctrl_tgtdece) {
      return false;
    }
    return true;
  }
  bool operator!=(const ChassisCanSended_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ChassisCanSended_

// alias to use template instance with default allocator
using ChassisCanSended =
  sensor_driver_msgs::msg::ChassisCanSended_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace sensor_driver_msgs

#endif  // SENSOR_DRIVER_MSGS__MSG__DETAIL__CHASSIS_CAN_SENDED__STRUCT_HPP_
