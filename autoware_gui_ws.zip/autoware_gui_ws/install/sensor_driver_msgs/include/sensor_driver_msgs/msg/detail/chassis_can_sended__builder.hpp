// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sensor_driver_msgs:msg/ChassisCanSended.idl
// generated code does not contain a copyright notice

#ifndef SENSOR_DRIVER_MSGS__MSG__DETAIL__CHASSIS_CAN_SENDED__BUILDER_HPP_
#define SENSOR_DRIVER_MSGS__MSG__DETAIL__CHASSIS_CAN_SENDED__BUILDER_HPP_

#include "sensor_driver_msgs/msg/detail/chassis_can_sended__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace sensor_driver_msgs
{

namespace msg
{

namespace builder
{

class Init_ChassisCanSended_iduehb_ctrl_tgtdece
{
public:
  explicit Init_ChassisCanSended_iduehb_ctrl_tgtdece(::sensor_driver_msgs::msg::ChassisCanSended & msg)
  : msg_(msg)
  {}
  ::sensor_driver_msgs::msg::ChassisCanSended iduehb_ctrl_tgtdece(::sensor_driver_msgs::msg::ChassisCanSended::_iduehb_ctrl_tgtdece_type arg)
  {
    msg_.iduehb_ctrl_tgtdece = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanSended msg_;
};

class Init_ChassisCanSended_idueps_ctrl_tgtangle
{
public:
  explicit Init_ChassisCanSended_idueps_ctrl_tgtangle(::sensor_driver_msgs::msg::ChassisCanSended & msg)
  : msg_(msg)
  {}
  Init_ChassisCanSended_iduehb_ctrl_tgtdece idueps_ctrl_tgtangle(::sensor_driver_msgs::msg::ChassisCanSended::_idueps_ctrl_tgtangle_type arg)
  {
    msg_.idueps_ctrl_tgtangle = std::move(arg);
    return Init_ChassisCanSended_iduehb_ctrl_tgtdece(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanSended msg_;
};

class Init_ChassisCanSended_idumcu_ctrl_tgttorq
{
public:
  explicit Init_ChassisCanSended_idumcu_ctrl_tgttorq(::sensor_driver_msgs::msg::ChassisCanSended & msg)
  : msg_(msg)
  {}
  Init_ChassisCanSended_idueps_ctrl_tgtangle idumcu_ctrl_tgttorq(::sensor_driver_msgs::msg::ChassisCanSended::_idumcu_ctrl_tgttorq_type arg)
  {
    msg_.idumcu_ctrl_tgttorq = std::move(arg);
    return Init_ChassisCanSended_idueps_ctrl_tgtangle(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanSended msg_;
};

class Init_ChassisCanSended_idumcu_ctrl_tgtacc
{
public:
  explicit Init_ChassisCanSended_idumcu_ctrl_tgtacc(::sensor_driver_msgs::msg::ChassisCanSended & msg)
  : msg_(msg)
  {}
  Init_ChassisCanSended_idumcu_ctrl_tgttorq idumcu_ctrl_tgtacc(::sensor_driver_msgs::msg::ChassisCanSended::_idumcu_ctrl_tgtacc_type arg)
  {
    msg_.idumcu_ctrl_tgtacc = std::move(arg);
    return Init_ChassisCanSended_idumcu_ctrl_tgttorq(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanSended msg_;
};

class Init_ChassisCanSended_idumcu_ctrl_tgtsped
{
public:
  explicit Init_ChassisCanSended_idumcu_ctrl_tgtsped(::sensor_driver_msgs::msg::ChassisCanSended & msg)
  : msg_(msg)
  {}
  Init_ChassisCanSended_idumcu_ctrl_tgtacc idumcu_ctrl_tgtsped(::sensor_driver_msgs::msg::ChassisCanSended::_idumcu_ctrl_tgtsped_type arg)
  {
    msg_.idumcu_ctrl_tgtsped = std::move(arg);
    return Init_ChassisCanSended_idumcu_ctrl_tgtacc(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanSended msg_;
};

class Init_ChassisCanSended_idubcm_ctrl_doubleflash
{
public:
  explicit Init_ChassisCanSended_idubcm_ctrl_doubleflash(::sensor_driver_msgs::msg::ChassisCanSended & msg)
  : msg_(msg)
  {}
  Init_ChassisCanSended_idumcu_ctrl_tgtsped idubcm_ctrl_doubleflash(::sensor_driver_msgs::msg::ChassisCanSended::_idubcm_ctrl_doubleflash_type arg)
  {
    msg_.idubcm_ctrl_doubleflash = std::move(arg);
    return Init_ChassisCanSended_idumcu_ctrl_tgtsped(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanSended msg_;
};

class Init_ChassisCanSended_idubcm_ctrl_voice
{
public:
  explicit Init_ChassisCanSended_idubcm_ctrl_voice(::sensor_driver_msgs::msg::ChassisCanSended & msg)
  : msg_(msg)
  {}
  Init_ChassisCanSended_idubcm_ctrl_doubleflash idubcm_ctrl_voice(::sensor_driver_msgs::msg::ChassisCanSended::_idubcm_ctrl_voice_type arg)
  {
    msg_.idubcm_ctrl_voice = std::move(arg);
    return Init_ChassisCanSended_idubcm_ctrl_doubleflash(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanSended msg_;
};

class Init_ChassisCanSended_idubcm_ctrl_siren
{
public:
  explicit Init_ChassisCanSended_idubcm_ctrl_siren(::sensor_driver_msgs::msg::ChassisCanSended & msg)
  : msg_(msg)
  {}
  Init_ChassisCanSended_idubcm_ctrl_voice idubcm_ctrl_siren(::sensor_driver_msgs::msg::ChassisCanSended::_idubcm_ctrl_siren_type arg)
  {
    msg_.idubcm_ctrl_siren = std::move(arg);
    return Init_ChassisCanSended_idubcm_ctrl_voice(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanSended msg_;
};

class Init_ChassisCanSended_idubcm_ctrl_brakelight
{
public:
  explicit Init_ChassisCanSended_idubcm_ctrl_brakelight(::sensor_driver_msgs::msg::ChassisCanSended & msg)
  : msg_(msg)
  {}
  Init_ChassisCanSended_idubcm_ctrl_siren idubcm_ctrl_brakelight(::sensor_driver_msgs::msg::ChassisCanSended::_idubcm_ctrl_brakelight_type arg)
  {
    msg_.idubcm_ctrl_brakelight = std::move(arg);
    return Init_ChassisCanSended_idubcm_ctrl_siren(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanSended msg_;
};

class Init_ChassisCanSended_idubcm_ctrl_backlight
{
public:
  explicit Init_ChassisCanSended_idubcm_ctrl_backlight(::sensor_driver_msgs::msg::ChassisCanSended & msg)
  : msg_(msg)
  {}
  Init_ChassisCanSended_idubcm_ctrl_brakelight idubcm_ctrl_backlight(::sensor_driver_msgs::msg::ChassisCanSended::_idubcm_ctrl_backlight_type arg)
  {
    msg_.idubcm_ctrl_backlight = std::move(arg);
    return Init_ChassisCanSended_idubcm_ctrl_brakelight(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanSended msg_;
};

class Init_ChassisCanSended_idubcm_ctrl_rightflash
{
public:
  explicit Init_ChassisCanSended_idubcm_ctrl_rightflash(::sensor_driver_msgs::msg::ChassisCanSended & msg)
  : msg_(msg)
  {}
  Init_ChassisCanSended_idubcm_ctrl_backlight idubcm_ctrl_rightflash(::sensor_driver_msgs::msg::ChassisCanSended::_idubcm_ctrl_rightflash_type arg)
  {
    msg_.idubcm_ctrl_rightflash = std::move(arg);
    return Init_ChassisCanSended_idubcm_ctrl_backlight(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanSended msg_;
};

class Init_ChassisCanSended_idubcm_ctrl_leftflash
{
public:
  explicit Init_ChassisCanSended_idubcm_ctrl_leftflash(::sensor_driver_msgs::msg::ChassisCanSended & msg)
  : msg_(msg)
  {}
  Init_ChassisCanSended_idubcm_ctrl_rightflash idubcm_ctrl_leftflash(::sensor_driver_msgs::msg::ChassisCanSended::_idubcm_ctrl_leftflash_type arg)
  {
    msg_.idubcm_ctrl_leftflash = std::move(arg);
    return Init_ChassisCanSended_idubcm_ctrl_rightflash(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanSended msg_;
};

class Init_ChassisCanSended_idubcm_ctrl_headlight
{
public:
  explicit Init_ChassisCanSended_idubcm_ctrl_headlight(::sensor_driver_msgs::msg::ChassisCanSended & msg)
  : msg_(msg)
  {}
  Init_ChassisCanSended_idubcm_ctrl_leftflash idubcm_ctrl_headlight(::sensor_driver_msgs::msg::ChassisCanSended::_idubcm_ctrl_headlight_type arg)
  {
    msg_.idubcm_ctrl_headlight = std::move(arg);
    return Init_ChassisCanSended_idubcm_ctrl_leftflash(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanSended msg_;
};

class Init_ChassisCanSended_idubms_ctrl_power
{
public:
  explicit Init_ChassisCanSended_idubms_ctrl_power(::sensor_driver_msgs::msg::ChassisCanSended & msg)
  : msg_(msg)
  {}
  Init_ChassisCanSended_idubcm_ctrl_headlight idubms_ctrl_power(::sensor_driver_msgs::msg::ChassisCanSended::_idubms_ctrl_power_type arg)
  {
    msg_.idubms_ctrl_power = std::move(arg);
    return Init_ChassisCanSended_idubcm_ctrl_headlight(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanSended msg_;
};

class Init_ChassisCanSended_iduehb_ctrl_tgtpressure
{
public:
  explicit Init_ChassisCanSended_iduehb_ctrl_tgtpressure(::sensor_driver_msgs::msg::ChassisCanSended & msg)
  : msg_(msg)
  {}
  Init_ChassisCanSended_idubms_ctrl_power iduehb_ctrl_tgtpressure(::sensor_driver_msgs::msg::ChassisCanSended::_iduehb_ctrl_tgtpressure_type arg)
  {
    msg_.iduehb_ctrl_tgtpressure = std::move(arg);
    return Init_ChassisCanSended_idubms_ctrl_power(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanSended msg_;
};

class Init_ChassisCanSended_iduehb_ctrl_brakmod
{
public:
  explicit Init_ChassisCanSended_iduehb_ctrl_brakmod(::sensor_driver_msgs::msg::ChassisCanSended & msg)
  : msg_(msg)
  {}
  Init_ChassisCanSended_iduehb_ctrl_tgtpressure iduehb_ctrl_brakmod(::sensor_driver_msgs::msg::ChassisCanSended::_iduehb_ctrl_brakmod_type arg)
  {
    msg_.iduehb_ctrl_brakmod = std::move(arg);
    return Init_ChassisCanSended_iduehb_ctrl_tgtpressure(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanSended msg_;
};

class Init_ChassisCanSended_iduepb_ctrl_reqpark
{
public:
  explicit Init_ChassisCanSended_iduepb_ctrl_reqpark(::sensor_driver_msgs::msg::ChassisCanSended & msg)
  : msg_(msg)
  {}
  Init_ChassisCanSended_iduehb_ctrl_brakmod iduepb_ctrl_reqpark(::sensor_driver_msgs::msg::ChassisCanSended::_iduepb_ctrl_reqpark_type arg)
  {
    msg_.iduepb_ctrl_reqpark = std::move(arg);
    return Init_ChassisCanSended_iduehb_ctrl_brakmod(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanSended msg_;
};

class Init_ChassisCanSended_idumcu_ctrl_rnd
{
public:
  explicit Init_ChassisCanSended_idumcu_ctrl_rnd(::sensor_driver_msgs::msg::ChassisCanSended & msg)
  : msg_(msg)
  {}
  Init_ChassisCanSended_iduepb_ctrl_reqpark idumcu_ctrl_rnd(::sensor_driver_msgs::msg::ChassisCanSended::_idumcu_ctrl_rnd_type arg)
  {
    msg_.idumcu_ctrl_rnd = std::move(arg);
    return Init_ChassisCanSended_iduepb_ctrl_reqpark(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanSended msg_;
};

class Init_ChassisCanSended_idumcu_ctrl_workmod
{
public:
  explicit Init_ChassisCanSended_idumcu_ctrl_workmod(::sensor_driver_msgs::msg::ChassisCanSended & msg)
  : msg_(msg)
  {}
  Init_ChassisCanSended_idumcu_ctrl_rnd idumcu_ctrl_workmod(::sensor_driver_msgs::msg::ChassisCanSended::_idumcu_ctrl_workmod_type arg)
  {
    msg_.idumcu_ctrl_workmod = std::move(arg);
    return Init_ChassisCanSended_idumcu_ctrl_rnd(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanSended msg_;
};

class Init_ChassisCanSended_iduvcu_ctrl_checksum
{
public:
  explicit Init_ChassisCanSended_iduvcu_ctrl_checksum(::sensor_driver_msgs::msg::ChassisCanSended & msg)
  : msg_(msg)
  {}
  Init_ChassisCanSended_idumcu_ctrl_workmod iduvcu_ctrl_checksum(::sensor_driver_msgs::msg::ChassisCanSended::_iduvcu_ctrl_checksum_type arg)
  {
    msg_.iduvcu_ctrl_checksum = std::move(arg);
    return Init_ChassisCanSended_idumcu_ctrl_workmod(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanSended msg_;
};

class Init_ChassisCanSended_iduvcu_ctrl_rollcnt
{
public:
  explicit Init_ChassisCanSended_iduvcu_ctrl_rollcnt(::sensor_driver_msgs::msg::ChassisCanSended & msg)
  : msg_(msg)
  {}
  Init_ChassisCanSended_iduvcu_ctrl_checksum iduvcu_ctrl_rollcnt(::sensor_driver_msgs::msg::ChassisCanSended::_iduvcu_ctrl_rollcnt_type arg)
  {
    msg_.iduvcu_ctrl_rollcnt = std::move(arg);
    return Init_ChassisCanSended_iduvcu_ctrl_checksum(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanSended msg_;
};

class Init_ChassisCanSended_iduvcu_ctrl_restop
{
public:
  explicit Init_ChassisCanSended_iduvcu_ctrl_restop(::sensor_driver_msgs::msg::ChassisCanSended & msg)
  : msg_(msg)
  {}
  Init_ChassisCanSended_iduvcu_ctrl_rollcnt iduvcu_ctrl_restop(::sensor_driver_msgs::msg::ChassisCanSended::_iduvcu_ctrl_restop_type arg)
  {
    msg_.iduvcu_ctrl_restop = std::move(arg);
    return Init_ChassisCanSended_iduvcu_ctrl_rollcnt(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanSended msg_;
};

class Init_ChassisCanSended_iduvcu_ctrl_estop
{
public:
  explicit Init_ChassisCanSended_iduvcu_ctrl_estop(::sensor_driver_msgs::msg::ChassisCanSended & msg)
  : msg_(msg)
  {}
  Init_ChassisCanSended_iduvcu_ctrl_restop iduvcu_ctrl_estop(::sensor_driver_msgs::msg::ChassisCanSended::_iduvcu_ctrl_estop_type arg)
  {
    msg_.iduvcu_ctrl_estop = std::move(arg);
    return Init_ChassisCanSended_iduvcu_ctrl_restop(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanSended msg_;
};

class Init_ChassisCanSended_iduvcu_ctrl_workmod
{
public:
  explicit Init_ChassisCanSended_iduvcu_ctrl_workmod(::sensor_driver_msgs::msg::ChassisCanSended & msg)
  : msg_(msg)
  {}
  Init_ChassisCanSended_iduvcu_ctrl_estop iduvcu_ctrl_workmod(::sensor_driver_msgs::msg::ChassisCanSended::_iduvcu_ctrl_workmod_type arg)
  {
    msg_.iduvcu_ctrl_workmod = std::move(arg);
    return Init_ChassisCanSended_iduvcu_ctrl_estop(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanSended msg_;
};

class Init_ChassisCanSended_header
{
public:
  Init_ChassisCanSended_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ChassisCanSended_iduvcu_ctrl_workmod header(::sensor_driver_msgs::msg::ChassisCanSended::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_ChassisCanSended_iduvcu_ctrl_workmod(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ChassisCanSended msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sensor_driver_msgs::msg::ChassisCanSended>()
{
  return sensor_driver_msgs::msg::builder::Init_ChassisCanSended_header();
}

}  // namespace sensor_driver_msgs

#endif  // SENSOR_DRIVER_MSGS__MSG__DETAIL__CHASSIS_CAN_SENDED__BUILDER_HPP_
