// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from sensor_driver_msgs:msg/GnssPashr.idl
// generated code does not contain a copyright notice

#ifndef SENSOR_DRIVER_MSGS__MSG__DETAIL__GNSS_PASHR__STRUCT_HPP_
#define SENSOR_DRIVER_MSGS__MSG__DETAIL__GNSS_PASHR__STRUCT_HPP_

#include <rosidl_runtime_cpp/bounded_vector.hpp>
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__sensor_driver_msgs__msg__GnssPashr __attribute__((deprecated))
#else
# define DEPRECATED__sensor_driver_msgs__msg__GnssPashr __declspec(deprecated)
#endif

namespace sensor_driver_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct GnssPashr_
{
  using Type = GnssPashr_<ContainerAllocator>;

  explicit GnssPashr_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->data_id = "";
      this->utc_time = 0.0;
      this->yaw = 0.0;
      this->t_sign = "";
      this->roll = 0.0;
      this->pitch = 0.0;
      this->height_error = 0.0;
      this->roll_std = 0.0;
      this->pitch_std = 0.0;
      this->yaw_std = 0.0;
      this->state = 0;
      this->cs = "";
    }
  }

  explicit GnssPashr_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init),
    data_id(_alloc),
    t_sign(_alloc),
    cs(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->data_id = "";
      this->utc_time = 0.0;
      this->yaw = 0.0;
      this->t_sign = "";
      this->roll = 0.0;
      this->pitch = 0.0;
      this->height_error = 0.0;
      this->roll_std = 0.0;
      this->pitch_std = 0.0;
      this->yaw_std = 0.0;
      this->state = 0;
      this->cs = "";
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _data_id_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _data_id_type data_id;
  using _utc_time_type =
    double;
  _utc_time_type utc_time;
  using _yaw_type =
    double;
  _yaw_type yaw;
  using _t_sign_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _t_sign_type t_sign;
  using _roll_type =
    double;
  _roll_type roll;
  using _pitch_type =
    double;
  _pitch_type pitch;
  using _height_error_type =
    double;
  _height_error_type height_error;
  using _roll_std_type =
    double;
  _roll_std_type roll_std;
  using _pitch_std_type =
    double;
  _pitch_std_type pitch_std;
  using _yaw_std_type =
    double;
  _yaw_std_type yaw_std;
  using _state_type =
    int16_t;
  _state_type state;
  using _cs_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _cs_type cs;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__data_id(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->data_id = _arg;
    return *this;
  }
  Type & set__utc_time(
    const double & _arg)
  {
    this->utc_time = _arg;
    return *this;
  }
  Type & set__yaw(
    const double & _arg)
  {
    this->yaw = _arg;
    return *this;
  }
  Type & set__t_sign(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->t_sign = _arg;
    return *this;
  }
  Type & set__roll(
    const double & _arg)
  {
    this->roll = _arg;
    return *this;
  }
  Type & set__pitch(
    const double & _arg)
  {
    this->pitch = _arg;
    return *this;
  }
  Type & set__height_error(
    const double & _arg)
  {
    this->height_error = _arg;
    return *this;
  }
  Type & set__roll_std(
    const double & _arg)
  {
    this->roll_std = _arg;
    return *this;
  }
  Type & set__pitch_std(
    const double & _arg)
  {
    this->pitch_std = _arg;
    return *this;
  }
  Type & set__yaw_std(
    const double & _arg)
  {
    this->yaw_std = _arg;
    return *this;
  }
  Type & set__state(
    const int16_t & _arg)
  {
    this->state = _arg;
    return *this;
  }
  Type & set__cs(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->cs = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    sensor_driver_msgs::msg::GnssPashr_<ContainerAllocator> *;
  using ConstRawPtr =
    const sensor_driver_msgs::msg::GnssPashr_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<sensor_driver_msgs::msg::GnssPashr_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<sensor_driver_msgs::msg::GnssPashr_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      sensor_driver_msgs::msg::GnssPashr_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<sensor_driver_msgs::msg::GnssPashr_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      sensor_driver_msgs::msg::GnssPashr_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<sensor_driver_msgs::msg::GnssPashr_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<sensor_driver_msgs::msg::GnssPashr_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<sensor_driver_msgs::msg::GnssPashr_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__sensor_driver_msgs__msg__GnssPashr
    std::shared_ptr<sensor_driver_msgs::msg::GnssPashr_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__sensor_driver_msgs__msg__GnssPashr
    std::shared_ptr<sensor_driver_msgs::msg::GnssPashr_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const GnssPashr_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->data_id != other.data_id) {
      return false;
    }
    if (this->utc_time != other.utc_time) {
      return false;
    }
    if (this->yaw != other.yaw) {
      return false;
    }
    if (this->t_sign != other.t_sign) {
      return false;
    }
    if (this->roll != other.roll) {
      return false;
    }
    if (this->pitch != other.pitch) {
      return false;
    }
    if (this->height_error != other.height_error) {
      return false;
    }
    if (this->roll_std != other.roll_std) {
      return false;
    }
    if (this->pitch_std != other.pitch_std) {
      return false;
    }
    if (this->yaw_std != other.yaw_std) {
      return false;
    }
    if (this->state != other.state) {
      return false;
    }
    if (this->cs != other.cs) {
      return false;
    }
    return true;
  }
  bool operator!=(const GnssPashr_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct GnssPashr_

// alias to use template instance with default allocator
using GnssPashr =
  sensor_driver_msgs::msg::GnssPashr_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace sensor_driver_msgs

#endif  // SENSOR_DRIVER_MSGS__MSG__DETAIL__GNSS_PASHR__STRUCT_HPP_
