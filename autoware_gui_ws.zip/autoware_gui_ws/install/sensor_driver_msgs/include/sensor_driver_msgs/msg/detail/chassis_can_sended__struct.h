// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from sensor_driver_msgs:msg/ChassisCanSended.idl
// generated code does not contain a copyright notice

#ifndef SENSOR_DRIVER_MSGS__MSG__DETAIL__CHASSIS_CAN_SENDED__STRUCT_H_
#define SENSOR_DRIVER_MSGS__MSG__DETAIL__CHASSIS_CAN_SENDED__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"

// Struct defined in msg/ChassisCanSended in the package sensor_driver_msgs.
typedef struct sensor_driver_msgs__msg__ChassisCanSended
{
  std_msgs__msg__Header header;
  uint16_t iduvcu_ctrl_workmod;
  uint16_t iduvcu_ctrl_estop;
  uint16_t iduvcu_ctrl_restop;
  uint16_t iduvcu_ctrl_rollcnt;
  uint16_t iduvcu_ctrl_checksum;
  uint16_t idumcu_ctrl_workmod;
  uint16_t idumcu_ctrl_rnd;
  uint16_t iduepb_ctrl_reqpark;
  uint16_t iduehb_ctrl_brakmod;
  uint16_t iduehb_ctrl_tgtpressure;
  uint16_t idubms_ctrl_power;
  uint16_t idubcm_ctrl_headlight;
  uint16_t idubcm_ctrl_leftflash;
  uint16_t idubcm_ctrl_rightflash;
  uint16_t idubcm_ctrl_backlight;
  uint16_t idubcm_ctrl_brakelight;
  uint16_t idubcm_ctrl_siren;
  uint16_t idubcm_ctrl_voice;
  uint16_t idubcm_ctrl_doubleflash;
  int16_t idumcu_ctrl_tgtsped;
  int16_t idumcu_ctrl_tgtacc;
  int16_t idumcu_ctrl_tgttorq;
  int16_t idueps_ctrl_tgtangle;
  int16_t iduehb_ctrl_tgtdece;
} sensor_driver_msgs__msg__ChassisCanSended;

// Struct for a sequence of sensor_driver_msgs__msg__ChassisCanSended.
typedef struct sensor_driver_msgs__msg__ChassisCanSended__Sequence
{
  sensor_driver_msgs__msg__ChassisCanSended * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sensor_driver_msgs__msg__ChassisCanSended__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SENSOR_DRIVER_MSGS__MSG__DETAIL__CHASSIS_CAN_SENDED__STRUCT_H_
