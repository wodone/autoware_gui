// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from sensor_driver_msgs:msg/ChassisCanRecived.idl
// generated code does not contain a copyright notice

#ifndef SENSOR_DRIVER_MSGS__MSG__DETAIL__CHASSIS_CAN_RECIVED__STRUCT_H_
#define SENSOR_DRIVER_MSGS__MSG__DETAIL__CHASSIS_CAN_RECIVED__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"

// Struct defined in msg/ChassisCanRecived in the package sensor_driver_msgs.
typedef struct sensor_driver_msgs__msg__ChassisCanRecived
{
  std_msgs__msg__Header header;
  uint16_t vcuidu_fdbk_workmod;
  uint16_t vcuidu_fdbk_modelstop;
  uint16_t vcuidu_fdbk_power;
  uint16_t vcuidu_fdbk_erro;
  uint32_t vcu_fdbk_softver;
  uint16_t vcu_fdbk_rollcnt;
  uint16_t vcuidu_fdbk_checksum;
  uint16_t mcuidu_fdbk_rnd;
  uint16_t mcuidu_fdbk_realtorq;
  uint16_t mcuidu_fdbk_realrpm;
  uint16_t mcuidu_fdbk_errolevel;
  uint16_t mcuidu_fdbk_fault;
  uint16_t epbidu_fdbk_parksta;
  uint16_t epbidu_fdbk_errolevel;
  uint16_t epbidu_fdbk_fault;
  uint16_t epsidu_fdbk_worksta;
  uint16_t epsidu_fdbk_errolevel;
  uint16_t epsidu_fdbk_fault;
  uint16_t ehbidu_fdbk_realpressure;
  uint16_t ehbidu_fdbk_errolevel;
  uint16_t ehbidu_fdbk_fault;
  uint16_t bmsidu_fdbk_chcsta;
  uint16_t bmsidu_fdbk_soc;
  uint16_t bmsidu_fdbk_busv;
  uint16_t bmsidu_fdbk_errolevel;
  uint16_t bmsidu_fdbk_fault;
  uint16_t bcmidu_fdbk_headlight;
  uint16_t bcmidu_fdbk_turnflash;
  uint16_t bcmidu_fdbk_backlight;
  uint16_t bcmidu_fdbk_brakelight;
  uint16_t bcmidu_fdbk_siren;
  uint16_t bcmidu_fdbk_voice;
  uint16_t bcmidu_fdbk_doubleflash;
  int16_t mcuidu_fdbk_realsped;
  int16_t mcuidu_fdbk_realacc;
  int16_t epsidu_fdbk_realangle;
  int16_t ehbidu_fdbk_realdece;
  int16_t bmsidu_fdbk_busa;
} sensor_driver_msgs__msg__ChassisCanRecived;

// Struct for a sequence of sensor_driver_msgs__msg__ChassisCanRecived.
typedef struct sensor_driver_msgs__msg__ChassisCanRecived__Sequence
{
  sensor_driver_msgs__msg__ChassisCanRecived * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sensor_driver_msgs__msg__ChassisCanRecived__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SENSOR_DRIVER_MSGS__MSG__DETAIL__CHASSIS_CAN_RECIVED__STRUCT_H_
