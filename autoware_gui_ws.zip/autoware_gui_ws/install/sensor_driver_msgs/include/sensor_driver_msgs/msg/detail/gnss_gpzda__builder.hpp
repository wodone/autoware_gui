// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sensor_driver_msgs:msg/GnssGpzda.idl
// generated code does not contain a copyright notice

#ifndef SENSOR_DRIVER_MSGS__MSG__DETAIL__GNSS_GPZDA__BUILDER_HPP_
#define SENSOR_DRIVER_MSGS__MSG__DETAIL__GNSS_GPZDA__BUILDER_HPP_

#include "sensor_driver_msgs/msg/detail/gnss_gpzda__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace sensor_driver_msgs
{

namespace msg
{

namespace builder
{

class Init_GnssGpzda_cs
{
public:
  explicit Init_GnssGpzda_cs(::sensor_driver_msgs::msg::GnssGpzda & msg)
  : msg_(msg)
  {}
  ::sensor_driver_msgs::msg::GnssGpzda cs(::sensor_driver_msgs::msg::GnssGpzda::_cs_type arg)
  {
    msg_.cs = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpzda msg_;
};

class Init_GnssGpzda_time_diff
{
public:
  explicit Init_GnssGpzda_time_diff(::sensor_driver_msgs::msg::GnssGpzda & msg)
  : msg_(msg)
  {}
  Init_GnssGpzda_cs time_diff(::sensor_driver_msgs::msg::GnssGpzda::_time_diff_type arg)
  {
    msg_.time_diff = std::move(arg);
    return Init_GnssGpzda_cs(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpzda msg_;
};

class Init_GnssGpzda_time_zone
{
public:
  explicit Init_GnssGpzda_time_zone(::sensor_driver_msgs::msg::GnssGpzda & msg)
  : msg_(msg)
  {}
  Init_GnssGpzda_time_diff time_zone(::sensor_driver_msgs::msg::GnssGpzda::_time_zone_type arg)
  {
    msg_.time_zone = std::move(arg);
    return Init_GnssGpzda_time_diff(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpzda msg_;
};

class Init_GnssGpzda_time_year
{
public:
  explicit Init_GnssGpzda_time_year(::sensor_driver_msgs::msg::GnssGpzda & msg)
  : msg_(msg)
  {}
  Init_GnssGpzda_time_zone time_year(::sensor_driver_msgs::msg::GnssGpzda::_time_year_type arg)
  {
    msg_.time_year = std::move(arg);
    return Init_GnssGpzda_time_zone(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpzda msg_;
};

class Init_GnssGpzda_time_month
{
public:
  explicit Init_GnssGpzda_time_month(::sensor_driver_msgs::msg::GnssGpzda & msg)
  : msg_(msg)
  {}
  Init_GnssGpzda_time_year time_month(::sensor_driver_msgs::msg::GnssGpzda::_time_month_type arg)
  {
    msg_.time_month = std::move(arg);
    return Init_GnssGpzda_time_year(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpzda msg_;
};

class Init_GnssGpzda_time_day
{
public:
  explicit Init_GnssGpzda_time_day(::sensor_driver_msgs::msg::GnssGpzda & msg)
  : msg_(msg)
  {}
  Init_GnssGpzda_time_month time_day(::sensor_driver_msgs::msg::GnssGpzda::_time_day_type arg)
  {
    msg_.time_day = std::move(arg);
    return Init_GnssGpzda_time_month(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpzda msg_;
};

class Init_GnssGpzda_utc_time
{
public:
  explicit Init_GnssGpzda_utc_time(::sensor_driver_msgs::msg::GnssGpzda & msg)
  : msg_(msg)
  {}
  Init_GnssGpzda_time_day utc_time(::sensor_driver_msgs::msg::GnssGpzda::_utc_time_type arg)
  {
    msg_.utc_time = std::move(arg);
    return Init_GnssGpzda_time_day(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpzda msg_;
};

class Init_GnssGpzda_data_id
{
public:
  explicit Init_GnssGpzda_data_id(::sensor_driver_msgs::msg::GnssGpzda & msg)
  : msg_(msg)
  {}
  Init_GnssGpzda_utc_time data_id(::sensor_driver_msgs::msg::GnssGpzda::_data_id_type arg)
  {
    msg_.data_id = std::move(arg);
    return Init_GnssGpzda_utc_time(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpzda msg_;
};

class Init_GnssGpzda_header
{
public:
  Init_GnssGpzda_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_GnssGpzda_data_id header(::sensor_driver_msgs::msg::GnssGpzda::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_GnssGpzda_data_id(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpzda msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sensor_driver_msgs::msg::GnssGpzda>()
{
  return sensor_driver_msgs::msg::builder::Init_GnssGpzda_header();
}

}  // namespace sensor_driver_msgs

#endif  // SENSOR_DRIVER_MSGS__MSG__DETAIL__GNSS_GPZDA__BUILDER_HPP_
