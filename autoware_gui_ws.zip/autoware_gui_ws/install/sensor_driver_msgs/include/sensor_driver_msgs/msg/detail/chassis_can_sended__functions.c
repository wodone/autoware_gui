// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from sensor_driver_msgs:msg/ChassisCanSended.idl
// generated code does not contain a copyright notice
#include "sensor_driver_msgs/msg/detail/chassis_can_sended__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"

bool
sensor_driver_msgs__msg__ChassisCanSended__init(sensor_driver_msgs__msg__ChassisCanSended * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    sensor_driver_msgs__msg__ChassisCanSended__fini(msg);
    return false;
  }
  // iduvcu_ctrl_workmod
  // iduvcu_ctrl_estop
  // iduvcu_ctrl_restop
  // iduvcu_ctrl_rollcnt
  // iduvcu_ctrl_checksum
  // idumcu_ctrl_workmod
  // idumcu_ctrl_rnd
  // iduepb_ctrl_reqpark
  // iduehb_ctrl_brakmod
  // iduehb_ctrl_tgtpressure
  // idubms_ctrl_power
  // idubcm_ctrl_headlight
  // idubcm_ctrl_leftflash
  // idubcm_ctrl_rightflash
  // idubcm_ctrl_backlight
  // idubcm_ctrl_brakelight
  // idubcm_ctrl_siren
  // idubcm_ctrl_voice
  // idubcm_ctrl_doubleflash
  // idumcu_ctrl_tgtsped
  // idumcu_ctrl_tgtacc
  // idumcu_ctrl_tgttorq
  // idueps_ctrl_tgtangle
  // iduehb_ctrl_tgtdece
  return true;
}

void
sensor_driver_msgs__msg__ChassisCanSended__fini(sensor_driver_msgs__msg__ChassisCanSended * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // iduvcu_ctrl_workmod
  // iduvcu_ctrl_estop
  // iduvcu_ctrl_restop
  // iduvcu_ctrl_rollcnt
  // iduvcu_ctrl_checksum
  // idumcu_ctrl_workmod
  // idumcu_ctrl_rnd
  // iduepb_ctrl_reqpark
  // iduehb_ctrl_brakmod
  // iduehb_ctrl_tgtpressure
  // idubms_ctrl_power
  // idubcm_ctrl_headlight
  // idubcm_ctrl_leftflash
  // idubcm_ctrl_rightflash
  // idubcm_ctrl_backlight
  // idubcm_ctrl_brakelight
  // idubcm_ctrl_siren
  // idubcm_ctrl_voice
  // idubcm_ctrl_doubleflash
  // idumcu_ctrl_tgtsped
  // idumcu_ctrl_tgtacc
  // idumcu_ctrl_tgttorq
  // idueps_ctrl_tgtangle
  // iduehb_ctrl_tgtdece
}

bool
sensor_driver_msgs__msg__ChassisCanSended__are_equal(const sensor_driver_msgs__msg__ChassisCanSended * lhs, const sensor_driver_msgs__msg__ChassisCanSended * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // iduvcu_ctrl_workmod
  if (lhs->iduvcu_ctrl_workmod != rhs->iduvcu_ctrl_workmod) {
    return false;
  }
  // iduvcu_ctrl_estop
  if (lhs->iduvcu_ctrl_estop != rhs->iduvcu_ctrl_estop) {
    return false;
  }
  // iduvcu_ctrl_restop
  if (lhs->iduvcu_ctrl_restop != rhs->iduvcu_ctrl_restop) {
    return false;
  }
  // iduvcu_ctrl_rollcnt
  if (lhs->iduvcu_ctrl_rollcnt != rhs->iduvcu_ctrl_rollcnt) {
    return false;
  }
  // iduvcu_ctrl_checksum
  if (lhs->iduvcu_ctrl_checksum != rhs->iduvcu_ctrl_checksum) {
    return false;
  }
  // idumcu_ctrl_workmod
  if (lhs->idumcu_ctrl_workmod != rhs->idumcu_ctrl_workmod) {
    return false;
  }
  // idumcu_ctrl_rnd
  if (lhs->idumcu_ctrl_rnd != rhs->idumcu_ctrl_rnd) {
    return false;
  }
  // iduepb_ctrl_reqpark
  if (lhs->iduepb_ctrl_reqpark != rhs->iduepb_ctrl_reqpark) {
    return false;
  }
  // iduehb_ctrl_brakmod
  if (lhs->iduehb_ctrl_brakmod != rhs->iduehb_ctrl_brakmod) {
    return false;
  }
  // iduehb_ctrl_tgtpressure
  if (lhs->iduehb_ctrl_tgtpressure != rhs->iduehb_ctrl_tgtpressure) {
    return false;
  }
  // idubms_ctrl_power
  if (lhs->idubms_ctrl_power != rhs->idubms_ctrl_power) {
    return false;
  }
  // idubcm_ctrl_headlight
  if (lhs->idubcm_ctrl_headlight != rhs->idubcm_ctrl_headlight) {
    return false;
  }
  // idubcm_ctrl_leftflash
  if (lhs->idubcm_ctrl_leftflash != rhs->idubcm_ctrl_leftflash) {
    return false;
  }
  // idubcm_ctrl_rightflash
  if (lhs->idubcm_ctrl_rightflash != rhs->idubcm_ctrl_rightflash) {
    return false;
  }
  // idubcm_ctrl_backlight
  if (lhs->idubcm_ctrl_backlight != rhs->idubcm_ctrl_backlight) {
    return false;
  }
  // idubcm_ctrl_brakelight
  if (lhs->idubcm_ctrl_brakelight != rhs->idubcm_ctrl_brakelight) {
    return false;
  }
  // idubcm_ctrl_siren
  if (lhs->idubcm_ctrl_siren != rhs->idubcm_ctrl_siren) {
    return false;
  }
  // idubcm_ctrl_voice
  if (lhs->idubcm_ctrl_voice != rhs->idubcm_ctrl_voice) {
    return false;
  }
  // idubcm_ctrl_doubleflash
  if (lhs->idubcm_ctrl_doubleflash != rhs->idubcm_ctrl_doubleflash) {
    return false;
  }
  // idumcu_ctrl_tgtsped
  if (lhs->idumcu_ctrl_tgtsped != rhs->idumcu_ctrl_tgtsped) {
    return false;
  }
  // idumcu_ctrl_tgtacc
  if (lhs->idumcu_ctrl_tgtacc != rhs->idumcu_ctrl_tgtacc) {
    return false;
  }
  // idumcu_ctrl_tgttorq
  if (lhs->idumcu_ctrl_tgttorq != rhs->idumcu_ctrl_tgttorq) {
    return false;
  }
  // idueps_ctrl_tgtangle
  if (lhs->idueps_ctrl_tgtangle != rhs->idueps_ctrl_tgtangle) {
    return false;
  }
  // iduehb_ctrl_tgtdece
  if (lhs->iduehb_ctrl_tgtdece != rhs->iduehb_ctrl_tgtdece) {
    return false;
  }
  return true;
}

bool
sensor_driver_msgs__msg__ChassisCanSended__copy(
  const sensor_driver_msgs__msg__ChassisCanSended * input,
  sensor_driver_msgs__msg__ChassisCanSended * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // iduvcu_ctrl_workmod
  output->iduvcu_ctrl_workmod = input->iduvcu_ctrl_workmod;
  // iduvcu_ctrl_estop
  output->iduvcu_ctrl_estop = input->iduvcu_ctrl_estop;
  // iduvcu_ctrl_restop
  output->iduvcu_ctrl_restop = input->iduvcu_ctrl_restop;
  // iduvcu_ctrl_rollcnt
  output->iduvcu_ctrl_rollcnt = input->iduvcu_ctrl_rollcnt;
  // iduvcu_ctrl_checksum
  output->iduvcu_ctrl_checksum = input->iduvcu_ctrl_checksum;
  // idumcu_ctrl_workmod
  output->idumcu_ctrl_workmod = input->idumcu_ctrl_workmod;
  // idumcu_ctrl_rnd
  output->idumcu_ctrl_rnd = input->idumcu_ctrl_rnd;
  // iduepb_ctrl_reqpark
  output->iduepb_ctrl_reqpark = input->iduepb_ctrl_reqpark;
  // iduehb_ctrl_brakmod
  output->iduehb_ctrl_brakmod = input->iduehb_ctrl_brakmod;
  // iduehb_ctrl_tgtpressure
  output->iduehb_ctrl_tgtpressure = input->iduehb_ctrl_tgtpressure;
  // idubms_ctrl_power
  output->idubms_ctrl_power = input->idubms_ctrl_power;
  // idubcm_ctrl_headlight
  output->idubcm_ctrl_headlight = input->idubcm_ctrl_headlight;
  // idubcm_ctrl_leftflash
  output->idubcm_ctrl_leftflash = input->idubcm_ctrl_leftflash;
  // idubcm_ctrl_rightflash
  output->idubcm_ctrl_rightflash = input->idubcm_ctrl_rightflash;
  // idubcm_ctrl_backlight
  output->idubcm_ctrl_backlight = input->idubcm_ctrl_backlight;
  // idubcm_ctrl_brakelight
  output->idubcm_ctrl_brakelight = input->idubcm_ctrl_brakelight;
  // idubcm_ctrl_siren
  output->idubcm_ctrl_siren = input->idubcm_ctrl_siren;
  // idubcm_ctrl_voice
  output->idubcm_ctrl_voice = input->idubcm_ctrl_voice;
  // idubcm_ctrl_doubleflash
  output->idubcm_ctrl_doubleflash = input->idubcm_ctrl_doubleflash;
  // idumcu_ctrl_tgtsped
  output->idumcu_ctrl_tgtsped = input->idumcu_ctrl_tgtsped;
  // idumcu_ctrl_tgtacc
  output->idumcu_ctrl_tgtacc = input->idumcu_ctrl_tgtacc;
  // idumcu_ctrl_tgttorq
  output->idumcu_ctrl_tgttorq = input->idumcu_ctrl_tgttorq;
  // idueps_ctrl_tgtangle
  output->idueps_ctrl_tgtangle = input->idueps_ctrl_tgtangle;
  // iduehb_ctrl_tgtdece
  output->iduehb_ctrl_tgtdece = input->iduehb_ctrl_tgtdece;
  return true;
}

sensor_driver_msgs__msg__ChassisCanSended *
sensor_driver_msgs__msg__ChassisCanSended__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sensor_driver_msgs__msg__ChassisCanSended * msg = (sensor_driver_msgs__msg__ChassisCanSended *)allocator.allocate(sizeof(sensor_driver_msgs__msg__ChassisCanSended), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(sensor_driver_msgs__msg__ChassisCanSended));
  bool success = sensor_driver_msgs__msg__ChassisCanSended__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
sensor_driver_msgs__msg__ChassisCanSended__destroy(sensor_driver_msgs__msg__ChassisCanSended * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    sensor_driver_msgs__msg__ChassisCanSended__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
sensor_driver_msgs__msg__ChassisCanSended__Sequence__init(sensor_driver_msgs__msg__ChassisCanSended__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sensor_driver_msgs__msg__ChassisCanSended * data = NULL;

  if (size) {
    data = (sensor_driver_msgs__msg__ChassisCanSended *)allocator.zero_allocate(size, sizeof(sensor_driver_msgs__msg__ChassisCanSended), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = sensor_driver_msgs__msg__ChassisCanSended__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        sensor_driver_msgs__msg__ChassisCanSended__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
sensor_driver_msgs__msg__ChassisCanSended__Sequence__fini(sensor_driver_msgs__msg__ChassisCanSended__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      sensor_driver_msgs__msg__ChassisCanSended__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

sensor_driver_msgs__msg__ChassisCanSended__Sequence *
sensor_driver_msgs__msg__ChassisCanSended__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sensor_driver_msgs__msg__ChassisCanSended__Sequence * array = (sensor_driver_msgs__msg__ChassisCanSended__Sequence *)allocator.allocate(sizeof(sensor_driver_msgs__msg__ChassisCanSended__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = sensor_driver_msgs__msg__ChassisCanSended__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
sensor_driver_msgs__msg__ChassisCanSended__Sequence__destroy(sensor_driver_msgs__msg__ChassisCanSended__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    sensor_driver_msgs__msg__ChassisCanSended__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
sensor_driver_msgs__msg__ChassisCanSended__Sequence__are_equal(const sensor_driver_msgs__msg__ChassisCanSended__Sequence * lhs, const sensor_driver_msgs__msg__ChassisCanSended__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!sensor_driver_msgs__msg__ChassisCanSended__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
sensor_driver_msgs__msg__ChassisCanSended__Sequence__copy(
  const sensor_driver_msgs__msg__ChassisCanSended__Sequence * input,
  sensor_driver_msgs__msg__ChassisCanSended__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(sensor_driver_msgs__msg__ChassisCanSended);
    sensor_driver_msgs__msg__ChassisCanSended * data =
      (sensor_driver_msgs__msg__ChassisCanSended *)realloc(output->data, allocation_size);
    if (!data) {
      return false;
    }
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!sensor_driver_msgs__msg__ChassisCanSended__init(&data[i])) {
        /* free currently allocated and return false */
        for (; i-- > output->capacity; ) {
          sensor_driver_msgs__msg__ChassisCanSended__fini(&data[i]);
        }
        free(data);
        return false;
      }
    }
    output->data = data;
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!sensor_driver_msgs__msg__ChassisCanSended__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
