// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from sensor_driver_msgs:msg/ImuHwt9073can.idl
// generated code does not contain a copyright notice

#ifndef SENSOR_DRIVER_MSGS__MSG__DETAIL__IMU_HWT9073CAN__STRUCT_H_
#define SENSOR_DRIVER_MSGS__MSG__DETAIL__IMU_HWT9073CAN__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"

// Struct defined in msg/ImuHwt9073can in the package sensor_driver_msgs.
typedef struct sensor_driver_msgs__msg__ImuHwt9073can
{
  std_msgs__msg__Header header;
  int16_t time_year;
  int16_t time_month;
  int16_t time_day;
  int16_t time_hour;
  int16_t time_min;
  int16_t time_sec;
  int16_t acc_x_raw;
  int16_t acc_y_raw;
  int16_t acc_z_raw;
  int16_t a_vel_x_raw;
  int16_t a_vel_y_raw;
  int16_t a_vel_z_raw;
  int32_t angle_x_raw;
  int32_t angle_y_raw;
  int32_t angle_z_raw;
  int16_t mag_x;
  int16_t mag_y;
  int16_t mag_z;
  double acc_x;
  double acc_y;
  double acc_z;
  double a_vel_x;
  double a_vel_y;
  double a_vel_z;
  double angle_x;
  double angle_y;
  double angle_z;
} sensor_driver_msgs__msg__ImuHwt9073can;

// Struct for a sequence of sensor_driver_msgs__msg__ImuHwt9073can.
typedef struct sensor_driver_msgs__msg__ImuHwt9073can__Sequence
{
  sensor_driver_msgs__msg__ImuHwt9073can * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sensor_driver_msgs__msg__ImuHwt9073can__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SENSOR_DRIVER_MSGS__MSG__DETAIL__IMU_HWT9073CAN__STRUCT_H_
