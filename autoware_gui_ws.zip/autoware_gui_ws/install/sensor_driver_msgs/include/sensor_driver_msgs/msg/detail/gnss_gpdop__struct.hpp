// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from sensor_driver_msgs:msg/GnssGpdop.idl
// generated code does not contain a copyright notice

#ifndef SENSOR_DRIVER_MSGS__MSG__DETAIL__GNSS_GPDOP__STRUCT_HPP_
#define SENSOR_DRIVER_MSGS__MSG__DETAIL__GNSS_GPDOP__STRUCT_HPP_

#include <rosidl_runtime_cpp/bounded_vector.hpp>
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__sensor_driver_msgs__msg__GnssGpdop __attribute__((deprecated))
#else
# define DEPRECATED__sensor_driver_msgs__msg__GnssGpdop __declspec(deprecated)
#endif

namespace sensor_driver_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct GnssGpdop_
{
  using Type = GnssGpdop_<ContainerAllocator>;

  explicit GnssGpdop_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->data_id = "";
      this->utc_time = 0.0;
      this->pdop = 0.0;
      this->hdop = 0.0;
      this->vdop = 0.0;
      this->tdop = 0.0;
      this->gdop = 0.0;
      this->cs = "";
    }
  }

  explicit GnssGpdop_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init),
    data_id(_alloc),
    cs(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->data_id = "";
      this->utc_time = 0.0;
      this->pdop = 0.0;
      this->hdop = 0.0;
      this->vdop = 0.0;
      this->tdop = 0.0;
      this->gdop = 0.0;
      this->cs = "";
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _data_id_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _data_id_type data_id;
  using _utc_time_type =
    double;
  _utc_time_type utc_time;
  using _pdop_type =
    double;
  _pdop_type pdop;
  using _hdop_type =
    double;
  _hdop_type hdop;
  using _vdop_type =
    double;
  _vdop_type vdop;
  using _tdop_type =
    double;
  _tdop_type tdop;
  using _gdop_type =
    double;
  _gdop_type gdop;
  using _cs_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _cs_type cs;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__data_id(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->data_id = _arg;
    return *this;
  }
  Type & set__utc_time(
    const double & _arg)
  {
    this->utc_time = _arg;
    return *this;
  }
  Type & set__pdop(
    const double & _arg)
  {
    this->pdop = _arg;
    return *this;
  }
  Type & set__hdop(
    const double & _arg)
  {
    this->hdop = _arg;
    return *this;
  }
  Type & set__vdop(
    const double & _arg)
  {
    this->vdop = _arg;
    return *this;
  }
  Type & set__tdop(
    const double & _arg)
  {
    this->tdop = _arg;
    return *this;
  }
  Type & set__gdop(
    const double & _arg)
  {
    this->gdop = _arg;
    return *this;
  }
  Type & set__cs(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->cs = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    sensor_driver_msgs::msg::GnssGpdop_<ContainerAllocator> *;
  using ConstRawPtr =
    const sensor_driver_msgs::msg::GnssGpdop_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<sensor_driver_msgs::msg::GnssGpdop_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<sensor_driver_msgs::msg::GnssGpdop_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      sensor_driver_msgs::msg::GnssGpdop_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<sensor_driver_msgs::msg::GnssGpdop_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      sensor_driver_msgs::msg::GnssGpdop_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<sensor_driver_msgs::msg::GnssGpdop_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<sensor_driver_msgs::msg::GnssGpdop_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<sensor_driver_msgs::msg::GnssGpdop_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__sensor_driver_msgs__msg__GnssGpdop
    std::shared_ptr<sensor_driver_msgs::msg::GnssGpdop_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__sensor_driver_msgs__msg__GnssGpdop
    std::shared_ptr<sensor_driver_msgs::msg::GnssGpdop_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const GnssGpdop_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->data_id != other.data_id) {
      return false;
    }
    if (this->utc_time != other.utc_time) {
      return false;
    }
    if (this->pdop != other.pdop) {
      return false;
    }
    if (this->hdop != other.hdop) {
      return false;
    }
    if (this->vdop != other.vdop) {
      return false;
    }
    if (this->tdop != other.tdop) {
      return false;
    }
    if (this->gdop != other.gdop) {
      return false;
    }
    if (this->cs != other.cs) {
      return false;
    }
    return true;
  }
  bool operator!=(const GnssGpdop_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct GnssGpdop_

// alias to use template instance with default allocator
using GnssGpdop =
  sensor_driver_msgs::msg::GnssGpdop_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace sensor_driver_msgs

#endif  // SENSOR_DRIVER_MSGS__MSG__DETAIL__GNSS_GPDOP__STRUCT_HPP_
