// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from sensor_driver_msgs:msg/ImuHwt9073can.idl
// generated code does not contain a copyright notice
#include "sensor_driver_msgs/msg/detail/imu_hwt9073can__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"

bool
sensor_driver_msgs__msg__ImuHwt9073can__init(sensor_driver_msgs__msg__ImuHwt9073can * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    sensor_driver_msgs__msg__ImuHwt9073can__fini(msg);
    return false;
  }
  // time_year
  // time_month
  // time_day
  // time_hour
  // time_min
  // time_sec
  // acc_x_raw
  // acc_y_raw
  // acc_z_raw
  // a_vel_x_raw
  // a_vel_y_raw
  // a_vel_z_raw
  // angle_x_raw
  // angle_y_raw
  // angle_z_raw
  // mag_x
  // mag_y
  // mag_z
  // acc_x
  // acc_y
  // acc_z
  // a_vel_x
  // a_vel_y
  // a_vel_z
  // angle_x
  // angle_y
  // angle_z
  return true;
}

void
sensor_driver_msgs__msg__ImuHwt9073can__fini(sensor_driver_msgs__msg__ImuHwt9073can * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // time_year
  // time_month
  // time_day
  // time_hour
  // time_min
  // time_sec
  // acc_x_raw
  // acc_y_raw
  // acc_z_raw
  // a_vel_x_raw
  // a_vel_y_raw
  // a_vel_z_raw
  // angle_x_raw
  // angle_y_raw
  // angle_z_raw
  // mag_x
  // mag_y
  // mag_z
  // acc_x
  // acc_y
  // acc_z
  // a_vel_x
  // a_vel_y
  // a_vel_z
  // angle_x
  // angle_y
  // angle_z
}

bool
sensor_driver_msgs__msg__ImuHwt9073can__are_equal(const sensor_driver_msgs__msg__ImuHwt9073can * lhs, const sensor_driver_msgs__msg__ImuHwt9073can * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // time_year
  if (lhs->time_year != rhs->time_year) {
    return false;
  }
  // time_month
  if (lhs->time_month != rhs->time_month) {
    return false;
  }
  // time_day
  if (lhs->time_day != rhs->time_day) {
    return false;
  }
  // time_hour
  if (lhs->time_hour != rhs->time_hour) {
    return false;
  }
  // time_min
  if (lhs->time_min != rhs->time_min) {
    return false;
  }
  // time_sec
  if (lhs->time_sec != rhs->time_sec) {
    return false;
  }
  // acc_x_raw
  if (lhs->acc_x_raw != rhs->acc_x_raw) {
    return false;
  }
  // acc_y_raw
  if (lhs->acc_y_raw != rhs->acc_y_raw) {
    return false;
  }
  // acc_z_raw
  if (lhs->acc_z_raw != rhs->acc_z_raw) {
    return false;
  }
  // a_vel_x_raw
  if (lhs->a_vel_x_raw != rhs->a_vel_x_raw) {
    return false;
  }
  // a_vel_y_raw
  if (lhs->a_vel_y_raw != rhs->a_vel_y_raw) {
    return false;
  }
  // a_vel_z_raw
  if (lhs->a_vel_z_raw != rhs->a_vel_z_raw) {
    return false;
  }
  // angle_x_raw
  if (lhs->angle_x_raw != rhs->angle_x_raw) {
    return false;
  }
  // angle_y_raw
  if (lhs->angle_y_raw != rhs->angle_y_raw) {
    return false;
  }
  // angle_z_raw
  if (lhs->angle_z_raw != rhs->angle_z_raw) {
    return false;
  }
  // mag_x
  if (lhs->mag_x != rhs->mag_x) {
    return false;
  }
  // mag_y
  if (lhs->mag_y != rhs->mag_y) {
    return false;
  }
  // mag_z
  if (lhs->mag_z != rhs->mag_z) {
    return false;
  }
  // acc_x
  if (lhs->acc_x != rhs->acc_x) {
    return false;
  }
  // acc_y
  if (lhs->acc_y != rhs->acc_y) {
    return false;
  }
  // acc_z
  if (lhs->acc_z != rhs->acc_z) {
    return false;
  }
  // a_vel_x
  if (lhs->a_vel_x != rhs->a_vel_x) {
    return false;
  }
  // a_vel_y
  if (lhs->a_vel_y != rhs->a_vel_y) {
    return false;
  }
  // a_vel_z
  if (lhs->a_vel_z != rhs->a_vel_z) {
    return false;
  }
  // angle_x
  if (lhs->angle_x != rhs->angle_x) {
    return false;
  }
  // angle_y
  if (lhs->angle_y != rhs->angle_y) {
    return false;
  }
  // angle_z
  if (lhs->angle_z != rhs->angle_z) {
    return false;
  }
  return true;
}

bool
sensor_driver_msgs__msg__ImuHwt9073can__copy(
  const sensor_driver_msgs__msg__ImuHwt9073can * input,
  sensor_driver_msgs__msg__ImuHwt9073can * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // time_year
  output->time_year = input->time_year;
  // time_month
  output->time_month = input->time_month;
  // time_day
  output->time_day = input->time_day;
  // time_hour
  output->time_hour = input->time_hour;
  // time_min
  output->time_min = input->time_min;
  // time_sec
  output->time_sec = input->time_sec;
  // acc_x_raw
  output->acc_x_raw = input->acc_x_raw;
  // acc_y_raw
  output->acc_y_raw = input->acc_y_raw;
  // acc_z_raw
  output->acc_z_raw = input->acc_z_raw;
  // a_vel_x_raw
  output->a_vel_x_raw = input->a_vel_x_raw;
  // a_vel_y_raw
  output->a_vel_y_raw = input->a_vel_y_raw;
  // a_vel_z_raw
  output->a_vel_z_raw = input->a_vel_z_raw;
  // angle_x_raw
  output->angle_x_raw = input->angle_x_raw;
  // angle_y_raw
  output->angle_y_raw = input->angle_y_raw;
  // angle_z_raw
  output->angle_z_raw = input->angle_z_raw;
  // mag_x
  output->mag_x = input->mag_x;
  // mag_y
  output->mag_y = input->mag_y;
  // mag_z
  output->mag_z = input->mag_z;
  // acc_x
  output->acc_x = input->acc_x;
  // acc_y
  output->acc_y = input->acc_y;
  // acc_z
  output->acc_z = input->acc_z;
  // a_vel_x
  output->a_vel_x = input->a_vel_x;
  // a_vel_y
  output->a_vel_y = input->a_vel_y;
  // a_vel_z
  output->a_vel_z = input->a_vel_z;
  // angle_x
  output->angle_x = input->angle_x;
  // angle_y
  output->angle_y = input->angle_y;
  // angle_z
  output->angle_z = input->angle_z;
  return true;
}

sensor_driver_msgs__msg__ImuHwt9073can *
sensor_driver_msgs__msg__ImuHwt9073can__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sensor_driver_msgs__msg__ImuHwt9073can * msg = (sensor_driver_msgs__msg__ImuHwt9073can *)allocator.allocate(sizeof(sensor_driver_msgs__msg__ImuHwt9073can), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(sensor_driver_msgs__msg__ImuHwt9073can));
  bool success = sensor_driver_msgs__msg__ImuHwt9073can__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
sensor_driver_msgs__msg__ImuHwt9073can__destroy(sensor_driver_msgs__msg__ImuHwt9073can * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    sensor_driver_msgs__msg__ImuHwt9073can__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
sensor_driver_msgs__msg__ImuHwt9073can__Sequence__init(sensor_driver_msgs__msg__ImuHwt9073can__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sensor_driver_msgs__msg__ImuHwt9073can * data = NULL;

  if (size) {
    data = (sensor_driver_msgs__msg__ImuHwt9073can *)allocator.zero_allocate(size, sizeof(sensor_driver_msgs__msg__ImuHwt9073can), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = sensor_driver_msgs__msg__ImuHwt9073can__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        sensor_driver_msgs__msg__ImuHwt9073can__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
sensor_driver_msgs__msg__ImuHwt9073can__Sequence__fini(sensor_driver_msgs__msg__ImuHwt9073can__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      sensor_driver_msgs__msg__ImuHwt9073can__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

sensor_driver_msgs__msg__ImuHwt9073can__Sequence *
sensor_driver_msgs__msg__ImuHwt9073can__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sensor_driver_msgs__msg__ImuHwt9073can__Sequence * array = (sensor_driver_msgs__msg__ImuHwt9073can__Sequence *)allocator.allocate(sizeof(sensor_driver_msgs__msg__ImuHwt9073can__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = sensor_driver_msgs__msg__ImuHwt9073can__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
sensor_driver_msgs__msg__ImuHwt9073can__Sequence__destroy(sensor_driver_msgs__msg__ImuHwt9073can__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    sensor_driver_msgs__msg__ImuHwt9073can__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
sensor_driver_msgs__msg__ImuHwt9073can__Sequence__are_equal(const sensor_driver_msgs__msg__ImuHwt9073can__Sequence * lhs, const sensor_driver_msgs__msg__ImuHwt9073can__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!sensor_driver_msgs__msg__ImuHwt9073can__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
sensor_driver_msgs__msg__ImuHwt9073can__Sequence__copy(
  const sensor_driver_msgs__msg__ImuHwt9073can__Sequence * input,
  sensor_driver_msgs__msg__ImuHwt9073can__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(sensor_driver_msgs__msg__ImuHwt9073can);
    sensor_driver_msgs__msg__ImuHwt9073can * data =
      (sensor_driver_msgs__msg__ImuHwt9073can *)realloc(output->data, allocation_size);
    if (!data) {
      return false;
    }
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!sensor_driver_msgs__msg__ImuHwt9073can__init(&data[i])) {
        /* free currently allocated and return false */
        for (; i-- > output->capacity; ) {
          sensor_driver_msgs__msg__ImuHwt9073can__fini(&data[i]);
        }
        free(data);
        return false;
      }
    }
    output->data = data;
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!sensor_driver_msgs__msg__ImuHwt9073can__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
