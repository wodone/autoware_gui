// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from sensor_driver_msgs:msg/InsByins.idl
// generated code does not contain a copyright notice

#ifndef SENSOR_DRIVER_MSGS__MSG__DETAIL__INS_BYINS__STRUCT_H_
#define SENSOR_DRIVER_MSGS__MSG__DETAIL__INS_BYINS__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'data_id'
// Member 'serial_number'
// Member 'cs'
#include "rosidl_runtime_c/string.h"

// Struct defined in msg/InsByins in the package sensor_driver_msgs.
typedef struct sensor_driver_msgs__msg__InsByins
{
  std_msgs__msg__Header header;
  rosidl_runtime_c__String data_id;
  rosidl_runtime_c__String serial_number;
  double utc_time;
  double gps_week_sec;
  double ins_latitude;
  double ins_longitude;
  double ins_altitude;
  double yaw;
  double pitch;
  double roll;
  double velocity_front;
  double velocity_right;
  double velocity_up;
  double accelerate_right;
  double accelerate_front;
  double accelerate_up;
  double angular_velocity_right_origin;
  double angular_velocity_front_origin;
  double angular_velocity_up_origin;
  double angular_velocity_right_judged;
  double angular_velocity_front_judged;
  double angular_velocity_up_judged;
  uint16_t ins_state;
  uint16_t gnss_vector_state;
  uint16_t satellite_num;
  double rtk_delay;
  double bk_1;
  double bk_2;
  double bk_3;
  double accelerate_north;
  double accelerate_east;
  double accelerate_ground;
  double gnss_latitude;
  double gnss_longitude;
  double gnss_altitude;
  uint16_t gnss_location_state;
  uint16_t error;
  double velocity_east;
  double velocity_north;
  double velocity_sky;
  rosidl_runtime_c__String cs;
} sensor_driver_msgs__msg__InsByins;

// Struct for a sequence of sensor_driver_msgs__msg__InsByins.
typedef struct sensor_driver_msgs__msg__InsByins__Sequence
{
  sensor_driver_msgs__msg__InsByins * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sensor_driver_msgs__msg__InsByins__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SENSOR_DRIVER_MSGS__MSG__DETAIL__INS_BYINS__STRUCT_H_
