// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sensor_driver_msgs:msg/GnssGpfpd.idl
// generated code does not contain a copyright notice

#ifndef SENSOR_DRIVER_MSGS__MSG__DETAIL__GNSS_GPFPD__BUILDER_HPP_
#define SENSOR_DRIVER_MSGS__MSG__DETAIL__GNSS_GPFPD__BUILDER_HPP_

#include "sensor_driver_msgs/msg/detail/gnss_gpfpd__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace sensor_driver_msgs
{

namespace msg
{

namespace builder
{

class Init_GnssGpfpd_cs
{
public:
  explicit Init_GnssGpfpd_cs(::sensor_driver_msgs::msg::GnssGpfpd & msg)
  : msg_(msg)
  {}
  ::sensor_driver_msgs::msg::GnssGpfpd cs(::sensor_driver_msgs::msg::GnssGpfpd::_cs_type arg)
  {
    msg_.cs = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpfpd msg_;
};

class Init_GnssGpfpd_state
{
public:
  explicit Init_GnssGpfpd_state(::sensor_driver_msgs::msg::GnssGpfpd & msg)
  : msg_(msg)
  {}
  Init_GnssGpfpd_cs state(::sensor_driver_msgs::msg::GnssGpfpd::_state_type arg)
  {
    msg_.state = std::move(arg);
    return Init_GnssGpfpd_cs(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpfpd msg_;
};

class Init_GnssGpfpd_satellite_num_2
{
public:
  explicit Init_GnssGpfpd_satellite_num_2(::sensor_driver_msgs::msg::GnssGpfpd & msg)
  : msg_(msg)
  {}
  Init_GnssGpfpd_state satellite_num_2(::sensor_driver_msgs::msg::GnssGpfpd::_satellite_num_2_type arg)
  {
    msg_.satellite_num_2 = std::move(arg);
    return Init_GnssGpfpd_state(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpfpd msg_;
};

class Init_GnssGpfpd_satellite_num_1
{
public:
  explicit Init_GnssGpfpd_satellite_num_1(::sensor_driver_msgs::msg::GnssGpfpd & msg)
  : msg_(msg)
  {}
  Init_GnssGpfpd_satellite_num_2 satellite_num_1(::sensor_driver_msgs::msg::GnssGpfpd::_satellite_num_1_type arg)
  {
    msg_.satellite_num_1 = std::move(arg);
    return Init_GnssGpfpd_satellite_num_2(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpfpd msg_;
};

class Init_GnssGpfpd_base_line
{
public:
  explicit Init_GnssGpfpd_base_line(::sensor_driver_msgs::msg::GnssGpfpd & msg)
  : msg_(msg)
  {}
  Init_GnssGpfpd_satellite_num_1 base_line(::sensor_driver_msgs::msg::GnssGpfpd::_base_line_type arg)
  {
    msg_.base_line = std::move(arg);
    return Init_GnssGpfpd_satellite_num_1(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpfpd msg_;
};

class Init_GnssGpfpd_velocity_sky
{
public:
  explicit Init_GnssGpfpd_velocity_sky(::sensor_driver_msgs::msg::GnssGpfpd & msg)
  : msg_(msg)
  {}
  Init_GnssGpfpd_base_line velocity_sky(::sensor_driver_msgs::msg::GnssGpfpd::_velocity_sky_type arg)
  {
    msg_.velocity_sky = std::move(arg);
    return Init_GnssGpfpd_base_line(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpfpd msg_;
};

class Init_GnssGpfpd_velocity_north
{
public:
  explicit Init_GnssGpfpd_velocity_north(::sensor_driver_msgs::msg::GnssGpfpd & msg)
  : msg_(msg)
  {}
  Init_GnssGpfpd_velocity_sky velocity_north(::sensor_driver_msgs::msg::GnssGpfpd::_velocity_north_type arg)
  {
    msg_.velocity_north = std::move(arg);
    return Init_GnssGpfpd_velocity_sky(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpfpd msg_;
};

class Init_GnssGpfpd_velocity_east
{
public:
  explicit Init_GnssGpfpd_velocity_east(::sensor_driver_msgs::msg::GnssGpfpd & msg)
  : msg_(msg)
  {}
  Init_GnssGpfpd_velocity_north velocity_east(::sensor_driver_msgs::msg::GnssGpfpd::_velocity_east_type arg)
  {
    msg_.velocity_east = std::move(arg);
    return Init_GnssGpfpd_velocity_north(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpfpd msg_;
};

class Init_GnssGpfpd_altitude
{
public:
  explicit Init_GnssGpfpd_altitude(::sensor_driver_msgs::msg::GnssGpfpd & msg)
  : msg_(msg)
  {}
  Init_GnssGpfpd_velocity_east altitude(::sensor_driver_msgs::msg::GnssGpfpd::_altitude_type arg)
  {
    msg_.altitude = std::move(arg);
    return Init_GnssGpfpd_velocity_east(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpfpd msg_;
};

class Init_GnssGpfpd_longitude
{
public:
  explicit Init_GnssGpfpd_longitude(::sensor_driver_msgs::msg::GnssGpfpd & msg)
  : msg_(msg)
  {}
  Init_GnssGpfpd_altitude longitude(::sensor_driver_msgs::msg::GnssGpfpd::_longitude_type arg)
  {
    msg_.longitude = std::move(arg);
    return Init_GnssGpfpd_altitude(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpfpd msg_;
};

class Init_GnssGpfpd_latitude
{
public:
  explicit Init_GnssGpfpd_latitude(::sensor_driver_msgs::msg::GnssGpfpd & msg)
  : msg_(msg)
  {}
  Init_GnssGpfpd_longitude latitude(::sensor_driver_msgs::msg::GnssGpfpd::_latitude_type arg)
  {
    msg_.latitude = std::move(arg);
    return Init_GnssGpfpd_longitude(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpfpd msg_;
};

class Init_GnssGpfpd_roll
{
public:
  explicit Init_GnssGpfpd_roll(::sensor_driver_msgs::msg::GnssGpfpd & msg)
  : msg_(msg)
  {}
  Init_GnssGpfpd_latitude roll(::sensor_driver_msgs::msg::GnssGpfpd::_roll_type arg)
  {
    msg_.roll = std::move(arg);
    return Init_GnssGpfpd_latitude(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpfpd msg_;
};

class Init_GnssGpfpd_pitch
{
public:
  explicit Init_GnssGpfpd_pitch(::sensor_driver_msgs::msg::GnssGpfpd & msg)
  : msg_(msg)
  {}
  Init_GnssGpfpd_roll pitch(::sensor_driver_msgs::msg::GnssGpfpd::_pitch_type arg)
  {
    msg_.pitch = std::move(arg);
    return Init_GnssGpfpd_roll(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpfpd msg_;
};

class Init_GnssGpfpd_yaw
{
public:
  explicit Init_GnssGpfpd_yaw(::sensor_driver_msgs::msg::GnssGpfpd & msg)
  : msg_(msg)
  {}
  Init_GnssGpfpd_pitch yaw(::sensor_driver_msgs::msg::GnssGpfpd::_yaw_type arg)
  {
    msg_.yaw = std::move(arg);
    return Init_GnssGpfpd_pitch(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpfpd msg_;
};

class Init_GnssGpfpd_gps_time
{
public:
  explicit Init_GnssGpfpd_gps_time(::sensor_driver_msgs::msg::GnssGpfpd & msg)
  : msg_(msg)
  {}
  Init_GnssGpfpd_yaw gps_time(::sensor_driver_msgs::msg::GnssGpfpd::_gps_time_type arg)
  {
    msg_.gps_time = std::move(arg);
    return Init_GnssGpfpd_yaw(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpfpd msg_;
};

class Init_GnssGpfpd_gps_week
{
public:
  explicit Init_GnssGpfpd_gps_week(::sensor_driver_msgs::msg::GnssGpfpd & msg)
  : msg_(msg)
  {}
  Init_GnssGpfpd_gps_time gps_week(::sensor_driver_msgs::msg::GnssGpfpd::_gps_week_type arg)
  {
    msg_.gps_week = std::move(arg);
    return Init_GnssGpfpd_gps_time(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpfpd msg_;
};

class Init_GnssGpfpd_data_id
{
public:
  explicit Init_GnssGpfpd_data_id(::sensor_driver_msgs::msg::GnssGpfpd & msg)
  : msg_(msg)
  {}
  Init_GnssGpfpd_gps_week data_id(::sensor_driver_msgs::msg::GnssGpfpd::_data_id_type arg)
  {
    msg_.data_id = std::move(arg);
    return Init_GnssGpfpd_gps_week(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpfpd msg_;
};

class Init_GnssGpfpd_header
{
public:
  Init_GnssGpfpd_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_GnssGpfpd_data_id header(::sensor_driver_msgs::msg::GnssGpfpd::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_GnssGpfpd_data_id(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpfpd msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sensor_driver_msgs::msg::GnssGpfpd>()
{
  return sensor_driver_msgs::msg::builder::Init_GnssGpfpd_header();
}

}  // namespace sensor_driver_msgs

#endif  // SENSOR_DRIVER_MSGS__MSG__DETAIL__GNSS_GPFPD__BUILDER_HPP_
