// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from sensor_driver_msgs:msg/GnssGpgst.idl
// generated code does not contain a copyright notice
#include "sensor_driver_msgs/msg/detail/gnss_gpgst__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"
// Member `data_id`
// Member `cs`
#include "rosidl_runtime_c/string_functions.h"

bool
sensor_driver_msgs__msg__GnssGpgst__init(sensor_driver_msgs__msg__GnssGpgst * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    sensor_driver_msgs__msg__GnssGpgst__fini(msg);
    return false;
  }
  // data_id
  if (!rosidl_runtime_c__String__init(&msg->data_id)) {
    sensor_driver_msgs__msg__GnssGpgst__fini(msg);
    return false;
  }
  // utc_time
  // rms_std
  // smjr_std
  // smnr_std
  // orient
  // lat_std
  // lon_std
  // alt_std
  // cs
  if (!rosidl_runtime_c__String__init(&msg->cs)) {
    sensor_driver_msgs__msg__GnssGpgst__fini(msg);
    return false;
  }
  return true;
}

void
sensor_driver_msgs__msg__GnssGpgst__fini(sensor_driver_msgs__msg__GnssGpgst * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // data_id
  rosidl_runtime_c__String__fini(&msg->data_id);
  // utc_time
  // rms_std
  // smjr_std
  // smnr_std
  // orient
  // lat_std
  // lon_std
  // alt_std
  // cs
  rosidl_runtime_c__String__fini(&msg->cs);
}

bool
sensor_driver_msgs__msg__GnssGpgst__are_equal(const sensor_driver_msgs__msg__GnssGpgst * lhs, const sensor_driver_msgs__msg__GnssGpgst * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // data_id
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->data_id), &(rhs->data_id)))
  {
    return false;
  }
  // utc_time
  if (lhs->utc_time != rhs->utc_time) {
    return false;
  }
  // rms_std
  if (lhs->rms_std != rhs->rms_std) {
    return false;
  }
  // smjr_std
  if (lhs->smjr_std != rhs->smjr_std) {
    return false;
  }
  // smnr_std
  if (lhs->smnr_std != rhs->smnr_std) {
    return false;
  }
  // orient
  if (lhs->orient != rhs->orient) {
    return false;
  }
  // lat_std
  if (lhs->lat_std != rhs->lat_std) {
    return false;
  }
  // lon_std
  if (lhs->lon_std != rhs->lon_std) {
    return false;
  }
  // alt_std
  if (lhs->alt_std != rhs->alt_std) {
    return false;
  }
  // cs
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->cs), &(rhs->cs)))
  {
    return false;
  }
  return true;
}

bool
sensor_driver_msgs__msg__GnssGpgst__copy(
  const sensor_driver_msgs__msg__GnssGpgst * input,
  sensor_driver_msgs__msg__GnssGpgst * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // data_id
  if (!rosidl_runtime_c__String__copy(
      &(input->data_id), &(output->data_id)))
  {
    return false;
  }
  // utc_time
  output->utc_time = input->utc_time;
  // rms_std
  output->rms_std = input->rms_std;
  // smjr_std
  output->smjr_std = input->smjr_std;
  // smnr_std
  output->smnr_std = input->smnr_std;
  // orient
  output->orient = input->orient;
  // lat_std
  output->lat_std = input->lat_std;
  // lon_std
  output->lon_std = input->lon_std;
  // alt_std
  output->alt_std = input->alt_std;
  // cs
  if (!rosidl_runtime_c__String__copy(
      &(input->cs), &(output->cs)))
  {
    return false;
  }
  return true;
}

sensor_driver_msgs__msg__GnssGpgst *
sensor_driver_msgs__msg__GnssGpgst__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sensor_driver_msgs__msg__GnssGpgst * msg = (sensor_driver_msgs__msg__GnssGpgst *)allocator.allocate(sizeof(sensor_driver_msgs__msg__GnssGpgst), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(sensor_driver_msgs__msg__GnssGpgst));
  bool success = sensor_driver_msgs__msg__GnssGpgst__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
sensor_driver_msgs__msg__GnssGpgst__destroy(sensor_driver_msgs__msg__GnssGpgst * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    sensor_driver_msgs__msg__GnssGpgst__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
sensor_driver_msgs__msg__GnssGpgst__Sequence__init(sensor_driver_msgs__msg__GnssGpgst__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sensor_driver_msgs__msg__GnssGpgst * data = NULL;

  if (size) {
    data = (sensor_driver_msgs__msg__GnssGpgst *)allocator.zero_allocate(size, sizeof(sensor_driver_msgs__msg__GnssGpgst), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = sensor_driver_msgs__msg__GnssGpgst__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        sensor_driver_msgs__msg__GnssGpgst__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
sensor_driver_msgs__msg__GnssGpgst__Sequence__fini(sensor_driver_msgs__msg__GnssGpgst__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      sensor_driver_msgs__msg__GnssGpgst__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

sensor_driver_msgs__msg__GnssGpgst__Sequence *
sensor_driver_msgs__msg__GnssGpgst__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sensor_driver_msgs__msg__GnssGpgst__Sequence * array = (sensor_driver_msgs__msg__GnssGpgst__Sequence *)allocator.allocate(sizeof(sensor_driver_msgs__msg__GnssGpgst__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = sensor_driver_msgs__msg__GnssGpgst__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
sensor_driver_msgs__msg__GnssGpgst__Sequence__destroy(sensor_driver_msgs__msg__GnssGpgst__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    sensor_driver_msgs__msg__GnssGpgst__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
sensor_driver_msgs__msg__GnssGpgst__Sequence__are_equal(const sensor_driver_msgs__msg__GnssGpgst__Sequence * lhs, const sensor_driver_msgs__msg__GnssGpgst__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!sensor_driver_msgs__msg__GnssGpgst__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
sensor_driver_msgs__msg__GnssGpgst__Sequence__copy(
  const sensor_driver_msgs__msg__GnssGpgst__Sequence * input,
  sensor_driver_msgs__msg__GnssGpgst__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(sensor_driver_msgs__msg__GnssGpgst);
    sensor_driver_msgs__msg__GnssGpgst * data =
      (sensor_driver_msgs__msg__GnssGpgst *)realloc(output->data, allocation_size);
    if (!data) {
      return false;
    }
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!sensor_driver_msgs__msg__GnssGpgst__init(&data[i])) {
        /* free currently allocated and return false */
        for (; i-- > output->capacity; ) {
          sensor_driver_msgs__msg__GnssGpgst__fini(&data[i]);
        }
        free(data);
        return false;
      }
    }
    output->data = data;
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!sensor_driver_msgs__msg__GnssGpgst__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
