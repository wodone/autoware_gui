// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sensor_driver_msgs:msg/InsByins.idl
// generated code does not contain a copyright notice

#ifndef SENSOR_DRIVER_MSGS__MSG__DETAIL__INS_BYINS__BUILDER_HPP_
#define SENSOR_DRIVER_MSGS__MSG__DETAIL__INS_BYINS__BUILDER_HPP_

#include "sensor_driver_msgs/msg/detail/ins_byins__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace sensor_driver_msgs
{

namespace msg
{

namespace builder
{

class Init_InsByins_cs
{
public:
  explicit Init_InsByins_cs(::sensor_driver_msgs::msg::InsByins & msg)
  : msg_(msg)
  {}
  ::sensor_driver_msgs::msg::InsByins cs(::sensor_driver_msgs::msg::InsByins::_cs_type arg)
  {
    msg_.cs = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sensor_driver_msgs::msg::InsByins msg_;
};

class Init_InsByins_velocity_sky
{
public:
  explicit Init_InsByins_velocity_sky(::sensor_driver_msgs::msg::InsByins & msg)
  : msg_(msg)
  {}
  Init_InsByins_cs velocity_sky(::sensor_driver_msgs::msg::InsByins::_velocity_sky_type arg)
  {
    msg_.velocity_sky = std::move(arg);
    return Init_InsByins_cs(msg_);
  }

private:
  ::sensor_driver_msgs::msg::InsByins msg_;
};

class Init_InsByins_velocity_north
{
public:
  explicit Init_InsByins_velocity_north(::sensor_driver_msgs::msg::InsByins & msg)
  : msg_(msg)
  {}
  Init_InsByins_velocity_sky velocity_north(::sensor_driver_msgs::msg::InsByins::_velocity_north_type arg)
  {
    msg_.velocity_north = std::move(arg);
    return Init_InsByins_velocity_sky(msg_);
  }

private:
  ::sensor_driver_msgs::msg::InsByins msg_;
};

class Init_InsByins_velocity_east
{
public:
  explicit Init_InsByins_velocity_east(::sensor_driver_msgs::msg::InsByins & msg)
  : msg_(msg)
  {}
  Init_InsByins_velocity_north velocity_east(::sensor_driver_msgs::msg::InsByins::_velocity_east_type arg)
  {
    msg_.velocity_east = std::move(arg);
    return Init_InsByins_velocity_north(msg_);
  }

private:
  ::sensor_driver_msgs::msg::InsByins msg_;
};

class Init_InsByins_error
{
public:
  explicit Init_InsByins_error(::sensor_driver_msgs::msg::InsByins & msg)
  : msg_(msg)
  {}
  Init_InsByins_velocity_east error(::sensor_driver_msgs::msg::InsByins::_error_type arg)
  {
    msg_.error = std::move(arg);
    return Init_InsByins_velocity_east(msg_);
  }

private:
  ::sensor_driver_msgs::msg::InsByins msg_;
};

class Init_InsByins_gnss_location_state
{
public:
  explicit Init_InsByins_gnss_location_state(::sensor_driver_msgs::msg::InsByins & msg)
  : msg_(msg)
  {}
  Init_InsByins_error gnss_location_state(::sensor_driver_msgs::msg::InsByins::_gnss_location_state_type arg)
  {
    msg_.gnss_location_state = std::move(arg);
    return Init_InsByins_error(msg_);
  }

private:
  ::sensor_driver_msgs::msg::InsByins msg_;
};

class Init_InsByins_gnss_altitude
{
public:
  explicit Init_InsByins_gnss_altitude(::sensor_driver_msgs::msg::InsByins & msg)
  : msg_(msg)
  {}
  Init_InsByins_gnss_location_state gnss_altitude(::sensor_driver_msgs::msg::InsByins::_gnss_altitude_type arg)
  {
    msg_.gnss_altitude = std::move(arg);
    return Init_InsByins_gnss_location_state(msg_);
  }

private:
  ::sensor_driver_msgs::msg::InsByins msg_;
};

class Init_InsByins_gnss_longitude
{
public:
  explicit Init_InsByins_gnss_longitude(::sensor_driver_msgs::msg::InsByins & msg)
  : msg_(msg)
  {}
  Init_InsByins_gnss_altitude gnss_longitude(::sensor_driver_msgs::msg::InsByins::_gnss_longitude_type arg)
  {
    msg_.gnss_longitude = std::move(arg);
    return Init_InsByins_gnss_altitude(msg_);
  }

private:
  ::sensor_driver_msgs::msg::InsByins msg_;
};

class Init_InsByins_gnss_latitude
{
public:
  explicit Init_InsByins_gnss_latitude(::sensor_driver_msgs::msg::InsByins & msg)
  : msg_(msg)
  {}
  Init_InsByins_gnss_longitude gnss_latitude(::sensor_driver_msgs::msg::InsByins::_gnss_latitude_type arg)
  {
    msg_.gnss_latitude = std::move(arg);
    return Init_InsByins_gnss_longitude(msg_);
  }

private:
  ::sensor_driver_msgs::msg::InsByins msg_;
};

class Init_InsByins_accelerate_ground
{
public:
  explicit Init_InsByins_accelerate_ground(::sensor_driver_msgs::msg::InsByins & msg)
  : msg_(msg)
  {}
  Init_InsByins_gnss_latitude accelerate_ground(::sensor_driver_msgs::msg::InsByins::_accelerate_ground_type arg)
  {
    msg_.accelerate_ground = std::move(arg);
    return Init_InsByins_gnss_latitude(msg_);
  }

private:
  ::sensor_driver_msgs::msg::InsByins msg_;
};

class Init_InsByins_accelerate_east
{
public:
  explicit Init_InsByins_accelerate_east(::sensor_driver_msgs::msg::InsByins & msg)
  : msg_(msg)
  {}
  Init_InsByins_accelerate_ground accelerate_east(::sensor_driver_msgs::msg::InsByins::_accelerate_east_type arg)
  {
    msg_.accelerate_east = std::move(arg);
    return Init_InsByins_accelerate_ground(msg_);
  }

private:
  ::sensor_driver_msgs::msg::InsByins msg_;
};

class Init_InsByins_accelerate_north
{
public:
  explicit Init_InsByins_accelerate_north(::sensor_driver_msgs::msg::InsByins & msg)
  : msg_(msg)
  {}
  Init_InsByins_accelerate_east accelerate_north(::sensor_driver_msgs::msg::InsByins::_accelerate_north_type arg)
  {
    msg_.accelerate_north = std::move(arg);
    return Init_InsByins_accelerate_east(msg_);
  }

private:
  ::sensor_driver_msgs::msg::InsByins msg_;
};

class Init_InsByins_bk_3
{
public:
  explicit Init_InsByins_bk_3(::sensor_driver_msgs::msg::InsByins & msg)
  : msg_(msg)
  {}
  Init_InsByins_accelerate_north bk_3(::sensor_driver_msgs::msg::InsByins::_bk_3_type arg)
  {
    msg_.bk_3 = std::move(arg);
    return Init_InsByins_accelerate_north(msg_);
  }

private:
  ::sensor_driver_msgs::msg::InsByins msg_;
};

class Init_InsByins_bk_2
{
public:
  explicit Init_InsByins_bk_2(::sensor_driver_msgs::msg::InsByins & msg)
  : msg_(msg)
  {}
  Init_InsByins_bk_3 bk_2(::sensor_driver_msgs::msg::InsByins::_bk_2_type arg)
  {
    msg_.bk_2 = std::move(arg);
    return Init_InsByins_bk_3(msg_);
  }

private:
  ::sensor_driver_msgs::msg::InsByins msg_;
};

class Init_InsByins_bk_1
{
public:
  explicit Init_InsByins_bk_1(::sensor_driver_msgs::msg::InsByins & msg)
  : msg_(msg)
  {}
  Init_InsByins_bk_2 bk_1(::sensor_driver_msgs::msg::InsByins::_bk_1_type arg)
  {
    msg_.bk_1 = std::move(arg);
    return Init_InsByins_bk_2(msg_);
  }

private:
  ::sensor_driver_msgs::msg::InsByins msg_;
};

class Init_InsByins_rtk_delay
{
public:
  explicit Init_InsByins_rtk_delay(::sensor_driver_msgs::msg::InsByins & msg)
  : msg_(msg)
  {}
  Init_InsByins_bk_1 rtk_delay(::sensor_driver_msgs::msg::InsByins::_rtk_delay_type arg)
  {
    msg_.rtk_delay = std::move(arg);
    return Init_InsByins_bk_1(msg_);
  }

private:
  ::sensor_driver_msgs::msg::InsByins msg_;
};

class Init_InsByins_satellite_num
{
public:
  explicit Init_InsByins_satellite_num(::sensor_driver_msgs::msg::InsByins & msg)
  : msg_(msg)
  {}
  Init_InsByins_rtk_delay satellite_num(::sensor_driver_msgs::msg::InsByins::_satellite_num_type arg)
  {
    msg_.satellite_num = std::move(arg);
    return Init_InsByins_rtk_delay(msg_);
  }

private:
  ::sensor_driver_msgs::msg::InsByins msg_;
};

class Init_InsByins_gnss_vector_state
{
public:
  explicit Init_InsByins_gnss_vector_state(::sensor_driver_msgs::msg::InsByins & msg)
  : msg_(msg)
  {}
  Init_InsByins_satellite_num gnss_vector_state(::sensor_driver_msgs::msg::InsByins::_gnss_vector_state_type arg)
  {
    msg_.gnss_vector_state = std::move(arg);
    return Init_InsByins_satellite_num(msg_);
  }

private:
  ::sensor_driver_msgs::msg::InsByins msg_;
};

class Init_InsByins_ins_state
{
public:
  explicit Init_InsByins_ins_state(::sensor_driver_msgs::msg::InsByins & msg)
  : msg_(msg)
  {}
  Init_InsByins_gnss_vector_state ins_state(::sensor_driver_msgs::msg::InsByins::_ins_state_type arg)
  {
    msg_.ins_state = std::move(arg);
    return Init_InsByins_gnss_vector_state(msg_);
  }

private:
  ::sensor_driver_msgs::msg::InsByins msg_;
};

class Init_InsByins_angular_velocity_up_judged
{
public:
  explicit Init_InsByins_angular_velocity_up_judged(::sensor_driver_msgs::msg::InsByins & msg)
  : msg_(msg)
  {}
  Init_InsByins_ins_state angular_velocity_up_judged(::sensor_driver_msgs::msg::InsByins::_angular_velocity_up_judged_type arg)
  {
    msg_.angular_velocity_up_judged = std::move(arg);
    return Init_InsByins_ins_state(msg_);
  }

private:
  ::sensor_driver_msgs::msg::InsByins msg_;
};

class Init_InsByins_angular_velocity_front_judged
{
public:
  explicit Init_InsByins_angular_velocity_front_judged(::sensor_driver_msgs::msg::InsByins & msg)
  : msg_(msg)
  {}
  Init_InsByins_angular_velocity_up_judged angular_velocity_front_judged(::sensor_driver_msgs::msg::InsByins::_angular_velocity_front_judged_type arg)
  {
    msg_.angular_velocity_front_judged = std::move(arg);
    return Init_InsByins_angular_velocity_up_judged(msg_);
  }

private:
  ::sensor_driver_msgs::msg::InsByins msg_;
};

class Init_InsByins_angular_velocity_right_judged
{
public:
  explicit Init_InsByins_angular_velocity_right_judged(::sensor_driver_msgs::msg::InsByins & msg)
  : msg_(msg)
  {}
  Init_InsByins_angular_velocity_front_judged angular_velocity_right_judged(::sensor_driver_msgs::msg::InsByins::_angular_velocity_right_judged_type arg)
  {
    msg_.angular_velocity_right_judged = std::move(arg);
    return Init_InsByins_angular_velocity_front_judged(msg_);
  }

private:
  ::sensor_driver_msgs::msg::InsByins msg_;
};

class Init_InsByins_angular_velocity_up_origin
{
public:
  explicit Init_InsByins_angular_velocity_up_origin(::sensor_driver_msgs::msg::InsByins & msg)
  : msg_(msg)
  {}
  Init_InsByins_angular_velocity_right_judged angular_velocity_up_origin(::sensor_driver_msgs::msg::InsByins::_angular_velocity_up_origin_type arg)
  {
    msg_.angular_velocity_up_origin = std::move(arg);
    return Init_InsByins_angular_velocity_right_judged(msg_);
  }

private:
  ::sensor_driver_msgs::msg::InsByins msg_;
};

class Init_InsByins_angular_velocity_front_origin
{
public:
  explicit Init_InsByins_angular_velocity_front_origin(::sensor_driver_msgs::msg::InsByins & msg)
  : msg_(msg)
  {}
  Init_InsByins_angular_velocity_up_origin angular_velocity_front_origin(::sensor_driver_msgs::msg::InsByins::_angular_velocity_front_origin_type arg)
  {
    msg_.angular_velocity_front_origin = std::move(arg);
    return Init_InsByins_angular_velocity_up_origin(msg_);
  }

private:
  ::sensor_driver_msgs::msg::InsByins msg_;
};

class Init_InsByins_angular_velocity_right_origin
{
public:
  explicit Init_InsByins_angular_velocity_right_origin(::sensor_driver_msgs::msg::InsByins & msg)
  : msg_(msg)
  {}
  Init_InsByins_angular_velocity_front_origin angular_velocity_right_origin(::sensor_driver_msgs::msg::InsByins::_angular_velocity_right_origin_type arg)
  {
    msg_.angular_velocity_right_origin = std::move(arg);
    return Init_InsByins_angular_velocity_front_origin(msg_);
  }

private:
  ::sensor_driver_msgs::msg::InsByins msg_;
};

class Init_InsByins_accelerate_up
{
public:
  explicit Init_InsByins_accelerate_up(::sensor_driver_msgs::msg::InsByins & msg)
  : msg_(msg)
  {}
  Init_InsByins_angular_velocity_right_origin accelerate_up(::sensor_driver_msgs::msg::InsByins::_accelerate_up_type arg)
  {
    msg_.accelerate_up = std::move(arg);
    return Init_InsByins_angular_velocity_right_origin(msg_);
  }

private:
  ::sensor_driver_msgs::msg::InsByins msg_;
};

class Init_InsByins_accelerate_front
{
public:
  explicit Init_InsByins_accelerate_front(::sensor_driver_msgs::msg::InsByins & msg)
  : msg_(msg)
  {}
  Init_InsByins_accelerate_up accelerate_front(::sensor_driver_msgs::msg::InsByins::_accelerate_front_type arg)
  {
    msg_.accelerate_front = std::move(arg);
    return Init_InsByins_accelerate_up(msg_);
  }

private:
  ::sensor_driver_msgs::msg::InsByins msg_;
};

class Init_InsByins_accelerate_right
{
public:
  explicit Init_InsByins_accelerate_right(::sensor_driver_msgs::msg::InsByins & msg)
  : msg_(msg)
  {}
  Init_InsByins_accelerate_front accelerate_right(::sensor_driver_msgs::msg::InsByins::_accelerate_right_type arg)
  {
    msg_.accelerate_right = std::move(arg);
    return Init_InsByins_accelerate_front(msg_);
  }

private:
  ::sensor_driver_msgs::msg::InsByins msg_;
};

class Init_InsByins_velocity_up
{
public:
  explicit Init_InsByins_velocity_up(::sensor_driver_msgs::msg::InsByins & msg)
  : msg_(msg)
  {}
  Init_InsByins_accelerate_right velocity_up(::sensor_driver_msgs::msg::InsByins::_velocity_up_type arg)
  {
    msg_.velocity_up = std::move(arg);
    return Init_InsByins_accelerate_right(msg_);
  }

private:
  ::sensor_driver_msgs::msg::InsByins msg_;
};

class Init_InsByins_velocity_right
{
public:
  explicit Init_InsByins_velocity_right(::sensor_driver_msgs::msg::InsByins & msg)
  : msg_(msg)
  {}
  Init_InsByins_velocity_up velocity_right(::sensor_driver_msgs::msg::InsByins::_velocity_right_type arg)
  {
    msg_.velocity_right = std::move(arg);
    return Init_InsByins_velocity_up(msg_);
  }

private:
  ::sensor_driver_msgs::msg::InsByins msg_;
};

class Init_InsByins_velocity_front
{
public:
  explicit Init_InsByins_velocity_front(::sensor_driver_msgs::msg::InsByins & msg)
  : msg_(msg)
  {}
  Init_InsByins_velocity_right velocity_front(::sensor_driver_msgs::msg::InsByins::_velocity_front_type arg)
  {
    msg_.velocity_front = std::move(arg);
    return Init_InsByins_velocity_right(msg_);
  }

private:
  ::sensor_driver_msgs::msg::InsByins msg_;
};

class Init_InsByins_roll
{
public:
  explicit Init_InsByins_roll(::sensor_driver_msgs::msg::InsByins & msg)
  : msg_(msg)
  {}
  Init_InsByins_velocity_front roll(::sensor_driver_msgs::msg::InsByins::_roll_type arg)
  {
    msg_.roll = std::move(arg);
    return Init_InsByins_velocity_front(msg_);
  }

private:
  ::sensor_driver_msgs::msg::InsByins msg_;
};

class Init_InsByins_pitch
{
public:
  explicit Init_InsByins_pitch(::sensor_driver_msgs::msg::InsByins & msg)
  : msg_(msg)
  {}
  Init_InsByins_roll pitch(::sensor_driver_msgs::msg::InsByins::_pitch_type arg)
  {
    msg_.pitch = std::move(arg);
    return Init_InsByins_roll(msg_);
  }

private:
  ::sensor_driver_msgs::msg::InsByins msg_;
};

class Init_InsByins_yaw
{
public:
  explicit Init_InsByins_yaw(::sensor_driver_msgs::msg::InsByins & msg)
  : msg_(msg)
  {}
  Init_InsByins_pitch yaw(::sensor_driver_msgs::msg::InsByins::_yaw_type arg)
  {
    msg_.yaw = std::move(arg);
    return Init_InsByins_pitch(msg_);
  }

private:
  ::sensor_driver_msgs::msg::InsByins msg_;
};

class Init_InsByins_ins_altitude
{
public:
  explicit Init_InsByins_ins_altitude(::sensor_driver_msgs::msg::InsByins & msg)
  : msg_(msg)
  {}
  Init_InsByins_yaw ins_altitude(::sensor_driver_msgs::msg::InsByins::_ins_altitude_type arg)
  {
    msg_.ins_altitude = std::move(arg);
    return Init_InsByins_yaw(msg_);
  }

private:
  ::sensor_driver_msgs::msg::InsByins msg_;
};

class Init_InsByins_ins_longitude
{
public:
  explicit Init_InsByins_ins_longitude(::sensor_driver_msgs::msg::InsByins & msg)
  : msg_(msg)
  {}
  Init_InsByins_ins_altitude ins_longitude(::sensor_driver_msgs::msg::InsByins::_ins_longitude_type arg)
  {
    msg_.ins_longitude = std::move(arg);
    return Init_InsByins_ins_altitude(msg_);
  }

private:
  ::sensor_driver_msgs::msg::InsByins msg_;
};

class Init_InsByins_ins_latitude
{
public:
  explicit Init_InsByins_ins_latitude(::sensor_driver_msgs::msg::InsByins & msg)
  : msg_(msg)
  {}
  Init_InsByins_ins_longitude ins_latitude(::sensor_driver_msgs::msg::InsByins::_ins_latitude_type arg)
  {
    msg_.ins_latitude = std::move(arg);
    return Init_InsByins_ins_longitude(msg_);
  }

private:
  ::sensor_driver_msgs::msg::InsByins msg_;
};

class Init_InsByins_gps_week_sec
{
public:
  explicit Init_InsByins_gps_week_sec(::sensor_driver_msgs::msg::InsByins & msg)
  : msg_(msg)
  {}
  Init_InsByins_ins_latitude gps_week_sec(::sensor_driver_msgs::msg::InsByins::_gps_week_sec_type arg)
  {
    msg_.gps_week_sec = std::move(arg);
    return Init_InsByins_ins_latitude(msg_);
  }

private:
  ::sensor_driver_msgs::msg::InsByins msg_;
};

class Init_InsByins_utc_time
{
public:
  explicit Init_InsByins_utc_time(::sensor_driver_msgs::msg::InsByins & msg)
  : msg_(msg)
  {}
  Init_InsByins_gps_week_sec utc_time(::sensor_driver_msgs::msg::InsByins::_utc_time_type arg)
  {
    msg_.utc_time = std::move(arg);
    return Init_InsByins_gps_week_sec(msg_);
  }

private:
  ::sensor_driver_msgs::msg::InsByins msg_;
};

class Init_InsByins_serial_number
{
public:
  explicit Init_InsByins_serial_number(::sensor_driver_msgs::msg::InsByins & msg)
  : msg_(msg)
  {}
  Init_InsByins_utc_time serial_number(::sensor_driver_msgs::msg::InsByins::_serial_number_type arg)
  {
    msg_.serial_number = std::move(arg);
    return Init_InsByins_utc_time(msg_);
  }

private:
  ::sensor_driver_msgs::msg::InsByins msg_;
};

class Init_InsByins_data_id
{
public:
  explicit Init_InsByins_data_id(::sensor_driver_msgs::msg::InsByins & msg)
  : msg_(msg)
  {}
  Init_InsByins_serial_number data_id(::sensor_driver_msgs::msg::InsByins::_data_id_type arg)
  {
    msg_.data_id = std::move(arg);
    return Init_InsByins_serial_number(msg_);
  }

private:
  ::sensor_driver_msgs::msg::InsByins msg_;
};

class Init_InsByins_header
{
public:
  Init_InsByins_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_InsByins_data_id header(::sensor_driver_msgs::msg::InsByins::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_InsByins_data_id(msg_);
  }

private:
  ::sensor_driver_msgs::msg::InsByins msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sensor_driver_msgs::msg::InsByins>()
{
  return sensor_driver_msgs::msg::builder::Init_InsByins_header();
}

}  // namespace sensor_driver_msgs

#endif  // SENSOR_DRIVER_MSGS__MSG__DETAIL__INS_BYINS__BUILDER_HPP_
