// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from sensor_driver_msgs:msg/ChassisCanRecived.idl
// generated code does not contain a copyright notice
#include "sensor_driver_msgs/msg/detail/chassis_can_recived__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"

bool
sensor_driver_msgs__msg__ChassisCanRecived__init(sensor_driver_msgs__msg__ChassisCanRecived * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    sensor_driver_msgs__msg__ChassisCanRecived__fini(msg);
    return false;
  }
  // vcuidu_fdbk_workmod
  // vcuidu_fdbk_modelstop
  // vcuidu_fdbk_power
  // vcuidu_fdbk_erro
  // vcu_fdbk_softver
  // vcu_fdbk_rollcnt
  // vcuidu_fdbk_checksum
  // mcuidu_fdbk_rnd
  // mcuidu_fdbk_realtorq
  // mcuidu_fdbk_realrpm
  // mcuidu_fdbk_errolevel
  // mcuidu_fdbk_fault
  // epbidu_fdbk_parksta
  // epbidu_fdbk_errolevel
  // epbidu_fdbk_fault
  // epsidu_fdbk_worksta
  // epsidu_fdbk_errolevel
  // epsidu_fdbk_fault
  // ehbidu_fdbk_realpressure
  // ehbidu_fdbk_errolevel
  // ehbidu_fdbk_fault
  // bmsidu_fdbk_chcsta
  // bmsidu_fdbk_soc
  // bmsidu_fdbk_busv
  // bmsidu_fdbk_errolevel
  // bmsidu_fdbk_fault
  // bcmidu_fdbk_headlight
  // bcmidu_fdbk_turnflash
  // bcmidu_fdbk_backlight
  // bcmidu_fdbk_brakelight
  // bcmidu_fdbk_siren
  // bcmidu_fdbk_voice
  // bcmidu_fdbk_doubleflash
  // mcuidu_fdbk_realsped
  // mcuidu_fdbk_realacc
  // epsidu_fdbk_realangle
  // ehbidu_fdbk_realdece
  // bmsidu_fdbk_busa
  return true;
}

void
sensor_driver_msgs__msg__ChassisCanRecived__fini(sensor_driver_msgs__msg__ChassisCanRecived * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // vcuidu_fdbk_workmod
  // vcuidu_fdbk_modelstop
  // vcuidu_fdbk_power
  // vcuidu_fdbk_erro
  // vcu_fdbk_softver
  // vcu_fdbk_rollcnt
  // vcuidu_fdbk_checksum
  // mcuidu_fdbk_rnd
  // mcuidu_fdbk_realtorq
  // mcuidu_fdbk_realrpm
  // mcuidu_fdbk_errolevel
  // mcuidu_fdbk_fault
  // epbidu_fdbk_parksta
  // epbidu_fdbk_errolevel
  // epbidu_fdbk_fault
  // epsidu_fdbk_worksta
  // epsidu_fdbk_errolevel
  // epsidu_fdbk_fault
  // ehbidu_fdbk_realpressure
  // ehbidu_fdbk_errolevel
  // ehbidu_fdbk_fault
  // bmsidu_fdbk_chcsta
  // bmsidu_fdbk_soc
  // bmsidu_fdbk_busv
  // bmsidu_fdbk_errolevel
  // bmsidu_fdbk_fault
  // bcmidu_fdbk_headlight
  // bcmidu_fdbk_turnflash
  // bcmidu_fdbk_backlight
  // bcmidu_fdbk_brakelight
  // bcmidu_fdbk_siren
  // bcmidu_fdbk_voice
  // bcmidu_fdbk_doubleflash
  // mcuidu_fdbk_realsped
  // mcuidu_fdbk_realacc
  // epsidu_fdbk_realangle
  // ehbidu_fdbk_realdece
  // bmsidu_fdbk_busa
}

bool
sensor_driver_msgs__msg__ChassisCanRecived__are_equal(const sensor_driver_msgs__msg__ChassisCanRecived * lhs, const sensor_driver_msgs__msg__ChassisCanRecived * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // vcuidu_fdbk_workmod
  if (lhs->vcuidu_fdbk_workmod != rhs->vcuidu_fdbk_workmod) {
    return false;
  }
  // vcuidu_fdbk_modelstop
  if (lhs->vcuidu_fdbk_modelstop != rhs->vcuidu_fdbk_modelstop) {
    return false;
  }
  // vcuidu_fdbk_power
  if (lhs->vcuidu_fdbk_power != rhs->vcuidu_fdbk_power) {
    return false;
  }
  // vcuidu_fdbk_erro
  if (lhs->vcuidu_fdbk_erro != rhs->vcuidu_fdbk_erro) {
    return false;
  }
  // vcu_fdbk_softver
  if (lhs->vcu_fdbk_softver != rhs->vcu_fdbk_softver) {
    return false;
  }
  // vcu_fdbk_rollcnt
  if (lhs->vcu_fdbk_rollcnt != rhs->vcu_fdbk_rollcnt) {
    return false;
  }
  // vcuidu_fdbk_checksum
  if (lhs->vcuidu_fdbk_checksum != rhs->vcuidu_fdbk_checksum) {
    return false;
  }
  // mcuidu_fdbk_rnd
  if (lhs->mcuidu_fdbk_rnd != rhs->mcuidu_fdbk_rnd) {
    return false;
  }
  // mcuidu_fdbk_realtorq
  if (lhs->mcuidu_fdbk_realtorq != rhs->mcuidu_fdbk_realtorq) {
    return false;
  }
  // mcuidu_fdbk_realrpm
  if (lhs->mcuidu_fdbk_realrpm != rhs->mcuidu_fdbk_realrpm) {
    return false;
  }
  // mcuidu_fdbk_errolevel
  if (lhs->mcuidu_fdbk_errolevel != rhs->mcuidu_fdbk_errolevel) {
    return false;
  }
  // mcuidu_fdbk_fault
  if (lhs->mcuidu_fdbk_fault != rhs->mcuidu_fdbk_fault) {
    return false;
  }
  // epbidu_fdbk_parksta
  if (lhs->epbidu_fdbk_parksta != rhs->epbidu_fdbk_parksta) {
    return false;
  }
  // epbidu_fdbk_errolevel
  if (lhs->epbidu_fdbk_errolevel != rhs->epbidu_fdbk_errolevel) {
    return false;
  }
  // epbidu_fdbk_fault
  if (lhs->epbidu_fdbk_fault != rhs->epbidu_fdbk_fault) {
    return false;
  }
  // epsidu_fdbk_worksta
  if (lhs->epsidu_fdbk_worksta != rhs->epsidu_fdbk_worksta) {
    return false;
  }
  // epsidu_fdbk_errolevel
  if (lhs->epsidu_fdbk_errolevel != rhs->epsidu_fdbk_errolevel) {
    return false;
  }
  // epsidu_fdbk_fault
  if (lhs->epsidu_fdbk_fault != rhs->epsidu_fdbk_fault) {
    return false;
  }
  // ehbidu_fdbk_realpressure
  if (lhs->ehbidu_fdbk_realpressure != rhs->ehbidu_fdbk_realpressure) {
    return false;
  }
  // ehbidu_fdbk_errolevel
  if (lhs->ehbidu_fdbk_errolevel != rhs->ehbidu_fdbk_errolevel) {
    return false;
  }
  // ehbidu_fdbk_fault
  if (lhs->ehbidu_fdbk_fault != rhs->ehbidu_fdbk_fault) {
    return false;
  }
  // bmsidu_fdbk_chcsta
  if (lhs->bmsidu_fdbk_chcsta != rhs->bmsidu_fdbk_chcsta) {
    return false;
  }
  // bmsidu_fdbk_soc
  if (lhs->bmsidu_fdbk_soc != rhs->bmsidu_fdbk_soc) {
    return false;
  }
  // bmsidu_fdbk_busv
  if (lhs->bmsidu_fdbk_busv != rhs->bmsidu_fdbk_busv) {
    return false;
  }
  // bmsidu_fdbk_errolevel
  if (lhs->bmsidu_fdbk_errolevel != rhs->bmsidu_fdbk_errolevel) {
    return false;
  }
  // bmsidu_fdbk_fault
  if (lhs->bmsidu_fdbk_fault != rhs->bmsidu_fdbk_fault) {
    return false;
  }
  // bcmidu_fdbk_headlight
  if (lhs->bcmidu_fdbk_headlight != rhs->bcmidu_fdbk_headlight) {
    return false;
  }
  // bcmidu_fdbk_turnflash
  if (lhs->bcmidu_fdbk_turnflash != rhs->bcmidu_fdbk_turnflash) {
    return false;
  }
  // bcmidu_fdbk_backlight
  if (lhs->bcmidu_fdbk_backlight != rhs->bcmidu_fdbk_backlight) {
    return false;
  }
  // bcmidu_fdbk_brakelight
  if (lhs->bcmidu_fdbk_brakelight != rhs->bcmidu_fdbk_brakelight) {
    return false;
  }
  // bcmidu_fdbk_siren
  if (lhs->bcmidu_fdbk_siren != rhs->bcmidu_fdbk_siren) {
    return false;
  }
  // bcmidu_fdbk_voice
  if (lhs->bcmidu_fdbk_voice != rhs->bcmidu_fdbk_voice) {
    return false;
  }
  // bcmidu_fdbk_doubleflash
  if (lhs->bcmidu_fdbk_doubleflash != rhs->bcmidu_fdbk_doubleflash) {
    return false;
  }
  // mcuidu_fdbk_realsped
  if (lhs->mcuidu_fdbk_realsped != rhs->mcuidu_fdbk_realsped) {
    return false;
  }
  // mcuidu_fdbk_realacc
  if (lhs->mcuidu_fdbk_realacc != rhs->mcuidu_fdbk_realacc) {
    return false;
  }
  // epsidu_fdbk_realangle
  if (lhs->epsidu_fdbk_realangle != rhs->epsidu_fdbk_realangle) {
    return false;
  }
  // ehbidu_fdbk_realdece
  if (lhs->ehbidu_fdbk_realdece != rhs->ehbidu_fdbk_realdece) {
    return false;
  }
  // bmsidu_fdbk_busa
  if (lhs->bmsidu_fdbk_busa != rhs->bmsidu_fdbk_busa) {
    return false;
  }
  return true;
}

bool
sensor_driver_msgs__msg__ChassisCanRecived__copy(
  const sensor_driver_msgs__msg__ChassisCanRecived * input,
  sensor_driver_msgs__msg__ChassisCanRecived * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // vcuidu_fdbk_workmod
  output->vcuidu_fdbk_workmod = input->vcuidu_fdbk_workmod;
  // vcuidu_fdbk_modelstop
  output->vcuidu_fdbk_modelstop = input->vcuidu_fdbk_modelstop;
  // vcuidu_fdbk_power
  output->vcuidu_fdbk_power = input->vcuidu_fdbk_power;
  // vcuidu_fdbk_erro
  output->vcuidu_fdbk_erro = input->vcuidu_fdbk_erro;
  // vcu_fdbk_softver
  output->vcu_fdbk_softver = input->vcu_fdbk_softver;
  // vcu_fdbk_rollcnt
  output->vcu_fdbk_rollcnt = input->vcu_fdbk_rollcnt;
  // vcuidu_fdbk_checksum
  output->vcuidu_fdbk_checksum = input->vcuidu_fdbk_checksum;
  // mcuidu_fdbk_rnd
  output->mcuidu_fdbk_rnd = input->mcuidu_fdbk_rnd;
  // mcuidu_fdbk_realtorq
  output->mcuidu_fdbk_realtorq = input->mcuidu_fdbk_realtorq;
  // mcuidu_fdbk_realrpm
  output->mcuidu_fdbk_realrpm = input->mcuidu_fdbk_realrpm;
  // mcuidu_fdbk_errolevel
  output->mcuidu_fdbk_errolevel = input->mcuidu_fdbk_errolevel;
  // mcuidu_fdbk_fault
  output->mcuidu_fdbk_fault = input->mcuidu_fdbk_fault;
  // epbidu_fdbk_parksta
  output->epbidu_fdbk_parksta = input->epbidu_fdbk_parksta;
  // epbidu_fdbk_errolevel
  output->epbidu_fdbk_errolevel = input->epbidu_fdbk_errolevel;
  // epbidu_fdbk_fault
  output->epbidu_fdbk_fault = input->epbidu_fdbk_fault;
  // epsidu_fdbk_worksta
  output->epsidu_fdbk_worksta = input->epsidu_fdbk_worksta;
  // epsidu_fdbk_errolevel
  output->epsidu_fdbk_errolevel = input->epsidu_fdbk_errolevel;
  // epsidu_fdbk_fault
  output->epsidu_fdbk_fault = input->epsidu_fdbk_fault;
  // ehbidu_fdbk_realpressure
  output->ehbidu_fdbk_realpressure = input->ehbidu_fdbk_realpressure;
  // ehbidu_fdbk_errolevel
  output->ehbidu_fdbk_errolevel = input->ehbidu_fdbk_errolevel;
  // ehbidu_fdbk_fault
  output->ehbidu_fdbk_fault = input->ehbidu_fdbk_fault;
  // bmsidu_fdbk_chcsta
  output->bmsidu_fdbk_chcsta = input->bmsidu_fdbk_chcsta;
  // bmsidu_fdbk_soc
  output->bmsidu_fdbk_soc = input->bmsidu_fdbk_soc;
  // bmsidu_fdbk_busv
  output->bmsidu_fdbk_busv = input->bmsidu_fdbk_busv;
  // bmsidu_fdbk_errolevel
  output->bmsidu_fdbk_errolevel = input->bmsidu_fdbk_errolevel;
  // bmsidu_fdbk_fault
  output->bmsidu_fdbk_fault = input->bmsidu_fdbk_fault;
  // bcmidu_fdbk_headlight
  output->bcmidu_fdbk_headlight = input->bcmidu_fdbk_headlight;
  // bcmidu_fdbk_turnflash
  output->bcmidu_fdbk_turnflash = input->bcmidu_fdbk_turnflash;
  // bcmidu_fdbk_backlight
  output->bcmidu_fdbk_backlight = input->bcmidu_fdbk_backlight;
  // bcmidu_fdbk_brakelight
  output->bcmidu_fdbk_brakelight = input->bcmidu_fdbk_brakelight;
  // bcmidu_fdbk_siren
  output->bcmidu_fdbk_siren = input->bcmidu_fdbk_siren;
  // bcmidu_fdbk_voice
  output->bcmidu_fdbk_voice = input->bcmidu_fdbk_voice;
  // bcmidu_fdbk_doubleflash
  output->bcmidu_fdbk_doubleflash = input->bcmidu_fdbk_doubleflash;
  // mcuidu_fdbk_realsped
  output->mcuidu_fdbk_realsped = input->mcuidu_fdbk_realsped;
  // mcuidu_fdbk_realacc
  output->mcuidu_fdbk_realacc = input->mcuidu_fdbk_realacc;
  // epsidu_fdbk_realangle
  output->epsidu_fdbk_realangle = input->epsidu_fdbk_realangle;
  // ehbidu_fdbk_realdece
  output->ehbidu_fdbk_realdece = input->ehbidu_fdbk_realdece;
  // bmsidu_fdbk_busa
  output->bmsidu_fdbk_busa = input->bmsidu_fdbk_busa;
  return true;
}

sensor_driver_msgs__msg__ChassisCanRecived *
sensor_driver_msgs__msg__ChassisCanRecived__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sensor_driver_msgs__msg__ChassisCanRecived * msg = (sensor_driver_msgs__msg__ChassisCanRecived *)allocator.allocate(sizeof(sensor_driver_msgs__msg__ChassisCanRecived), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(sensor_driver_msgs__msg__ChassisCanRecived));
  bool success = sensor_driver_msgs__msg__ChassisCanRecived__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
sensor_driver_msgs__msg__ChassisCanRecived__destroy(sensor_driver_msgs__msg__ChassisCanRecived * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    sensor_driver_msgs__msg__ChassisCanRecived__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
sensor_driver_msgs__msg__ChassisCanRecived__Sequence__init(sensor_driver_msgs__msg__ChassisCanRecived__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sensor_driver_msgs__msg__ChassisCanRecived * data = NULL;

  if (size) {
    data = (sensor_driver_msgs__msg__ChassisCanRecived *)allocator.zero_allocate(size, sizeof(sensor_driver_msgs__msg__ChassisCanRecived), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = sensor_driver_msgs__msg__ChassisCanRecived__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        sensor_driver_msgs__msg__ChassisCanRecived__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
sensor_driver_msgs__msg__ChassisCanRecived__Sequence__fini(sensor_driver_msgs__msg__ChassisCanRecived__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      sensor_driver_msgs__msg__ChassisCanRecived__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

sensor_driver_msgs__msg__ChassisCanRecived__Sequence *
sensor_driver_msgs__msg__ChassisCanRecived__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sensor_driver_msgs__msg__ChassisCanRecived__Sequence * array = (sensor_driver_msgs__msg__ChassisCanRecived__Sequence *)allocator.allocate(sizeof(sensor_driver_msgs__msg__ChassisCanRecived__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = sensor_driver_msgs__msg__ChassisCanRecived__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
sensor_driver_msgs__msg__ChassisCanRecived__Sequence__destroy(sensor_driver_msgs__msg__ChassisCanRecived__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    sensor_driver_msgs__msg__ChassisCanRecived__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
sensor_driver_msgs__msg__ChassisCanRecived__Sequence__are_equal(const sensor_driver_msgs__msg__ChassisCanRecived__Sequence * lhs, const sensor_driver_msgs__msg__ChassisCanRecived__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!sensor_driver_msgs__msg__ChassisCanRecived__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
sensor_driver_msgs__msg__ChassisCanRecived__Sequence__copy(
  const sensor_driver_msgs__msg__ChassisCanRecived__Sequence * input,
  sensor_driver_msgs__msg__ChassisCanRecived__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(sensor_driver_msgs__msg__ChassisCanRecived);
    sensor_driver_msgs__msg__ChassisCanRecived * data =
      (sensor_driver_msgs__msg__ChassisCanRecived *)realloc(output->data, allocation_size);
    if (!data) {
      return false;
    }
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!sensor_driver_msgs__msg__ChassisCanRecived__init(&data[i])) {
        /* free currently allocated and return false */
        for (; i-- > output->capacity; ) {
          sensor_driver_msgs__msg__ChassisCanRecived__fini(&data[i]);
        }
        free(data);
        return false;
      }
    }
    output->data = data;
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!sensor_driver_msgs__msg__ChassisCanRecived__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
