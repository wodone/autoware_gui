// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sensor_driver_msgs:msg/ImuHwt9073can.idl
// generated code does not contain a copyright notice

#ifndef SENSOR_DRIVER_MSGS__MSG__DETAIL__IMU_HWT9073CAN__BUILDER_HPP_
#define SENSOR_DRIVER_MSGS__MSG__DETAIL__IMU_HWT9073CAN__BUILDER_HPP_

#include "sensor_driver_msgs/msg/detail/imu_hwt9073can__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace sensor_driver_msgs
{

namespace msg
{

namespace builder
{

class Init_ImuHwt9073can_angle_z
{
public:
  explicit Init_ImuHwt9073can_angle_z(::sensor_driver_msgs::msg::ImuHwt9073can & msg)
  : msg_(msg)
  {}
  ::sensor_driver_msgs::msg::ImuHwt9073can angle_z(::sensor_driver_msgs::msg::ImuHwt9073can::_angle_z_type arg)
  {
    msg_.angle_z = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ImuHwt9073can msg_;
};

class Init_ImuHwt9073can_angle_y
{
public:
  explicit Init_ImuHwt9073can_angle_y(::sensor_driver_msgs::msg::ImuHwt9073can & msg)
  : msg_(msg)
  {}
  Init_ImuHwt9073can_angle_z angle_y(::sensor_driver_msgs::msg::ImuHwt9073can::_angle_y_type arg)
  {
    msg_.angle_y = std::move(arg);
    return Init_ImuHwt9073can_angle_z(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ImuHwt9073can msg_;
};

class Init_ImuHwt9073can_angle_x
{
public:
  explicit Init_ImuHwt9073can_angle_x(::sensor_driver_msgs::msg::ImuHwt9073can & msg)
  : msg_(msg)
  {}
  Init_ImuHwt9073can_angle_y angle_x(::sensor_driver_msgs::msg::ImuHwt9073can::_angle_x_type arg)
  {
    msg_.angle_x = std::move(arg);
    return Init_ImuHwt9073can_angle_y(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ImuHwt9073can msg_;
};

class Init_ImuHwt9073can_a_vel_z
{
public:
  explicit Init_ImuHwt9073can_a_vel_z(::sensor_driver_msgs::msg::ImuHwt9073can & msg)
  : msg_(msg)
  {}
  Init_ImuHwt9073can_angle_x a_vel_z(::sensor_driver_msgs::msg::ImuHwt9073can::_a_vel_z_type arg)
  {
    msg_.a_vel_z = std::move(arg);
    return Init_ImuHwt9073can_angle_x(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ImuHwt9073can msg_;
};

class Init_ImuHwt9073can_a_vel_y
{
public:
  explicit Init_ImuHwt9073can_a_vel_y(::sensor_driver_msgs::msg::ImuHwt9073can & msg)
  : msg_(msg)
  {}
  Init_ImuHwt9073can_a_vel_z a_vel_y(::sensor_driver_msgs::msg::ImuHwt9073can::_a_vel_y_type arg)
  {
    msg_.a_vel_y = std::move(arg);
    return Init_ImuHwt9073can_a_vel_z(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ImuHwt9073can msg_;
};

class Init_ImuHwt9073can_a_vel_x
{
public:
  explicit Init_ImuHwt9073can_a_vel_x(::sensor_driver_msgs::msg::ImuHwt9073can & msg)
  : msg_(msg)
  {}
  Init_ImuHwt9073can_a_vel_y a_vel_x(::sensor_driver_msgs::msg::ImuHwt9073can::_a_vel_x_type arg)
  {
    msg_.a_vel_x = std::move(arg);
    return Init_ImuHwt9073can_a_vel_y(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ImuHwt9073can msg_;
};

class Init_ImuHwt9073can_acc_z
{
public:
  explicit Init_ImuHwt9073can_acc_z(::sensor_driver_msgs::msg::ImuHwt9073can & msg)
  : msg_(msg)
  {}
  Init_ImuHwt9073can_a_vel_x acc_z(::sensor_driver_msgs::msg::ImuHwt9073can::_acc_z_type arg)
  {
    msg_.acc_z = std::move(arg);
    return Init_ImuHwt9073can_a_vel_x(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ImuHwt9073can msg_;
};

class Init_ImuHwt9073can_acc_y
{
public:
  explicit Init_ImuHwt9073can_acc_y(::sensor_driver_msgs::msg::ImuHwt9073can & msg)
  : msg_(msg)
  {}
  Init_ImuHwt9073can_acc_z acc_y(::sensor_driver_msgs::msg::ImuHwt9073can::_acc_y_type arg)
  {
    msg_.acc_y = std::move(arg);
    return Init_ImuHwt9073can_acc_z(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ImuHwt9073can msg_;
};

class Init_ImuHwt9073can_acc_x
{
public:
  explicit Init_ImuHwt9073can_acc_x(::sensor_driver_msgs::msg::ImuHwt9073can & msg)
  : msg_(msg)
  {}
  Init_ImuHwt9073can_acc_y acc_x(::sensor_driver_msgs::msg::ImuHwt9073can::_acc_x_type arg)
  {
    msg_.acc_x = std::move(arg);
    return Init_ImuHwt9073can_acc_y(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ImuHwt9073can msg_;
};

class Init_ImuHwt9073can_mag_z
{
public:
  explicit Init_ImuHwt9073can_mag_z(::sensor_driver_msgs::msg::ImuHwt9073can & msg)
  : msg_(msg)
  {}
  Init_ImuHwt9073can_acc_x mag_z(::sensor_driver_msgs::msg::ImuHwt9073can::_mag_z_type arg)
  {
    msg_.mag_z = std::move(arg);
    return Init_ImuHwt9073can_acc_x(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ImuHwt9073can msg_;
};

class Init_ImuHwt9073can_mag_y
{
public:
  explicit Init_ImuHwt9073can_mag_y(::sensor_driver_msgs::msg::ImuHwt9073can & msg)
  : msg_(msg)
  {}
  Init_ImuHwt9073can_mag_z mag_y(::sensor_driver_msgs::msg::ImuHwt9073can::_mag_y_type arg)
  {
    msg_.mag_y = std::move(arg);
    return Init_ImuHwt9073can_mag_z(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ImuHwt9073can msg_;
};

class Init_ImuHwt9073can_mag_x
{
public:
  explicit Init_ImuHwt9073can_mag_x(::sensor_driver_msgs::msg::ImuHwt9073can & msg)
  : msg_(msg)
  {}
  Init_ImuHwt9073can_mag_y mag_x(::sensor_driver_msgs::msg::ImuHwt9073can::_mag_x_type arg)
  {
    msg_.mag_x = std::move(arg);
    return Init_ImuHwt9073can_mag_y(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ImuHwt9073can msg_;
};

class Init_ImuHwt9073can_angle_z_raw
{
public:
  explicit Init_ImuHwt9073can_angle_z_raw(::sensor_driver_msgs::msg::ImuHwt9073can & msg)
  : msg_(msg)
  {}
  Init_ImuHwt9073can_mag_x angle_z_raw(::sensor_driver_msgs::msg::ImuHwt9073can::_angle_z_raw_type arg)
  {
    msg_.angle_z_raw = std::move(arg);
    return Init_ImuHwt9073can_mag_x(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ImuHwt9073can msg_;
};

class Init_ImuHwt9073can_angle_y_raw
{
public:
  explicit Init_ImuHwt9073can_angle_y_raw(::sensor_driver_msgs::msg::ImuHwt9073can & msg)
  : msg_(msg)
  {}
  Init_ImuHwt9073can_angle_z_raw angle_y_raw(::sensor_driver_msgs::msg::ImuHwt9073can::_angle_y_raw_type arg)
  {
    msg_.angle_y_raw = std::move(arg);
    return Init_ImuHwt9073can_angle_z_raw(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ImuHwt9073can msg_;
};

class Init_ImuHwt9073can_angle_x_raw
{
public:
  explicit Init_ImuHwt9073can_angle_x_raw(::sensor_driver_msgs::msg::ImuHwt9073can & msg)
  : msg_(msg)
  {}
  Init_ImuHwt9073can_angle_y_raw angle_x_raw(::sensor_driver_msgs::msg::ImuHwt9073can::_angle_x_raw_type arg)
  {
    msg_.angle_x_raw = std::move(arg);
    return Init_ImuHwt9073can_angle_y_raw(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ImuHwt9073can msg_;
};

class Init_ImuHwt9073can_a_vel_z_raw
{
public:
  explicit Init_ImuHwt9073can_a_vel_z_raw(::sensor_driver_msgs::msg::ImuHwt9073can & msg)
  : msg_(msg)
  {}
  Init_ImuHwt9073can_angle_x_raw a_vel_z_raw(::sensor_driver_msgs::msg::ImuHwt9073can::_a_vel_z_raw_type arg)
  {
    msg_.a_vel_z_raw = std::move(arg);
    return Init_ImuHwt9073can_angle_x_raw(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ImuHwt9073can msg_;
};

class Init_ImuHwt9073can_a_vel_y_raw
{
public:
  explicit Init_ImuHwt9073can_a_vel_y_raw(::sensor_driver_msgs::msg::ImuHwt9073can & msg)
  : msg_(msg)
  {}
  Init_ImuHwt9073can_a_vel_z_raw a_vel_y_raw(::sensor_driver_msgs::msg::ImuHwt9073can::_a_vel_y_raw_type arg)
  {
    msg_.a_vel_y_raw = std::move(arg);
    return Init_ImuHwt9073can_a_vel_z_raw(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ImuHwt9073can msg_;
};

class Init_ImuHwt9073can_a_vel_x_raw
{
public:
  explicit Init_ImuHwt9073can_a_vel_x_raw(::sensor_driver_msgs::msg::ImuHwt9073can & msg)
  : msg_(msg)
  {}
  Init_ImuHwt9073can_a_vel_y_raw a_vel_x_raw(::sensor_driver_msgs::msg::ImuHwt9073can::_a_vel_x_raw_type arg)
  {
    msg_.a_vel_x_raw = std::move(arg);
    return Init_ImuHwt9073can_a_vel_y_raw(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ImuHwt9073can msg_;
};

class Init_ImuHwt9073can_acc_z_raw
{
public:
  explicit Init_ImuHwt9073can_acc_z_raw(::sensor_driver_msgs::msg::ImuHwt9073can & msg)
  : msg_(msg)
  {}
  Init_ImuHwt9073can_a_vel_x_raw acc_z_raw(::sensor_driver_msgs::msg::ImuHwt9073can::_acc_z_raw_type arg)
  {
    msg_.acc_z_raw = std::move(arg);
    return Init_ImuHwt9073can_a_vel_x_raw(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ImuHwt9073can msg_;
};

class Init_ImuHwt9073can_acc_y_raw
{
public:
  explicit Init_ImuHwt9073can_acc_y_raw(::sensor_driver_msgs::msg::ImuHwt9073can & msg)
  : msg_(msg)
  {}
  Init_ImuHwt9073can_acc_z_raw acc_y_raw(::sensor_driver_msgs::msg::ImuHwt9073can::_acc_y_raw_type arg)
  {
    msg_.acc_y_raw = std::move(arg);
    return Init_ImuHwt9073can_acc_z_raw(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ImuHwt9073can msg_;
};

class Init_ImuHwt9073can_acc_x_raw
{
public:
  explicit Init_ImuHwt9073can_acc_x_raw(::sensor_driver_msgs::msg::ImuHwt9073can & msg)
  : msg_(msg)
  {}
  Init_ImuHwt9073can_acc_y_raw acc_x_raw(::sensor_driver_msgs::msg::ImuHwt9073can::_acc_x_raw_type arg)
  {
    msg_.acc_x_raw = std::move(arg);
    return Init_ImuHwt9073can_acc_y_raw(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ImuHwt9073can msg_;
};

class Init_ImuHwt9073can_time_sec
{
public:
  explicit Init_ImuHwt9073can_time_sec(::sensor_driver_msgs::msg::ImuHwt9073can & msg)
  : msg_(msg)
  {}
  Init_ImuHwt9073can_acc_x_raw time_sec(::sensor_driver_msgs::msg::ImuHwt9073can::_time_sec_type arg)
  {
    msg_.time_sec = std::move(arg);
    return Init_ImuHwt9073can_acc_x_raw(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ImuHwt9073can msg_;
};

class Init_ImuHwt9073can_time_min
{
public:
  explicit Init_ImuHwt9073can_time_min(::sensor_driver_msgs::msg::ImuHwt9073can & msg)
  : msg_(msg)
  {}
  Init_ImuHwt9073can_time_sec time_min(::sensor_driver_msgs::msg::ImuHwt9073can::_time_min_type arg)
  {
    msg_.time_min = std::move(arg);
    return Init_ImuHwt9073can_time_sec(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ImuHwt9073can msg_;
};

class Init_ImuHwt9073can_time_hour
{
public:
  explicit Init_ImuHwt9073can_time_hour(::sensor_driver_msgs::msg::ImuHwt9073can & msg)
  : msg_(msg)
  {}
  Init_ImuHwt9073can_time_min time_hour(::sensor_driver_msgs::msg::ImuHwt9073can::_time_hour_type arg)
  {
    msg_.time_hour = std::move(arg);
    return Init_ImuHwt9073can_time_min(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ImuHwt9073can msg_;
};

class Init_ImuHwt9073can_time_day
{
public:
  explicit Init_ImuHwt9073can_time_day(::sensor_driver_msgs::msg::ImuHwt9073can & msg)
  : msg_(msg)
  {}
  Init_ImuHwt9073can_time_hour time_day(::sensor_driver_msgs::msg::ImuHwt9073can::_time_day_type arg)
  {
    msg_.time_day = std::move(arg);
    return Init_ImuHwt9073can_time_hour(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ImuHwt9073can msg_;
};

class Init_ImuHwt9073can_time_month
{
public:
  explicit Init_ImuHwt9073can_time_month(::sensor_driver_msgs::msg::ImuHwt9073can & msg)
  : msg_(msg)
  {}
  Init_ImuHwt9073can_time_day time_month(::sensor_driver_msgs::msg::ImuHwt9073can::_time_month_type arg)
  {
    msg_.time_month = std::move(arg);
    return Init_ImuHwt9073can_time_day(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ImuHwt9073can msg_;
};

class Init_ImuHwt9073can_time_year
{
public:
  explicit Init_ImuHwt9073can_time_year(::sensor_driver_msgs::msg::ImuHwt9073can & msg)
  : msg_(msg)
  {}
  Init_ImuHwt9073can_time_month time_year(::sensor_driver_msgs::msg::ImuHwt9073can::_time_year_type arg)
  {
    msg_.time_year = std::move(arg);
    return Init_ImuHwt9073can_time_month(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ImuHwt9073can msg_;
};

class Init_ImuHwt9073can_header
{
public:
  Init_ImuHwt9073can_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ImuHwt9073can_time_year header(::sensor_driver_msgs::msg::ImuHwt9073can::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_ImuHwt9073can_time_year(msg_);
  }

private:
  ::sensor_driver_msgs::msg::ImuHwt9073can msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sensor_driver_msgs::msg::ImuHwt9073can>()
{
  return sensor_driver_msgs::msg::builder::Init_ImuHwt9073can_header();
}

}  // namespace sensor_driver_msgs

#endif  // SENSOR_DRIVER_MSGS__MSG__DETAIL__IMU_HWT9073CAN__BUILDER_HPP_
