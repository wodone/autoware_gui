// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from sensor_driver_msgs:msg/GnssGpgga.idl
// generated code does not contain a copyright notice
#include "sensor_driver_msgs/msg/detail/gnss_gpgga__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"
// Member `data_id`
// Member `latitude_sign`
// Member `longitude_sign`
// Member `altitude_sign`
// Member `altitude_diff_sign`
// Member `cs`
#include "rosidl_runtime_c/string_functions.h"

bool
sensor_driver_msgs__msg__GnssGpgga__init(sensor_driver_msgs__msg__GnssGpgga * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    sensor_driver_msgs__msg__GnssGpgga__fini(msg);
    return false;
  }
  // data_id
  if (!rosidl_runtime_c__String__init(&msg->data_id)) {
    sensor_driver_msgs__msg__GnssGpgga__fini(msg);
    return false;
  }
  // utc_time
  // latitude
  // latitude_sign
  if (!rosidl_runtime_c__String__init(&msg->latitude_sign)) {
    sensor_driver_msgs__msg__GnssGpgga__fini(msg);
    return false;
  }
  // longitude
  // longitude_sign
  if (!rosidl_runtime_c__String__init(&msg->longitude_sign)) {
    sensor_driver_msgs__msg__GnssGpgga__fini(msg);
    return false;
  }
  // state
  // satellite_num
  // hdop
  // altitude
  // altitude_sign
  if (!rosidl_runtime_c__String__init(&msg->altitude_sign)) {
    sensor_driver_msgs__msg__GnssGpgga__fini(msg);
    return false;
  }
  // altitude_diff
  // altitude_diff_sign
  if (!rosidl_runtime_c__String__init(&msg->altitude_diff_sign)) {
    sensor_driver_msgs__msg__GnssGpgga__fini(msg);
    return false;
  }
  // rtk_delay
  // rtk_id
  // cs
  if (!rosidl_runtime_c__String__init(&msg->cs)) {
    sensor_driver_msgs__msg__GnssGpgga__fini(msg);
    return false;
  }
  return true;
}

void
sensor_driver_msgs__msg__GnssGpgga__fini(sensor_driver_msgs__msg__GnssGpgga * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // data_id
  rosidl_runtime_c__String__fini(&msg->data_id);
  // utc_time
  // latitude
  // latitude_sign
  rosidl_runtime_c__String__fini(&msg->latitude_sign);
  // longitude
  // longitude_sign
  rosidl_runtime_c__String__fini(&msg->longitude_sign);
  // state
  // satellite_num
  // hdop
  // altitude
  // altitude_sign
  rosidl_runtime_c__String__fini(&msg->altitude_sign);
  // altitude_diff
  // altitude_diff_sign
  rosidl_runtime_c__String__fini(&msg->altitude_diff_sign);
  // rtk_delay
  // rtk_id
  // cs
  rosidl_runtime_c__String__fini(&msg->cs);
}

bool
sensor_driver_msgs__msg__GnssGpgga__are_equal(const sensor_driver_msgs__msg__GnssGpgga * lhs, const sensor_driver_msgs__msg__GnssGpgga * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // data_id
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->data_id), &(rhs->data_id)))
  {
    return false;
  }
  // utc_time
  if (lhs->utc_time != rhs->utc_time) {
    return false;
  }
  // latitude
  if (lhs->latitude != rhs->latitude) {
    return false;
  }
  // latitude_sign
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->latitude_sign), &(rhs->latitude_sign)))
  {
    return false;
  }
  // longitude
  if (lhs->longitude != rhs->longitude) {
    return false;
  }
  // longitude_sign
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->longitude_sign), &(rhs->longitude_sign)))
  {
    return false;
  }
  // state
  if (lhs->state != rhs->state) {
    return false;
  }
  // satellite_num
  if (lhs->satellite_num != rhs->satellite_num) {
    return false;
  }
  // hdop
  if (lhs->hdop != rhs->hdop) {
    return false;
  }
  // altitude
  if (lhs->altitude != rhs->altitude) {
    return false;
  }
  // altitude_sign
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->altitude_sign), &(rhs->altitude_sign)))
  {
    return false;
  }
  // altitude_diff
  if (lhs->altitude_diff != rhs->altitude_diff) {
    return false;
  }
  // altitude_diff_sign
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->altitude_diff_sign), &(rhs->altitude_diff_sign)))
  {
    return false;
  }
  // rtk_delay
  if (lhs->rtk_delay != rhs->rtk_delay) {
    return false;
  }
  // rtk_id
  if (lhs->rtk_id != rhs->rtk_id) {
    return false;
  }
  // cs
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->cs), &(rhs->cs)))
  {
    return false;
  }
  return true;
}

bool
sensor_driver_msgs__msg__GnssGpgga__copy(
  const sensor_driver_msgs__msg__GnssGpgga * input,
  sensor_driver_msgs__msg__GnssGpgga * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // data_id
  if (!rosidl_runtime_c__String__copy(
      &(input->data_id), &(output->data_id)))
  {
    return false;
  }
  // utc_time
  output->utc_time = input->utc_time;
  // latitude
  output->latitude = input->latitude;
  // latitude_sign
  if (!rosidl_runtime_c__String__copy(
      &(input->latitude_sign), &(output->latitude_sign)))
  {
    return false;
  }
  // longitude
  output->longitude = input->longitude;
  // longitude_sign
  if (!rosidl_runtime_c__String__copy(
      &(input->longitude_sign), &(output->longitude_sign)))
  {
    return false;
  }
  // state
  output->state = input->state;
  // satellite_num
  output->satellite_num = input->satellite_num;
  // hdop
  output->hdop = input->hdop;
  // altitude
  output->altitude = input->altitude;
  // altitude_sign
  if (!rosidl_runtime_c__String__copy(
      &(input->altitude_sign), &(output->altitude_sign)))
  {
    return false;
  }
  // altitude_diff
  output->altitude_diff = input->altitude_diff;
  // altitude_diff_sign
  if (!rosidl_runtime_c__String__copy(
      &(input->altitude_diff_sign), &(output->altitude_diff_sign)))
  {
    return false;
  }
  // rtk_delay
  output->rtk_delay = input->rtk_delay;
  // rtk_id
  output->rtk_id = input->rtk_id;
  // cs
  if (!rosidl_runtime_c__String__copy(
      &(input->cs), &(output->cs)))
  {
    return false;
  }
  return true;
}

sensor_driver_msgs__msg__GnssGpgga *
sensor_driver_msgs__msg__GnssGpgga__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sensor_driver_msgs__msg__GnssGpgga * msg = (sensor_driver_msgs__msg__GnssGpgga *)allocator.allocate(sizeof(sensor_driver_msgs__msg__GnssGpgga), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(sensor_driver_msgs__msg__GnssGpgga));
  bool success = sensor_driver_msgs__msg__GnssGpgga__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
sensor_driver_msgs__msg__GnssGpgga__destroy(sensor_driver_msgs__msg__GnssGpgga * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    sensor_driver_msgs__msg__GnssGpgga__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
sensor_driver_msgs__msg__GnssGpgga__Sequence__init(sensor_driver_msgs__msg__GnssGpgga__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sensor_driver_msgs__msg__GnssGpgga * data = NULL;

  if (size) {
    data = (sensor_driver_msgs__msg__GnssGpgga *)allocator.zero_allocate(size, sizeof(sensor_driver_msgs__msg__GnssGpgga), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = sensor_driver_msgs__msg__GnssGpgga__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        sensor_driver_msgs__msg__GnssGpgga__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
sensor_driver_msgs__msg__GnssGpgga__Sequence__fini(sensor_driver_msgs__msg__GnssGpgga__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      sensor_driver_msgs__msg__GnssGpgga__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

sensor_driver_msgs__msg__GnssGpgga__Sequence *
sensor_driver_msgs__msg__GnssGpgga__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sensor_driver_msgs__msg__GnssGpgga__Sequence * array = (sensor_driver_msgs__msg__GnssGpgga__Sequence *)allocator.allocate(sizeof(sensor_driver_msgs__msg__GnssGpgga__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = sensor_driver_msgs__msg__GnssGpgga__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
sensor_driver_msgs__msg__GnssGpgga__Sequence__destroy(sensor_driver_msgs__msg__GnssGpgga__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    sensor_driver_msgs__msg__GnssGpgga__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
sensor_driver_msgs__msg__GnssGpgga__Sequence__are_equal(const sensor_driver_msgs__msg__GnssGpgga__Sequence * lhs, const sensor_driver_msgs__msg__GnssGpgga__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!sensor_driver_msgs__msg__GnssGpgga__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
sensor_driver_msgs__msg__GnssGpgga__Sequence__copy(
  const sensor_driver_msgs__msg__GnssGpgga__Sequence * input,
  sensor_driver_msgs__msg__GnssGpgga__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(sensor_driver_msgs__msg__GnssGpgga);
    sensor_driver_msgs__msg__GnssGpgga * data =
      (sensor_driver_msgs__msg__GnssGpgga *)realloc(output->data, allocation_size);
    if (!data) {
      return false;
    }
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!sensor_driver_msgs__msg__GnssGpgga__init(&data[i])) {
        /* free currently allocated and return false */
        for (; i-- > output->capacity; ) {
          sensor_driver_msgs__msg__GnssGpgga__fini(&data[i]);
        }
        free(data);
        return false;
      }
    }
    output->data = data;
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!sensor_driver_msgs__msg__GnssGpgga__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
