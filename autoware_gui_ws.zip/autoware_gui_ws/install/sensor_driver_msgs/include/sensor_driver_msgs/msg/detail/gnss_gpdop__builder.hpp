// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sensor_driver_msgs:msg/GnssGpdop.idl
// generated code does not contain a copyright notice

#ifndef SENSOR_DRIVER_MSGS__MSG__DETAIL__GNSS_GPDOP__BUILDER_HPP_
#define SENSOR_DRIVER_MSGS__MSG__DETAIL__GNSS_GPDOP__BUILDER_HPP_

#include "sensor_driver_msgs/msg/detail/gnss_gpdop__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace sensor_driver_msgs
{

namespace msg
{

namespace builder
{

class Init_GnssGpdop_cs
{
public:
  explicit Init_GnssGpdop_cs(::sensor_driver_msgs::msg::GnssGpdop & msg)
  : msg_(msg)
  {}
  ::sensor_driver_msgs::msg::GnssGpdop cs(::sensor_driver_msgs::msg::GnssGpdop::_cs_type arg)
  {
    msg_.cs = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpdop msg_;
};

class Init_GnssGpdop_gdop
{
public:
  explicit Init_GnssGpdop_gdop(::sensor_driver_msgs::msg::GnssGpdop & msg)
  : msg_(msg)
  {}
  Init_GnssGpdop_cs gdop(::sensor_driver_msgs::msg::GnssGpdop::_gdop_type arg)
  {
    msg_.gdop = std::move(arg);
    return Init_GnssGpdop_cs(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpdop msg_;
};

class Init_GnssGpdop_tdop
{
public:
  explicit Init_GnssGpdop_tdop(::sensor_driver_msgs::msg::GnssGpdop & msg)
  : msg_(msg)
  {}
  Init_GnssGpdop_gdop tdop(::sensor_driver_msgs::msg::GnssGpdop::_tdop_type arg)
  {
    msg_.tdop = std::move(arg);
    return Init_GnssGpdop_gdop(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpdop msg_;
};

class Init_GnssGpdop_vdop
{
public:
  explicit Init_GnssGpdop_vdop(::sensor_driver_msgs::msg::GnssGpdop & msg)
  : msg_(msg)
  {}
  Init_GnssGpdop_tdop vdop(::sensor_driver_msgs::msg::GnssGpdop::_vdop_type arg)
  {
    msg_.vdop = std::move(arg);
    return Init_GnssGpdop_tdop(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpdop msg_;
};

class Init_GnssGpdop_hdop
{
public:
  explicit Init_GnssGpdop_hdop(::sensor_driver_msgs::msg::GnssGpdop & msg)
  : msg_(msg)
  {}
  Init_GnssGpdop_vdop hdop(::sensor_driver_msgs::msg::GnssGpdop::_hdop_type arg)
  {
    msg_.hdop = std::move(arg);
    return Init_GnssGpdop_vdop(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpdop msg_;
};

class Init_GnssGpdop_pdop
{
public:
  explicit Init_GnssGpdop_pdop(::sensor_driver_msgs::msg::GnssGpdop & msg)
  : msg_(msg)
  {}
  Init_GnssGpdop_hdop pdop(::sensor_driver_msgs::msg::GnssGpdop::_pdop_type arg)
  {
    msg_.pdop = std::move(arg);
    return Init_GnssGpdop_hdop(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpdop msg_;
};

class Init_GnssGpdop_utc_time
{
public:
  explicit Init_GnssGpdop_utc_time(::sensor_driver_msgs::msg::GnssGpdop & msg)
  : msg_(msg)
  {}
  Init_GnssGpdop_pdop utc_time(::sensor_driver_msgs::msg::GnssGpdop::_utc_time_type arg)
  {
    msg_.utc_time = std::move(arg);
    return Init_GnssGpdop_pdop(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpdop msg_;
};

class Init_GnssGpdop_data_id
{
public:
  explicit Init_GnssGpdop_data_id(::sensor_driver_msgs::msg::GnssGpdop & msg)
  : msg_(msg)
  {}
  Init_GnssGpdop_utc_time data_id(::sensor_driver_msgs::msg::GnssGpdop::_data_id_type arg)
  {
    msg_.data_id = std::move(arg);
    return Init_GnssGpdop_utc_time(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpdop msg_;
};

class Init_GnssGpdop_header
{
public:
  Init_GnssGpdop_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_GnssGpdop_data_id header(::sensor_driver_msgs::msg::GnssGpdop::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_GnssGpdop_data_id(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpdop msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sensor_driver_msgs::msg::GnssGpdop>()
{
  return sensor_driver_msgs::msg::builder::Init_GnssGpdop_header();
}

}  // namespace sensor_driver_msgs

#endif  // SENSOR_DRIVER_MSGS__MSG__DETAIL__GNSS_GPDOP__BUILDER_HPP_
