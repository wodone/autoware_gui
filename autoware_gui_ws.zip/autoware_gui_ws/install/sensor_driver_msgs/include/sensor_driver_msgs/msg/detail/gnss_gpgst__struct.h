// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from sensor_driver_msgs:msg/GnssGpgst.idl
// generated code does not contain a copyright notice

#ifndef SENSOR_DRIVER_MSGS__MSG__DETAIL__GNSS_GPGST__STRUCT_H_
#define SENSOR_DRIVER_MSGS__MSG__DETAIL__GNSS_GPGST__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'data_id'
// Member 'cs'
#include "rosidl_runtime_c/string.h"

// Struct defined in msg/GnssGpgst in the package sensor_driver_msgs.
typedef struct sensor_driver_msgs__msg__GnssGpgst
{
  std_msgs__msg__Header header;
  rosidl_runtime_c__String data_id;
  double utc_time;
  double rms_std;
  double smjr_std;
  double smnr_std;
  double orient;
  double lat_std;
  double lon_std;
  double alt_std;
  rosidl_runtime_c__String cs;
} sensor_driver_msgs__msg__GnssGpgst;

// Struct for a sequence of sensor_driver_msgs__msg__GnssGpgst.
typedef struct sensor_driver_msgs__msg__GnssGpgst__Sequence
{
  sensor_driver_msgs__msg__GnssGpgst * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sensor_driver_msgs__msg__GnssGpgst__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SENSOR_DRIVER_MSGS__MSG__DETAIL__GNSS_GPGST__STRUCT_H_
