// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from sensor_driver_msgs:msg/InsByins.idl
// generated code does not contain a copyright notice

#ifndef SENSOR_DRIVER_MSGS__MSG__DETAIL__INS_BYINS__STRUCT_HPP_
#define SENSOR_DRIVER_MSGS__MSG__DETAIL__INS_BYINS__STRUCT_HPP_

#include <rosidl_runtime_cpp/bounded_vector.hpp>
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__sensor_driver_msgs__msg__InsByins __attribute__((deprecated))
#else
# define DEPRECATED__sensor_driver_msgs__msg__InsByins __declspec(deprecated)
#endif

namespace sensor_driver_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct InsByins_
{
  using Type = InsByins_<ContainerAllocator>;

  explicit InsByins_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->data_id = "";
      this->serial_number = "";
      this->utc_time = 0.0;
      this->gps_week_sec = 0.0;
      this->ins_latitude = 0.0;
      this->ins_longitude = 0.0;
      this->ins_altitude = 0.0;
      this->yaw = 0.0;
      this->pitch = 0.0;
      this->roll = 0.0;
      this->velocity_front = 0.0;
      this->velocity_right = 0.0;
      this->velocity_up = 0.0;
      this->accelerate_right = 0.0;
      this->accelerate_front = 0.0;
      this->accelerate_up = 0.0;
      this->angular_velocity_right_origin = 0.0;
      this->angular_velocity_front_origin = 0.0;
      this->angular_velocity_up_origin = 0.0;
      this->angular_velocity_right_judged = 0.0;
      this->angular_velocity_front_judged = 0.0;
      this->angular_velocity_up_judged = 0.0;
      this->ins_state = 0;
      this->gnss_vector_state = 0;
      this->satellite_num = 0;
      this->rtk_delay = 0.0;
      this->bk_1 = 0.0;
      this->bk_2 = 0.0;
      this->bk_3 = 0.0;
      this->accelerate_north = 0.0;
      this->accelerate_east = 0.0;
      this->accelerate_ground = 0.0;
      this->gnss_latitude = 0.0;
      this->gnss_longitude = 0.0;
      this->gnss_altitude = 0.0;
      this->gnss_location_state = 0;
      this->error = 0;
      this->velocity_east = 0.0;
      this->velocity_north = 0.0;
      this->velocity_sky = 0.0;
      this->cs = "";
    }
  }

  explicit InsByins_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init),
    data_id(_alloc),
    serial_number(_alloc),
    cs(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->data_id = "";
      this->serial_number = "";
      this->utc_time = 0.0;
      this->gps_week_sec = 0.0;
      this->ins_latitude = 0.0;
      this->ins_longitude = 0.0;
      this->ins_altitude = 0.0;
      this->yaw = 0.0;
      this->pitch = 0.0;
      this->roll = 0.0;
      this->velocity_front = 0.0;
      this->velocity_right = 0.0;
      this->velocity_up = 0.0;
      this->accelerate_right = 0.0;
      this->accelerate_front = 0.0;
      this->accelerate_up = 0.0;
      this->angular_velocity_right_origin = 0.0;
      this->angular_velocity_front_origin = 0.0;
      this->angular_velocity_up_origin = 0.0;
      this->angular_velocity_right_judged = 0.0;
      this->angular_velocity_front_judged = 0.0;
      this->angular_velocity_up_judged = 0.0;
      this->ins_state = 0;
      this->gnss_vector_state = 0;
      this->satellite_num = 0;
      this->rtk_delay = 0.0;
      this->bk_1 = 0.0;
      this->bk_2 = 0.0;
      this->bk_3 = 0.0;
      this->accelerate_north = 0.0;
      this->accelerate_east = 0.0;
      this->accelerate_ground = 0.0;
      this->gnss_latitude = 0.0;
      this->gnss_longitude = 0.0;
      this->gnss_altitude = 0.0;
      this->gnss_location_state = 0;
      this->error = 0;
      this->velocity_east = 0.0;
      this->velocity_north = 0.0;
      this->velocity_sky = 0.0;
      this->cs = "";
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _data_id_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _data_id_type data_id;
  using _serial_number_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _serial_number_type serial_number;
  using _utc_time_type =
    double;
  _utc_time_type utc_time;
  using _gps_week_sec_type =
    double;
  _gps_week_sec_type gps_week_sec;
  using _ins_latitude_type =
    double;
  _ins_latitude_type ins_latitude;
  using _ins_longitude_type =
    double;
  _ins_longitude_type ins_longitude;
  using _ins_altitude_type =
    double;
  _ins_altitude_type ins_altitude;
  using _yaw_type =
    double;
  _yaw_type yaw;
  using _pitch_type =
    double;
  _pitch_type pitch;
  using _roll_type =
    double;
  _roll_type roll;
  using _velocity_front_type =
    double;
  _velocity_front_type velocity_front;
  using _velocity_right_type =
    double;
  _velocity_right_type velocity_right;
  using _velocity_up_type =
    double;
  _velocity_up_type velocity_up;
  using _accelerate_right_type =
    double;
  _accelerate_right_type accelerate_right;
  using _accelerate_front_type =
    double;
  _accelerate_front_type accelerate_front;
  using _accelerate_up_type =
    double;
  _accelerate_up_type accelerate_up;
  using _angular_velocity_right_origin_type =
    double;
  _angular_velocity_right_origin_type angular_velocity_right_origin;
  using _angular_velocity_front_origin_type =
    double;
  _angular_velocity_front_origin_type angular_velocity_front_origin;
  using _angular_velocity_up_origin_type =
    double;
  _angular_velocity_up_origin_type angular_velocity_up_origin;
  using _angular_velocity_right_judged_type =
    double;
  _angular_velocity_right_judged_type angular_velocity_right_judged;
  using _angular_velocity_front_judged_type =
    double;
  _angular_velocity_front_judged_type angular_velocity_front_judged;
  using _angular_velocity_up_judged_type =
    double;
  _angular_velocity_up_judged_type angular_velocity_up_judged;
  using _ins_state_type =
    uint16_t;
  _ins_state_type ins_state;
  using _gnss_vector_state_type =
    uint16_t;
  _gnss_vector_state_type gnss_vector_state;
  using _satellite_num_type =
    uint16_t;
  _satellite_num_type satellite_num;
  using _rtk_delay_type =
    double;
  _rtk_delay_type rtk_delay;
  using _bk_1_type =
    double;
  _bk_1_type bk_1;
  using _bk_2_type =
    double;
  _bk_2_type bk_2;
  using _bk_3_type =
    double;
  _bk_3_type bk_3;
  using _accelerate_north_type =
    double;
  _accelerate_north_type accelerate_north;
  using _accelerate_east_type =
    double;
  _accelerate_east_type accelerate_east;
  using _accelerate_ground_type =
    double;
  _accelerate_ground_type accelerate_ground;
  using _gnss_latitude_type =
    double;
  _gnss_latitude_type gnss_latitude;
  using _gnss_longitude_type =
    double;
  _gnss_longitude_type gnss_longitude;
  using _gnss_altitude_type =
    double;
  _gnss_altitude_type gnss_altitude;
  using _gnss_location_state_type =
    uint16_t;
  _gnss_location_state_type gnss_location_state;
  using _error_type =
    uint16_t;
  _error_type error;
  using _velocity_east_type =
    double;
  _velocity_east_type velocity_east;
  using _velocity_north_type =
    double;
  _velocity_north_type velocity_north;
  using _velocity_sky_type =
    double;
  _velocity_sky_type velocity_sky;
  using _cs_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _cs_type cs;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__data_id(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->data_id = _arg;
    return *this;
  }
  Type & set__serial_number(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->serial_number = _arg;
    return *this;
  }
  Type & set__utc_time(
    const double & _arg)
  {
    this->utc_time = _arg;
    return *this;
  }
  Type & set__gps_week_sec(
    const double & _arg)
  {
    this->gps_week_sec = _arg;
    return *this;
  }
  Type & set__ins_latitude(
    const double & _arg)
  {
    this->ins_latitude = _arg;
    return *this;
  }
  Type & set__ins_longitude(
    const double & _arg)
  {
    this->ins_longitude = _arg;
    return *this;
  }
  Type & set__ins_altitude(
    const double & _arg)
  {
    this->ins_altitude = _arg;
    return *this;
  }
  Type & set__yaw(
    const double & _arg)
  {
    this->yaw = _arg;
    return *this;
  }
  Type & set__pitch(
    const double & _arg)
  {
    this->pitch = _arg;
    return *this;
  }
  Type & set__roll(
    const double & _arg)
  {
    this->roll = _arg;
    return *this;
  }
  Type & set__velocity_front(
    const double & _arg)
  {
    this->velocity_front = _arg;
    return *this;
  }
  Type & set__velocity_right(
    const double & _arg)
  {
    this->velocity_right = _arg;
    return *this;
  }
  Type & set__velocity_up(
    const double & _arg)
  {
    this->velocity_up = _arg;
    return *this;
  }
  Type & set__accelerate_right(
    const double & _arg)
  {
    this->accelerate_right = _arg;
    return *this;
  }
  Type & set__accelerate_front(
    const double & _arg)
  {
    this->accelerate_front = _arg;
    return *this;
  }
  Type & set__accelerate_up(
    const double & _arg)
  {
    this->accelerate_up = _arg;
    return *this;
  }
  Type & set__angular_velocity_right_origin(
    const double & _arg)
  {
    this->angular_velocity_right_origin = _arg;
    return *this;
  }
  Type & set__angular_velocity_front_origin(
    const double & _arg)
  {
    this->angular_velocity_front_origin = _arg;
    return *this;
  }
  Type & set__angular_velocity_up_origin(
    const double & _arg)
  {
    this->angular_velocity_up_origin = _arg;
    return *this;
  }
  Type & set__angular_velocity_right_judged(
    const double & _arg)
  {
    this->angular_velocity_right_judged = _arg;
    return *this;
  }
  Type & set__angular_velocity_front_judged(
    const double & _arg)
  {
    this->angular_velocity_front_judged = _arg;
    return *this;
  }
  Type & set__angular_velocity_up_judged(
    const double & _arg)
  {
    this->angular_velocity_up_judged = _arg;
    return *this;
  }
  Type & set__ins_state(
    const uint16_t & _arg)
  {
    this->ins_state = _arg;
    return *this;
  }
  Type & set__gnss_vector_state(
    const uint16_t & _arg)
  {
    this->gnss_vector_state = _arg;
    return *this;
  }
  Type & set__satellite_num(
    const uint16_t & _arg)
  {
    this->satellite_num = _arg;
    return *this;
  }
  Type & set__rtk_delay(
    const double & _arg)
  {
    this->rtk_delay = _arg;
    return *this;
  }
  Type & set__bk_1(
    const double & _arg)
  {
    this->bk_1 = _arg;
    return *this;
  }
  Type & set__bk_2(
    const double & _arg)
  {
    this->bk_2 = _arg;
    return *this;
  }
  Type & set__bk_3(
    const double & _arg)
  {
    this->bk_3 = _arg;
    return *this;
  }
  Type & set__accelerate_north(
    const double & _arg)
  {
    this->accelerate_north = _arg;
    return *this;
  }
  Type & set__accelerate_east(
    const double & _arg)
  {
    this->accelerate_east = _arg;
    return *this;
  }
  Type & set__accelerate_ground(
    const double & _arg)
  {
    this->accelerate_ground = _arg;
    return *this;
  }
  Type & set__gnss_latitude(
    const double & _arg)
  {
    this->gnss_latitude = _arg;
    return *this;
  }
  Type & set__gnss_longitude(
    const double & _arg)
  {
    this->gnss_longitude = _arg;
    return *this;
  }
  Type & set__gnss_altitude(
    const double & _arg)
  {
    this->gnss_altitude = _arg;
    return *this;
  }
  Type & set__gnss_location_state(
    const uint16_t & _arg)
  {
    this->gnss_location_state = _arg;
    return *this;
  }
  Type & set__error(
    const uint16_t & _arg)
  {
    this->error = _arg;
    return *this;
  }
  Type & set__velocity_east(
    const double & _arg)
  {
    this->velocity_east = _arg;
    return *this;
  }
  Type & set__velocity_north(
    const double & _arg)
  {
    this->velocity_north = _arg;
    return *this;
  }
  Type & set__velocity_sky(
    const double & _arg)
  {
    this->velocity_sky = _arg;
    return *this;
  }
  Type & set__cs(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->cs = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    sensor_driver_msgs::msg::InsByins_<ContainerAllocator> *;
  using ConstRawPtr =
    const sensor_driver_msgs::msg::InsByins_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<sensor_driver_msgs::msg::InsByins_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<sensor_driver_msgs::msg::InsByins_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      sensor_driver_msgs::msg::InsByins_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<sensor_driver_msgs::msg::InsByins_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      sensor_driver_msgs::msg::InsByins_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<sensor_driver_msgs::msg::InsByins_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<sensor_driver_msgs::msg::InsByins_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<sensor_driver_msgs::msg::InsByins_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__sensor_driver_msgs__msg__InsByins
    std::shared_ptr<sensor_driver_msgs::msg::InsByins_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__sensor_driver_msgs__msg__InsByins
    std::shared_ptr<sensor_driver_msgs::msg::InsByins_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const InsByins_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->data_id != other.data_id) {
      return false;
    }
    if (this->serial_number != other.serial_number) {
      return false;
    }
    if (this->utc_time != other.utc_time) {
      return false;
    }
    if (this->gps_week_sec != other.gps_week_sec) {
      return false;
    }
    if (this->ins_latitude != other.ins_latitude) {
      return false;
    }
    if (this->ins_longitude != other.ins_longitude) {
      return false;
    }
    if (this->ins_altitude != other.ins_altitude) {
      return false;
    }
    if (this->yaw != other.yaw) {
      return false;
    }
    if (this->pitch != other.pitch) {
      return false;
    }
    if (this->roll != other.roll) {
      return false;
    }
    if (this->velocity_front != other.velocity_front) {
      return false;
    }
    if (this->velocity_right != other.velocity_right) {
      return false;
    }
    if (this->velocity_up != other.velocity_up) {
      return false;
    }
    if (this->accelerate_right != other.accelerate_right) {
      return false;
    }
    if (this->accelerate_front != other.accelerate_front) {
      return false;
    }
    if (this->accelerate_up != other.accelerate_up) {
      return false;
    }
    if (this->angular_velocity_right_origin != other.angular_velocity_right_origin) {
      return false;
    }
    if (this->angular_velocity_front_origin != other.angular_velocity_front_origin) {
      return false;
    }
    if (this->angular_velocity_up_origin != other.angular_velocity_up_origin) {
      return false;
    }
    if (this->angular_velocity_right_judged != other.angular_velocity_right_judged) {
      return false;
    }
    if (this->angular_velocity_front_judged != other.angular_velocity_front_judged) {
      return false;
    }
    if (this->angular_velocity_up_judged != other.angular_velocity_up_judged) {
      return false;
    }
    if (this->ins_state != other.ins_state) {
      return false;
    }
    if (this->gnss_vector_state != other.gnss_vector_state) {
      return false;
    }
    if (this->satellite_num != other.satellite_num) {
      return false;
    }
    if (this->rtk_delay != other.rtk_delay) {
      return false;
    }
    if (this->bk_1 != other.bk_1) {
      return false;
    }
    if (this->bk_2 != other.bk_2) {
      return false;
    }
    if (this->bk_3 != other.bk_3) {
      return false;
    }
    if (this->accelerate_north != other.accelerate_north) {
      return false;
    }
    if (this->accelerate_east != other.accelerate_east) {
      return false;
    }
    if (this->accelerate_ground != other.accelerate_ground) {
      return false;
    }
    if (this->gnss_latitude != other.gnss_latitude) {
      return false;
    }
    if (this->gnss_longitude != other.gnss_longitude) {
      return false;
    }
    if (this->gnss_altitude != other.gnss_altitude) {
      return false;
    }
    if (this->gnss_location_state != other.gnss_location_state) {
      return false;
    }
    if (this->error != other.error) {
      return false;
    }
    if (this->velocity_east != other.velocity_east) {
      return false;
    }
    if (this->velocity_north != other.velocity_north) {
      return false;
    }
    if (this->velocity_sky != other.velocity_sky) {
      return false;
    }
    if (this->cs != other.cs) {
      return false;
    }
    return true;
  }
  bool operator!=(const InsByins_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct InsByins_

// alias to use template instance with default allocator
using InsByins =
  sensor_driver_msgs::msg::InsByins_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace sensor_driver_msgs

#endif  // SENSOR_DRIVER_MSGS__MSG__DETAIL__INS_BYINS__STRUCT_HPP_
