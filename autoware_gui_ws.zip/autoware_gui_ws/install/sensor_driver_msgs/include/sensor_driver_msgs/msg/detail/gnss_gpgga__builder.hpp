// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sensor_driver_msgs:msg/GnssGpgga.idl
// generated code does not contain a copyright notice

#ifndef SENSOR_DRIVER_MSGS__MSG__DETAIL__GNSS_GPGGA__BUILDER_HPP_
#define SENSOR_DRIVER_MSGS__MSG__DETAIL__GNSS_GPGGA__BUILDER_HPP_

#include "sensor_driver_msgs/msg/detail/gnss_gpgga__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace sensor_driver_msgs
{

namespace msg
{

namespace builder
{

class Init_GnssGpgga_cs
{
public:
  explicit Init_GnssGpgga_cs(::sensor_driver_msgs::msg::GnssGpgga & msg)
  : msg_(msg)
  {}
  ::sensor_driver_msgs::msg::GnssGpgga cs(::sensor_driver_msgs::msg::GnssGpgga::_cs_type arg)
  {
    msg_.cs = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpgga msg_;
};

class Init_GnssGpgga_rtk_id
{
public:
  explicit Init_GnssGpgga_rtk_id(::sensor_driver_msgs::msg::GnssGpgga & msg)
  : msg_(msg)
  {}
  Init_GnssGpgga_cs rtk_id(::sensor_driver_msgs::msg::GnssGpgga::_rtk_id_type arg)
  {
    msg_.rtk_id = std::move(arg);
    return Init_GnssGpgga_cs(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpgga msg_;
};

class Init_GnssGpgga_rtk_delay
{
public:
  explicit Init_GnssGpgga_rtk_delay(::sensor_driver_msgs::msg::GnssGpgga & msg)
  : msg_(msg)
  {}
  Init_GnssGpgga_rtk_id rtk_delay(::sensor_driver_msgs::msg::GnssGpgga::_rtk_delay_type arg)
  {
    msg_.rtk_delay = std::move(arg);
    return Init_GnssGpgga_rtk_id(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpgga msg_;
};

class Init_GnssGpgga_altitude_diff_sign
{
public:
  explicit Init_GnssGpgga_altitude_diff_sign(::sensor_driver_msgs::msg::GnssGpgga & msg)
  : msg_(msg)
  {}
  Init_GnssGpgga_rtk_delay altitude_diff_sign(::sensor_driver_msgs::msg::GnssGpgga::_altitude_diff_sign_type arg)
  {
    msg_.altitude_diff_sign = std::move(arg);
    return Init_GnssGpgga_rtk_delay(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpgga msg_;
};

class Init_GnssGpgga_altitude_diff
{
public:
  explicit Init_GnssGpgga_altitude_diff(::sensor_driver_msgs::msg::GnssGpgga & msg)
  : msg_(msg)
  {}
  Init_GnssGpgga_altitude_diff_sign altitude_diff(::sensor_driver_msgs::msg::GnssGpgga::_altitude_diff_type arg)
  {
    msg_.altitude_diff = std::move(arg);
    return Init_GnssGpgga_altitude_diff_sign(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpgga msg_;
};

class Init_GnssGpgga_altitude_sign
{
public:
  explicit Init_GnssGpgga_altitude_sign(::sensor_driver_msgs::msg::GnssGpgga & msg)
  : msg_(msg)
  {}
  Init_GnssGpgga_altitude_diff altitude_sign(::sensor_driver_msgs::msg::GnssGpgga::_altitude_sign_type arg)
  {
    msg_.altitude_sign = std::move(arg);
    return Init_GnssGpgga_altitude_diff(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpgga msg_;
};

class Init_GnssGpgga_altitude
{
public:
  explicit Init_GnssGpgga_altitude(::sensor_driver_msgs::msg::GnssGpgga & msg)
  : msg_(msg)
  {}
  Init_GnssGpgga_altitude_sign altitude(::sensor_driver_msgs::msg::GnssGpgga::_altitude_type arg)
  {
    msg_.altitude = std::move(arg);
    return Init_GnssGpgga_altitude_sign(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpgga msg_;
};

class Init_GnssGpgga_hdop
{
public:
  explicit Init_GnssGpgga_hdop(::sensor_driver_msgs::msg::GnssGpgga & msg)
  : msg_(msg)
  {}
  Init_GnssGpgga_altitude hdop(::sensor_driver_msgs::msg::GnssGpgga::_hdop_type arg)
  {
    msg_.hdop = std::move(arg);
    return Init_GnssGpgga_altitude(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpgga msg_;
};

class Init_GnssGpgga_satellite_num
{
public:
  explicit Init_GnssGpgga_satellite_num(::sensor_driver_msgs::msg::GnssGpgga & msg)
  : msg_(msg)
  {}
  Init_GnssGpgga_hdop satellite_num(::sensor_driver_msgs::msg::GnssGpgga::_satellite_num_type arg)
  {
    msg_.satellite_num = std::move(arg);
    return Init_GnssGpgga_hdop(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpgga msg_;
};

class Init_GnssGpgga_state
{
public:
  explicit Init_GnssGpgga_state(::sensor_driver_msgs::msg::GnssGpgga & msg)
  : msg_(msg)
  {}
  Init_GnssGpgga_satellite_num state(::sensor_driver_msgs::msg::GnssGpgga::_state_type arg)
  {
    msg_.state = std::move(arg);
    return Init_GnssGpgga_satellite_num(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpgga msg_;
};

class Init_GnssGpgga_longitude_sign
{
public:
  explicit Init_GnssGpgga_longitude_sign(::sensor_driver_msgs::msg::GnssGpgga & msg)
  : msg_(msg)
  {}
  Init_GnssGpgga_state longitude_sign(::sensor_driver_msgs::msg::GnssGpgga::_longitude_sign_type arg)
  {
    msg_.longitude_sign = std::move(arg);
    return Init_GnssGpgga_state(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpgga msg_;
};

class Init_GnssGpgga_longitude
{
public:
  explicit Init_GnssGpgga_longitude(::sensor_driver_msgs::msg::GnssGpgga & msg)
  : msg_(msg)
  {}
  Init_GnssGpgga_longitude_sign longitude(::sensor_driver_msgs::msg::GnssGpgga::_longitude_type arg)
  {
    msg_.longitude = std::move(arg);
    return Init_GnssGpgga_longitude_sign(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpgga msg_;
};

class Init_GnssGpgga_latitude_sign
{
public:
  explicit Init_GnssGpgga_latitude_sign(::sensor_driver_msgs::msg::GnssGpgga & msg)
  : msg_(msg)
  {}
  Init_GnssGpgga_longitude latitude_sign(::sensor_driver_msgs::msg::GnssGpgga::_latitude_sign_type arg)
  {
    msg_.latitude_sign = std::move(arg);
    return Init_GnssGpgga_longitude(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpgga msg_;
};

class Init_GnssGpgga_latitude
{
public:
  explicit Init_GnssGpgga_latitude(::sensor_driver_msgs::msg::GnssGpgga & msg)
  : msg_(msg)
  {}
  Init_GnssGpgga_latitude_sign latitude(::sensor_driver_msgs::msg::GnssGpgga::_latitude_type arg)
  {
    msg_.latitude = std::move(arg);
    return Init_GnssGpgga_latitude_sign(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpgga msg_;
};

class Init_GnssGpgga_utc_time
{
public:
  explicit Init_GnssGpgga_utc_time(::sensor_driver_msgs::msg::GnssGpgga & msg)
  : msg_(msg)
  {}
  Init_GnssGpgga_latitude utc_time(::sensor_driver_msgs::msg::GnssGpgga::_utc_time_type arg)
  {
    msg_.utc_time = std::move(arg);
    return Init_GnssGpgga_latitude(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpgga msg_;
};

class Init_GnssGpgga_data_id
{
public:
  explicit Init_GnssGpgga_data_id(::sensor_driver_msgs::msg::GnssGpgga & msg)
  : msg_(msg)
  {}
  Init_GnssGpgga_utc_time data_id(::sensor_driver_msgs::msg::GnssGpgga::_data_id_type arg)
  {
    msg_.data_id = std::move(arg);
    return Init_GnssGpgga_utc_time(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpgga msg_;
};

class Init_GnssGpgga_header
{
public:
  Init_GnssGpgga_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_GnssGpgga_data_id header(::sensor_driver_msgs::msg::GnssGpgga::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_GnssGpgga_data_id(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpgga msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sensor_driver_msgs::msg::GnssGpgga>()
{
  return sensor_driver_msgs::msg::builder::Init_GnssGpgga_header();
}

}  // namespace sensor_driver_msgs

#endif  // SENSOR_DRIVER_MSGS__MSG__DETAIL__GNSS_GPGGA__BUILDER_HPP_
