// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from sensor_driver_msgs:msg/InsByins.idl
// generated code does not contain a copyright notice
#include "sensor_driver_msgs/msg/detail/ins_byins__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"
// Member `data_id`
// Member `serial_number`
// Member `cs`
#include "rosidl_runtime_c/string_functions.h"

bool
sensor_driver_msgs__msg__InsByins__init(sensor_driver_msgs__msg__InsByins * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    sensor_driver_msgs__msg__InsByins__fini(msg);
    return false;
  }
  // data_id
  if (!rosidl_runtime_c__String__init(&msg->data_id)) {
    sensor_driver_msgs__msg__InsByins__fini(msg);
    return false;
  }
  // serial_number
  if (!rosidl_runtime_c__String__init(&msg->serial_number)) {
    sensor_driver_msgs__msg__InsByins__fini(msg);
    return false;
  }
  // utc_time
  // gps_week_sec
  // ins_latitude
  // ins_longitude
  // ins_altitude
  // yaw
  // pitch
  // roll
  // velocity_front
  // velocity_right
  // velocity_up
  // accelerate_right
  // accelerate_front
  // accelerate_up
  // angular_velocity_right_origin
  // angular_velocity_front_origin
  // angular_velocity_up_origin
  // angular_velocity_right_judged
  // angular_velocity_front_judged
  // angular_velocity_up_judged
  // ins_state
  // gnss_vector_state
  // satellite_num
  // rtk_delay
  // bk_1
  // bk_2
  // bk_3
  // accelerate_north
  // accelerate_east
  // accelerate_ground
  // gnss_latitude
  // gnss_longitude
  // gnss_altitude
  // gnss_location_state
  // error
  // velocity_east
  // velocity_north
  // velocity_sky
  // cs
  if (!rosidl_runtime_c__String__init(&msg->cs)) {
    sensor_driver_msgs__msg__InsByins__fini(msg);
    return false;
  }
  return true;
}

void
sensor_driver_msgs__msg__InsByins__fini(sensor_driver_msgs__msg__InsByins * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // data_id
  rosidl_runtime_c__String__fini(&msg->data_id);
  // serial_number
  rosidl_runtime_c__String__fini(&msg->serial_number);
  // utc_time
  // gps_week_sec
  // ins_latitude
  // ins_longitude
  // ins_altitude
  // yaw
  // pitch
  // roll
  // velocity_front
  // velocity_right
  // velocity_up
  // accelerate_right
  // accelerate_front
  // accelerate_up
  // angular_velocity_right_origin
  // angular_velocity_front_origin
  // angular_velocity_up_origin
  // angular_velocity_right_judged
  // angular_velocity_front_judged
  // angular_velocity_up_judged
  // ins_state
  // gnss_vector_state
  // satellite_num
  // rtk_delay
  // bk_1
  // bk_2
  // bk_3
  // accelerate_north
  // accelerate_east
  // accelerate_ground
  // gnss_latitude
  // gnss_longitude
  // gnss_altitude
  // gnss_location_state
  // error
  // velocity_east
  // velocity_north
  // velocity_sky
  // cs
  rosidl_runtime_c__String__fini(&msg->cs);
}

bool
sensor_driver_msgs__msg__InsByins__are_equal(const sensor_driver_msgs__msg__InsByins * lhs, const sensor_driver_msgs__msg__InsByins * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // data_id
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->data_id), &(rhs->data_id)))
  {
    return false;
  }
  // serial_number
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->serial_number), &(rhs->serial_number)))
  {
    return false;
  }
  // utc_time
  if (lhs->utc_time != rhs->utc_time) {
    return false;
  }
  // gps_week_sec
  if (lhs->gps_week_sec != rhs->gps_week_sec) {
    return false;
  }
  // ins_latitude
  if (lhs->ins_latitude != rhs->ins_latitude) {
    return false;
  }
  // ins_longitude
  if (lhs->ins_longitude != rhs->ins_longitude) {
    return false;
  }
  // ins_altitude
  if (lhs->ins_altitude != rhs->ins_altitude) {
    return false;
  }
  // yaw
  if (lhs->yaw != rhs->yaw) {
    return false;
  }
  // pitch
  if (lhs->pitch != rhs->pitch) {
    return false;
  }
  // roll
  if (lhs->roll != rhs->roll) {
    return false;
  }
  // velocity_front
  if (lhs->velocity_front != rhs->velocity_front) {
    return false;
  }
  // velocity_right
  if (lhs->velocity_right != rhs->velocity_right) {
    return false;
  }
  // velocity_up
  if (lhs->velocity_up != rhs->velocity_up) {
    return false;
  }
  // accelerate_right
  if (lhs->accelerate_right != rhs->accelerate_right) {
    return false;
  }
  // accelerate_front
  if (lhs->accelerate_front != rhs->accelerate_front) {
    return false;
  }
  // accelerate_up
  if (lhs->accelerate_up != rhs->accelerate_up) {
    return false;
  }
  // angular_velocity_right_origin
  if (lhs->angular_velocity_right_origin != rhs->angular_velocity_right_origin) {
    return false;
  }
  // angular_velocity_front_origin
  if (lhs->angular_velocity_front_origin != rhs->angular_velocity_front_origin) {
    return false;
  }
  // angular_velocity_up_origin
  if (lhs->angular_velocity_up_origin != rhs->angular_velocity_up_origin) {
    return false;
  }
  // angular_velocity_right_judged
  if (lhs->angular_velocity_right_judged != rhs->angular_velocity_right_judged) {
    return false;
  }
  // angular_velocity_front_judged
  if (lhs->angular_velocity_front_judged != rhs->angular_velocity_front_judged) {
    return false;
  }
  // angular_velocity_up_judged
  if (lhs->angular_velocity_up_judged != rhs->angular_velocity_up_judged) {
    return false;
  }
  // ins_state
  if (lhs->ins_state != rhs->ins_state) {
    return false;
  }
  // gnss_vector_state
  if (lhs->gnss_vector_state != rhs->gnss_vector_state) {
    return false;
  }
  // satellite_num
  if (lhs->satellite_num != rhs->satellite_num) {
    return false;
  }
  // rtk_delay
  if (lhs->rtk_delay != rhs->rtk_delay) {
    return false;
  }
  // bk_1
  if (lhs->bk_1 != rhs->bk_1) {
    return false;
  }
  // bk_2
  if (lhs->bk_2 != rhs->bk_2) {
    return false;
  }
  // bk_3
  if (lhs->bk_3 != rhs->bk_3) {
    return false;
  }
  // accelerate_north
  if (lhs->accelerate_north != rhs->accelerate_north) {
    return false;
  }
  // accelerate_east
  if (lhs->accelerate_east != rhs->accelerate_east) {
    return false;
  }
  // accelerate_ground
  if (lhs->accelerate_ground != rhs->accelerate_ground) {
    return false;
  }
  // gnss_latitude
  if (lhs->gnss_latitude != rhs->gnss_latitude) {
    return false;
  }
  // gnss_longitude
  if (lhs->gnss_longitude != rhs->gnss_longitude) {
    return false;
  }
  // gnss_altitude
  if (lhs->gnss_altitude != rhs->gnss_altitude) {
    return false;
  }
  // gnss_location_state
  if (lhs->gnss_location_state != rhs->gnss_location_state) {
    return false;
  }
  // error
  if (lhs->error != rhs->error) {
    return false;
  }
  // velocity_east
  if (lhs->velocity_east != rhs->velocity_east) {
    return false;
  }
  // velocity_north
  if (lhs->velocity_north != rhs->velocity_north) {
    return false;
  }
  // velocity_sky
  if (lhs->velocity_sky != rhs->velocity_sky) {
    return false;
  }
  // cs
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->cs), &(rhs->cs)))
  {
    return false;
  }
  return true;
}

bool
sensor_driver_msgs__msg__InsByins__copy(
  const sensor_driver_msgs__msg__InsByins * input,
  sensor_driver_msgs__msg__InsByins * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // data_id
  if (!rosidl_runtime_c__String__copy(
      &(input->data_id), &(output->data_id)))
  {
    return false;
  }
  // serial_number
  if (!rosidl_runtime_c__String__copy(
      &(input->serial_number), &(output->serial_number)))
  {
    return false;
  }
  // utc_time
  output->utc_time = input->utc_time;
  // gps_week_sec
  output->gps_week_sec = input->gps_week_sec;
  // ins_latitude
  output->ins_latitude = input->ins_latitude;
  // ins_longitude
  output->ins_longitude = input->ins_longitude;
  // ins_altitude
  output->ins_altitude = input->ins_altitude;
  // yaw
  output->yaw = input->yaw;
  // pitch
  output->pitch = input->pitch;
  // roll
  output->roll = input->roll;
  // velocity_front
  output->velocity_front = input->velocity_front;
  // velocity_right
  output->velocity_right = input->velocity_right;
  // velocity_up
  output->velocity_up = input->velocity_up;
  // accelerate_right
  output->accelerate_right = input->accelerate_right;
  // accelerate_front
  output->accelerate_front = input->accelerate_front;
  // accelerate_up
  output->accelerate_up = input->accelerate_up;
  // angular_velocity_right_origin
  output->angular_velocity_right_origin = input->angular_velocity_right_origin;
  // angular_velocity_front_origin
  output->angular_velocity_front_origin = input->angular_velocity_front_origin;
  // angular_velocity_up_origin
  output->angular_velocity_up_origin = input->angular_velocity_up_origin;
  // angular_velocity_right_judged
  output->angular_velocity_right_judged = input->angular_velocity_right_judged;
  // angular_velocity_front_judged
  output->angular_velocity_front_judged = input->angular_velocity_front_judged;
  // angular_velocity_up_judged
  output->angular_velocity_up_judged = input->angular_velocity_up_judged;
  // ins_state
  output->ins_state = input->ins_state;
  // gnss_vector_state
  output->gnss_vector_state = input->gnss_vector_state;
  // satellite_num
  output->satellite_num = input->satellite_num;
  // rtk_delay
  output->rtk_delay = input->rtk_delay;
  // bk_1
  output->bk_1 = input->bk_1;
  // bk_2
  output->bk_2 = input->bk_2;
  // bk_3
  output->bk_3 = input->bk_3;
  // accelerate_north
  output->accelerate_north = input->accelerate_north;
  // accelerate_east
  output->accelerate_east = input->accelerate_east;
  // accelerate_ground
  output->accelerate_ground = input->accelerate_ground;
  // gnss_latitude
  output->gnss_latitude = input->gnss_latitude;
  // gnss_longitude
  output->gnss_longitude = input->gnss_longitude;
  // gnss_altitude
  output->gnss_altitude = input->gnss_altitude;
  // gnss_location_state
  output->gnss_location_state = input->gnss_location_state;
  // error
  output->error = input->error;
  // velocity_east
  output->velocity_east = input->velocity_east;
  // velocity_north
  output->velocity_north = input->velocity_north;
  // velocity_sky
  output->velocity_sky = input->velocity_sky;
  // cs
  if (!rosidl_runtime_c__String__copy(
      &(input->cs), &(output->cs)))
  {
    return false;
  }
  return true;
}

sensor_driver_msgs__msg__InsByins *
sensor_driver_msgs__msg__InsByins__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sensor_driver_msgs__msg__InsByins * msg = (sensor_driver_msgs__msg__InsByins *)allocator.allocate(sizeof(sensor_driver_msgs__msg__InsByins), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(sensor_driver_msgs__msg__InsByins));
  bool success = sensor_driver_msgs__msg__InsByins__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
sensor_driver_msgs__msg__InsByins__destroy(sensor_driver_msgs__msg__InsByins * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    sensor_driver_msgs__msg__InsByins__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
sensor_driver_msgs__msg__InsByins__Sequence__init(sensor_driver_msgs__msg__InsByins__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sensor_driver_msgs__msg__InsByins * data = NULL;

  if (size) {
    data = (sensor_driver_msgs__msg__InsByins *)allocator.zero_allocate(size, sizeof(sensor_driver_msgs__msg__InsByins), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = sensor_driver_msgs__msg__InsByins__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        sensor_driver_msgs__msg__InsByins__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
sensor_driver_msgs__msg__InsByins__Sequence__fini(sensor_driver_msgs__msg__InsByins__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      sensor_driver_msgs__msg__InsByins__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

sensor_driver_msgs__msg__InsByins__Sequence *
sensor_driver_msgs__msg__InsByins__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sensor_driver_msgs__msg__InsByins__Sequence * array = (sensor_driver_msgs__msg__InsByins__Sequence *)allocator.allocate(sizeof(sensor_driver_msgs__msg__InsByins__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = sensor_driver_msgs__msg__InsByins__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
sensor_driver_msgs__msg__InsByins__Sequence__destroy(sensor_driver_msgs__msg__InsByins__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    sensor_driver_msgs__msg__InsByins__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
sensor_driver_msgs__msg__InsByins__Sequence__are_equal(const sensor_driver_msgs__msg__InsByins__Sequence * lhs, const sensor_driver_msgs__msg__InsByins__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!sensor_driver_msgs__msg__InsByins__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
sensor_driver_msgs__msg__InsByins__Sequence__copy(
  const sensor_driver_msgs__msg__InsByins__Sequence * input,
  sensor_driver_msgs__msg__InsByins__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(sensor_driver_msgs__msg__InsByins);
    sensor_driver_msgs__msg__InsByins * data =
      (sensor_driver_msgs__msg__InsByins *)realloc(output->data, allocation_size);
    if (!data) {
      return false;
    }
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!sensor_driver_msgs__msg__InsByins__init(&data[i])) {
        /* free currently allocated and return false */
        for (; i-- > output->capacity; ) {
          sensor_driver_msgs__msg__InsByins__fini(&data[i]);
        }
        free(data);
        return false;
      }
    }
    output->data = data;
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!sensor_driver_msgs__msg__InsByins__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
