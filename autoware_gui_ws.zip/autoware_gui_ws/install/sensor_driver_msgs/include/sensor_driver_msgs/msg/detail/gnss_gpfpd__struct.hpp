// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from sensor_driver_msgs:msg/GnssGpfpd.idl
// generated code does not contain a copyright notice

#ifndef SENSOR_DRIVER_MSGS__MSG__DETAIL__GNSS_GPFPD__STRUCT_HPP_
#define SENSOR_DRIVER_MSGS__MSG__DETAIL__GNSS_GPFPD__STRUCT_HPP_

#include <rosidl_runtime_cpp/bounded_vector.hpp>
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__sensor_driver_msgs__msg__GnssGpfpd __attribute__((deprecated))
#else
# define DEPRECATED__sensor_driver_msgs__msg__GnssGpfpd __declspec(deprecated)
#endif

namespace sensor_driver_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct GnssGpfpd_
{
  using Type = GnssGpfpd_<ContainerAllocator>;

  explicit GnssGpfpd_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->data_id = "";
      this->gps_week = 0;
      this->gps_time = 0.0;
      this->yaw = 0.0;
      this->pitch = 0.0;
      this->roll = 0.0;
      this->latitude = 0.0;
      this->longitude = 0.0;
      this->altitude = 0.0;
      this->velocity_east = 0.0;
      this->velocity_north = 0.0;
      this->velocity_sky = 0.0;
      this->base_line = 0.0;
      this->satellite_num_1 = 0;
      this->satellite_num_2 = 0;
      this->state = 0;
      this->cs = "";
    }
  }

  explicit GnssGpfpd_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init),
    data_id(_alloc),
    cs(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->data_id = "";
      this->gps_week = 0;
      this->gps_time = 0.0;
      this->yaw = 0.0;
      this->pitch = 0.0;
      this->roll = 0.0;
      this->latitude = 0.0;
      this->longitude = 0.0;
      this->altitude = 0.0;
      this->velocity_east = 0.0;
      this->velocity_north = 0.0;
      this->velocity_sky = 0.0;
      this->base_line = 0.0;
      this->satellite_num_1 = 0;
      this->satellite_num_2 = 0;
      this->state = 0;
      this->cs = "";
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _data_id_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _data_id_type data_id;
  using _gps_week_type =
    int16_t;
  _gps_week_type gps_week;
  using _gps_time_type =
    double;
  _gps_time_type gps_time;
  using _yaw_type =
    double;
  _yaw_type yaw;
  using _pitch_type =
    double;
  _pitch_type pitch;
  using _roll_type =
    double;
  _roll_type roll;
  using _latitude_type =
    double;
  _latitude_type latitude;
  using _longitude_type =
    double;
  _longitude_type longitude;
  using _altitude_type =
    double;
  _altitude_type altitude;
  using _velocity_east_type =
    double;
  _velocity_east_type velocity_east;
  using _velocity_north_type =
    double;
  _velocity_north_type velocity_north;
  using _velocity_sky_type =
    double;
  _velocity_sky_type velocity_sky;
  using _base_line_type =
    double;
  _base_line_type base_line;
  using _satellite_num_1_type =
    int16_t;
  _satellite_num_1_type satellite_num_1;
  using _satellite_num_2_type =
    int16_t;
  _satellite_num_2_type satellite_num_2;
  using _state_type =
    int16_t;
  _state_type state;
  using _cs_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _cs_type cs;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__data_id(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->data_id = _arg;
    return *this;
  }
  Type & set__gps_week(
    const int16_t & _arg)
  {
    this->gps_week = _arg;
    return *this;
  }
  Type & set__gps_time(
    const double & _arg)
  {
    this->gps_time = _arg;
    return *this;
  }
  Type & set__yaw(
    const double & _arg)
  {
    this->yaw = _arg;
    return *this;
  }
  Type & set__pitch(
    const double & _arg)
  {
    this->pitch = _arg;
    return *this;
  }
  Type & set__roll(
    const double & _arg)
  {
    this->roll = _arg;
    return *this;
  }
  Type & set__latitude(
    const double & _arg)
  {
    this->latitude = _arg;
    return *this;
  }
  Type & set__longitude(
    const double & _arg)
  {
    this->longitude = _arg;
    return *this;
  }
  Type & set__altitude(
    const double & _arg)
  {
    this->altitude = _arg;
    return *this;
  }
  Type & set__velocity_east(
    const double & _arg)
  {
    this->velocity_east = _arg;
    return *this;
  }
  Type & set__velocity_north(
    const double & _arg)
  {
    this->velocity_north = _arg;
    return *this;
  }
  Type & set__velocity_sky(
    const double & _arg)
  {
    this->velocity_sky = _arg;
    return *this;
  }
  Type & set__base_line(
    const double & _arg)
  {
    this->base_line = _arg;
    return *this;
  }
  Type & set__satellite_num_1(
    const int16_t & _arg)
  {
    this->satellite_num_1 = _arg;
    return *this;
  }
  Type & set__satellite_num_2(
    const int16_t & _arg)
  {
    this->satellite_num_2 = _arg;
    return *this;
  }
  Type & set__state(
    const int16_t & _arg)
  {
    this->state = _arg;
    return *this;
  }
  Type & set__cs(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->cs = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    sensor_driver_msgs::msg::GnssGpfpd_<ContainerAllocator> *;
  using ConstRawPtr =
    const sensor_driver_msgs::msg::GnssGpfpd_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<sensor_driver_msgs::msg::GnssGpfpd_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<sensor_driver_msgs::msg::GnssGpfpd_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      sensor_driver_msgs::msg::GnssGpfpd_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<sensor_driver_msgs::msg::GnssGpfpd_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      sensor_driver_msgs::msg::GnssGpfpd_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<sensor_driver_msgs::msg::GnssGpfpd_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<sensor_driver_msgs::msg::GnssGpfpd_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<sensor_driver_msgs::msg::GnssGpfpd_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__sensor_driver_msgs__msg__GnssGpfpd
    std::shared_ptr<sensor_driver_msgs::msg::GnssGpfpd_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__sensor_driver_msgs__msg__GnssGpfpd
    std::shared_ptr<sensor_driver_msgs::msg::GnssGpfpd_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const GnssGpfpd_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->data_id != other.data_id) {
      return false;
    }
    if (this->gps_week != other.gps_week) {
      return false;
    }
    if (this->gps_time != other.gps_time) {
      return false;
    }
    if (this->yaw != other.yaw) {
      return false;
    }
    if (this->pitch != other.pitch) {
      return false;
    }
    if (this->roll != other.roll) {
      return false;
    }
    if (this->latitude != other.latitude) {
      return false;
    }
    if (this->longitude != other.longitude) {
      return false;
    }
    if (this->altitude != other.altitude) {
      return false;
    }
    if (this->velocity_east != other.velocity_east) {
      return false;
    }
    if (this->velocity_north != other.velocity_north) {
      return false;
    }
    if (this->velocity_sky != other.velocity_sky) {
      return false;
    }
    if (this->base_line != other.base_line) {
      return false;
    }
    if (this->satellite_num_1 != other.satellite_num_1) {
      return false;
    }
    if (this->satellite_num_2 != other.satellite_num_2) {
      return false;
    }
    if (this->state != other.state) {
      return false;
    }
    if (this->cs != other.cs) {
      return false;
    }
    return true;
  }
  bool operator!=(const GnssGpfpd_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct GnssGpfpd_

// alias to use template instance with default allocator
using GnssGpfpd =
  sensor_driver_msgs::msg::GnssGpfpd_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace sensor_driver_msgs

#endif  // SENSOR_DRIVER_MSGS__MSG__DETAIL__GNSS_GPFPD__STRUCT_HPP_
