// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sensor_driver_msgs:msg/GnssGpgst.idl
// generated code does not contain a copyright notice

#ifndef SENSOR_DRIVER_MSGS__MSG__DETAIL__GNSS_GPGST__BUILDER_HPP_
#define SENSOR_DRIVER_MSGS__MSG__DETAIL__GNSS_GPGST__BUILDER_HPP_

#include "sensor_driver_msgs/msg/detail/gnss_gpgst__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace sensor_driver_msgs
{

namespace msg
{

namespace builder
{

class Init_GnssGpgst_cs
{
public:
  explicit Init_GnssGpgst_cs(::sensor_driver_msgs::msg::GnssGpgst & msg)
  : msg_(msg)
  {}
  ::sensor_driver_msgs::msg::GnssGpgst cs(::sensor_driver_msgs::msg::GnssGpgst::_cs_type arg)
  {
    msg_.cs = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpgst msg_;
};

class Init_GnssGpgst_alt_std
{
public:
  explicit Init_GnssGpgst_alt_std(::sensor_driver_msgs::msg::GnssGpgst & msg)
  : msg_(msg)
  {}
  Init_GnssGpgst_cs alt_std(::sensor_driver_msgs::msg::GnssGpgst::_alt_std_type arg)
  {
    msg_.alt_std = std::move(arg);
    return Init_GnssGpgst_cs(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpgst msg_;
};

class Init_GnssGpgst_lon_std
{
public:
  explicit Init_GnssGpgst_lon_std(::sensor_driver_msgs::msg::GnssGpgst & msg)
  : msg_(msg)
  {}
  Init_GnssGpgst_alt_std lon_std(::sensor_driver_msgs::msg::GnssGpgst::_lon_std_type arg)
  {
    msg_.lon_std = std::move(arg);
    return Init_GnssGpgst_alt_std(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpgst msg_;
};

class Init_GnssGpgst_lat_std
{
public:
  explicit Init_GnssGpgst_lat_std(::sensor_driver_msgs::msg::GnssGpgst & msg)
  : msg_(msg)
  {}
  Init_GnssGpgst_lon_std lat_std(::sensor_driver_msgs::msg::GnssGpgst::_lat_std_type arg)
  {
    msg_.lat_std = std::move(arg);
    return Init_GnssGpgst_lon_std(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpgst msg_;
};

class Init_GnssGpgst_orient
{
public:
  explicit Init_GnssGpgst_orient(::sensor_driver_msgs::msg::GnssGpgst & msg)
  : msg_(msg)
  {}
  Init_GnssGpgst_lat_std orient(::sensor_driver_msgs::msg::GnssGpgst::_orient_type arg)
  {
    msg_.orient = std::move(arg);
    return Init_GnssGpgst_lat_std(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpgst msg_;
};

class Init_GnssGpgst_smnr_std
{
public:
  explicit Init_GnssGpgst_smnr_std(::sensor_driver_msgs::msg::GnssGpgst & msg)
  : msg_(msg)
  {}
  Init_GnssGpgst_orient smnr_std(::sensor_driver_msgs::msg::GnssGpgst::_smnr_std_type arg)
  {
    msg_.smnr_std = std::move(arg);
    return Init_GnssGpgst_orient(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpgst msg_;
};

class Init_GnssGpgst_smjr_std
{
public:
  explicit Init_GnssGpgst_smjr_std(::sensor_driver_msgs::msg::GnssGpgst & msg)
  : msg_(msg)
  {}
  Init_GnssGpgst_smnr_std smjr_std(::sensor_driver_msgs::msg::GnssGpgst::_smjr_std_type arg)
  {
    msg_.smjr_std = std::move(arg);
    return Init_GnssGpgst_smnr_std(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpgst msg_;
};

class Init_GnssGpgst_rms_std
{
public:
  explicit Init_GnssGpgst_rms_std(::sensor_driver_msgs::msg::GnssGpgst & msg)
  : msg_(msg)
  {}
  Init_GnssGpgst_smjr_std rms_std(::sensor_driver_msgs::msg::GnssGpgst::_rms_std_type arg)
  {
    msg_.rms_std = std::move(arg);
    return Init_GnssGpgst_smjr_std(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpgst msg_;
};

class Init_GnssGpgst_utc_time
{
public:
  explicit Init_GnssGpgst_utc_time(::sensor_driver_msgs::msg::GnssGpgst & msg)
  : msg_(msg)
  {}
  Init_GnssGpgst_rms_std utc_time(::sensor_driver_msgs::msg::GnssGpgst::_utc_time_type arg)
  {
    msg_.utc_time = std::move(arg);
    return Init_GnssGpgst_rms_std(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpgst msg_;
};

class Init_GnssGpgst_data_id
{
public:
  explicit Init_GnssGpgst_data_id(::sensor_driver_msgs::msg::GnssGpgst & msg)
  : msg_(msg)
  {}
  Init_GnssGpgst_utc_time data_id(::sensor_driver_msgs::msg::GnssGpgst::_data_id_type arg)
  {
    msg_.data_id = std::move(arg);
    return Init_GnssGpgst_utc_time(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpgst msg_;
};

class Init_GnssGpgst_header
{
public:
  Init_GnssGpgst_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_GnssGpgst_data_id header(::sensor_driver_msgs::msg::GnssGpgst::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_GnssGpgst_data_id(msg_);
  }

private:
  ::sensor_driver_msgs::msg::GnssGpgst msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sensor_driver_msgs::msg::GnssGpgst>()
{
  return sensor_driver_msgs::msg::builder::Init_GnssGpgst_header();
}

}  // namespace sensor_driver_msgs

#endif  // SENSOR_DRIVER_MSGS__MSG__DETAIL__GNSS_GPGST__BUILDER_HPP_
