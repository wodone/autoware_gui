// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from sensor_driver_msgs:msg/UltrasonicRadar20.idl
// generated code does not contain a copyright notice
#include "sensor_driver_msgs/msg/detail/ultrasonic_radar20__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"

bool
sensor_driver_msgs__msg__UltrasonicRadar20__init(sensor_driver_msgs__msg__UltrasonicRadar20 * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    sensor_driver_msgs__msg__UltrasonicRadar20__fini(msg);
    return false;
  }
  // ultrasonic_01
  // ultrasonic_02
  // ultrasonic_03
  // ultrasonic_04
  // ultrasonic_05
  // ultrasonic_06
  // ultrasonic_07
  // ultrasonic_08
  // ultrasonic_09
  // ultrasonic_10
  // ultrasonic_11
  // ultrasonic_12
  // ultrasonic_13
  // ultrasonic_14
  // ultrasonic_15
  // ultrasonic_16
  // ultrasonic_17
  // ultrasonic_18
  // ultrasonic_19
  // ultrasonic_20
  return true;
}

void
sensor_driver_msgs__msg__UltrasonicRadar20__fini(sensor_driver_msgs__msg__UltrasonicRadar20 * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // ultrasonic_01
  // ultrasonic_02
  // ultrasonic_03
  // ultrasonic_04
  // ultrasonic_05
  // ultrasonic_06
  // ultrasonic_07
  // ultrasonic_08
  // ultrasonic_09
  // ultrasonic_10
  // ultrasonic_11
  // ultrasonic_12
  // ultrasonic_13
  // ultrasonic_14
  // ultrasonic_15
  // ultrasonic_16
  // ultrasonic_17
  // ultrasonic_18
  // ultrasonic_19
  // ultrasonic_20
}

bool
sensor_driver_msgs__msg__UltrasonicRadar20__are_equal(const sensor_driver_msgs__msg__UltrasonicRadar20 * lhs, const sensor_driver_msgs__msg__UltrasonicRadar20 * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // ultrasonic_01
  if (lhs->ultrasonic_01 != rhs->ultrasonic_01) {
    return false;
  }
  // ultrasonic_02
  if (lhs->ultrasonic_02 != rhs->ultrasonic_02) {
    return false;
  }
  // ultrasonic_03
  if (lhs->ultrasonic_03 != rhs->ultrasonic_03) {
    return false;
  }
  // ultrasonic_04
  if (lhs->ultrasonic_04 != rhs->ultrasonic_04) {
    return false;
  }
  // ultrasonic_05
  if (lhs->ultrasonic_05 != rhs->ultrasonic_05) {
    return false;
  }
  // ultrasonic_06
  if (lhs->ultrasonic_06 != rhs->ultrasonic_06) {
    return false;
  }
  // ultrasonic_07
  if (lhs->ultrasonic_07 != rhs->ultrasonic_07) {
    return false;
  }
  // ultrasonic_08
  if (lhs->ultrasonic_08 != rhs->ultrasonic_08) {
    return false;
  }
  // ultrasonic_09
  if (lhs->ultrasonic_09 != rhs->ultrasonic_09) {
    return false;
  }
  // ultrasonic_10
  if (lhs->ultrasonic_10 != rhs->ultrasonic_10) {
    return false;
  }
  // ultrasonic_11
  if (lhs->ultrasonic_11 != rhs->ultrasonic_11) {
    return false;
  }
  // ultrasonic_12
  if (lhs->ultrasonic_12 != rhs->ultrasonic_12) {
    return false;
  }
  // ultrasonic_13
  if (lhs->ultrasonic_13 != rhs->ultrasonic_13) {
    return false;
  }
  // ultrasonic_14
  if (lhs->ultrasonic_14 != rhs->ultrasonic_14) {
    return false;
  }
  // ultrasonic_15
  if (lhs->ultrasonic_15 != rhs->ultrasonic_15) {
    return false;
  }
  // ultrasonic_16
  if (lhs->ultrasonic_16 != rhs->ultrasonic_16) {
    return false;
  }
  // ultrasonic_17
  if (lhs->ultrasonic_17 != rhs->ultrasonic_17) {
    return false;
  }
  // ultrasonic_18
  if (lhs->ultrasonic_18 != rhs->ultrasonic_18) {
    return false;
  }
  // ultrasonic_19
  if (lhs->ultrasonic_19 != rhs->ultrasonic_19) {
    return false;
  }
  // ultrasonic_20
  if (lhs->ultrasonic_20 != rhs->ultrasonic_20) {
    return false;
  }
  return true;
}

bool
sensor_driver_msgs__msg__UltrasonicRadar20__copy(
  const sensor_driver_msgs__msg__UltrasonicRadar20 * input,
  sensor_driver_msgs__msg__UltrasonicRadar20 * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // ultrasonic_01
  output->ultrasonic_01 = input->ultrasonic_01;
  // ultrasonic_02
  output->ultrasonic_02 = input->ultrasonic_02;
  // ultrasonic_03
  output->ultrasonic_03 = input->ultrasonic_03;
  // ultrasonic_04
  output->ultrasonic_04 = input->ultrasonic_04;
  // ultrasonic_05
  output->ultrasonic_05 = input->ultrasonic_05;
  // ultrasonic_06
  output->ultrasonic_06 = input->ultrasonic_06;
  // ultrasonic_07
  output->ultrasonic_07 = input->ultrasonic_07;
  // ultrasonic_08
  output->ultrasonic_08 = input->ultrasonic_08;
  // ultrasonic_09
  output->ultrasonic_09 = input->ultrasonic_09;
  // ultrasonic_10
  output->ultrasonic_10 = input->ultrasonic_10;
  // ultrasonic_11
  output->ultrasonic_11 = input->ultrasonic_11;
  // ultrasonic_12
  output->ultrasonic_12 = input->ultrasonic_12;
  // ultrasonic_13
  output->ultrasonic_13 = input->ultrasonic_13;
  // ultrasonic_14
  output->ultrasonic_14 = input->ultrasonic_14;
  // ultrasonic_15
  output->ultrasonic_15 = input->ultrasonic_15;
  // ultrasonic_16
  output->ultrasonic_16 = input->ultrasonic_16;
  // ultrasonic_17
  output->ultrasonic_17 = input->ultrasonic_17;
  // ultrasonic_18
  output->ultrasonic_18 = input->ultrasonic_18;
  // ultrasonic_19
  output->ultrasonic_19 = input->ultrasonic_19;
  // ultrasonic_20
  output->ultrasonic_20 = input->ultrasonic_20;
  return true;
}

sensor_driver_msgs__msg__UltrasonicRadar20 *
sensor_driver_msgs__msg__UltrasonicRadar20__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sensor_driver_msgs__msg__UltrasonicRadar20 * msg = (sensor_driver_msgs__msg__UltrasonicRadar20 *)allocator.allocate(sizeof(sensor_driver_msgs__msg__UltrasonicRadar20), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(sensor_driver_msgs__msg__UltrasonicRadar20));
  bool success = sensor_driver_msgs__msg__UltrasonicRadar20__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
sensor_driver_msgs__msg__UltrasonicRadar20__destroy(sensor_driver_msgs__msg__UltrasonicRadar20 * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    sensor_driver_msgs__msg__UltrasonicRadar20__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
sensor_driver_msgs__msg__UltrasonicRadar20__Sequence__init(sensor_driver_msgs__msg__UltrasonicRadar20__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sensor_driver_msgs__msg__UltrasonicRadar20 * data = NULL;

  if (size) {
    data = (sensor_driver_msgs__msg__UltrasonicRadar20 *)allocator.zero_allocate(size, sizeof(sensor_driver_msgs__msg__UltrasonicRadar20), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = sensor_driver_msgs__msg__UltrasonicRadar20__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        sensor_driver_msgs__msg__UltrasonicRadar20__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
sensor_driver_msgs__msg__UltrasonicRadar20__Sequence__fini(sensor_driver_msgs__msg__UltrasonicRadar20__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      sensor_driver_msgs__msg__UltrasonicRadar20__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

sensor_driver_msgs__msg__UltrasonicRadar20__Sequence *
sensor_driver_msgs__msg__UltrasonicRadar20__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sensor_driver_msgs__msg__UltrasonicRadar20__Sequence * array = (sensor_driver_msgs__msg__UltrasonicRadar20__Sequence *)allocator.allocate(sizeof(sensor_driver_msgs__msg__UltrasonicRadar20__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = sensor_driver_msgs__msg__UltrasonicRadar20__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
sensor_driver_msgs__msg__UltrasonicRadar20__Sequence__destroy(sensor_driver_msgs__msg__UltrasonicRadar20__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    sensor_driver_msgs__msg__UltrasonicRadar20__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
sensor_driver_msgs__msg__UltrasonicRadar20__Sequence__are_equal(const sensor_driver_msgs__msg__UltrasonicRadar20__Sequence * lhs, const sensor_driver_msgs__msg__UltrasonicRadar20__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!sensor_driver_msgs__msg__UltrasonicRadar20__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
sensor_driver_msgs__msg__UltrasonicRadar20__Sequence__copy(
  const sensor_driver_msgs__msg__UltrasonicRadar20__Sequence * input,
  sensor_driver_msgs__msg__UltrasonicRadar20__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(sensor_driver_msgs__msg__UltrasonicRadar20);
    sensor_driver_msgs__msg__UltrasonicRadar20 * data =
      (sensor_driver_msgs__msg__UltrasonicRadar20 *)realloc(output->data, allocation_size);
    if (!data) {
      return false;
    }
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!sensor_driver_msgs__msg__UltrasonicRadar20__init(&data[i])) {
        /* free currently allocated and return false */
        for (; i-- > output->capacity; ) {
          sensor_driver_msgs__msg__UltrasonicRadar20__fini(&data[i]);
        }
        free(data);
        return false;
      }
    }
    output->data = data;
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!sensor_driver_msgs__msg__UltrasonicRadar20__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
