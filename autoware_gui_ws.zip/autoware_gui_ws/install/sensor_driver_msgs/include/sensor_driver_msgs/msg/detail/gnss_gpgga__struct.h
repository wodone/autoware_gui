// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from sensor_driver_msgs:msg/GnssGpgga.idl
// generated code does not contain a copyright notice

#ifndef SENSOR_DRIVER_MSGS__MSG__DETAIL__GNSS_GPGGA__STRUCT_H_
#define SENSOR_DRIVER_MSGS__MSG__DETAIL__GNSS_GPGGA__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'data_id'
// Member 'latitude_sign'
// Member 'longitude_sign'
// Member 'altitude_sign'
// Member 'altitude_diff_sign'
// Member 'cs'
#include "rosidl_runtime_c/string.h"

// Struct defined in msg/GnssGpgga in the package sensor_driver_msgs.
typedef struct sensor_driver_msgs__msg__GnssGpgga
{
  std_msgs__msg__Header header;
  rosidl_runtime_c__String data_id;
  double utc_time;
  double latitude;
  rosidl_runtime_c__String latitude_sign;
  double longitude;
  rosidl_runtime_c__String longitude_sign;
  uint16_t state;
  uint16_t satellite_num;
  double hdop;
  double altitude;
  rosidl_runtime_c__String altitude_sign;
  double altitude_diff;
  rosidl_runtime_c__String altitude_diff_sign;
  double rtk_delay;
  uint16_t rtk_id;
  rosidl_runtime_c__String cs;
} sensor_driver_msgs__msg__GnssGpgga;

// Struct for a sequence of sensor_driver_msgs__msg__GnssGpgga.
typedef struct sensor_driver_msgs__msg__GnssGpgga__Sequence
{
  sensor_driver_msgs__msg__GnssGpgga * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sensor_driver_msgs__msg__GnssGpgga__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SENSOR_DRIVER_MSGS__MSG__DETAIL__GNSS_GPGGA__STRUCT_H_
