// generated from rosidl_generator_c/resource/idl.h.em
// with input from sensor_driver_msgs:msg/GnssGpzda.idl
// generated code does not contain a copyright notice

#ifndef SENSOR_DRIVER_MSGS__MSG__GNSS_GPZDA_H_
#define SENSOR_DRIVER_MSGS__MSG__GNSS_GPZDA_H_

#include "sensor_driver_msgs/msg/detail/gnss_gpzda__struct.h"
#include "sensor_driver_msgs/msg/detail/gnss_gpzda__functions.h"
#include "sensor_driver_msgs/msg/detail/gnss_gpzda__type_support.h"

#endif  // SENSOR_DRIVER_MSGS__MSG__GNSS_GPZDA_H_
