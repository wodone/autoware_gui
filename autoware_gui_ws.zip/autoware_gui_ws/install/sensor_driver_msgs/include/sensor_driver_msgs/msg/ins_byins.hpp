// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SENSOR_DRIVER_MSGS__MSG__INS_BYINS_HPP_
#define SENSOR_DRIVER_MSGS__MSG__INS_BYINS_HPP_

#include "sensor_driver_msgs/msg/detail/ins_byins__struct.hpp"
#include "sensor_driver_msgs/msg/detail/ins_byins__builder.hpp"
#include "sensor_driver_msgs/msg/detail/ins_byins__traits.hpp"

#endif  // SENSOR_DRIVER_MSGS__MSG__INS_BYINS_HPP_
