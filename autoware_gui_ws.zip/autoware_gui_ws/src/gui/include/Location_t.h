#ifndef LOCATION_T_H
#define LOCATION_T_H

struct Location_t{
    double x=0,y=0;
    double roll=0,pitch=0,yaw=0;
};

#endif // LOCATION_T_H
