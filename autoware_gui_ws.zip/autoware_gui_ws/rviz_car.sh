#!/bin/sh
rviz2 -d /home/ros2/autoware_gui_ws/localization.rviz
