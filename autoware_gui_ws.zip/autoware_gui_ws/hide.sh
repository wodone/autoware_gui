#!/bin/sh
wmctrl -r RViz -b add,below
